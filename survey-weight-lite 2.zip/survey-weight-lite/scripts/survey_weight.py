"""
调研数据 IPF 加权脚本（通用版）
支持任意 N 个维度，无需预设性别/年龄/学历
支持 xlsx 与 csv 输入（按扩展名自动识别）

本脚本与具体 AI 工具无关：放在任意目录均可，调用时传入绝对路径即可，例如：
    python3 /你的目录/survey_weight.py --file "数据.csv" --dim "性别|男,女|50.4,49.6" --output-dir "/输出目录"
"""

import argparse
import csv
import io
import os
import re
import sys
import unicodedata
from itertools import combinations

import numpy as np
import pandas as pd


# ── 数据读取（xlsx / csv 自动识别） ────────────────────────────────────────────────

def read_data(file, sheet):
    """
    按扩展名自动选择读取方式。
    - .csv：使用 read_csv，忽略 sheet 参数
    - 其它（.xlsx/.xls）：使用 read_excel，sheet 生效
    返回 (df, fmt, sheet_used)
    """
    ext = os.path.splitext(file)[1].lower()
    options = {"dtype": object, "keep_default_na": False}
    if ext == ".csv":
        if sheet not in (None, "Sheet1"):
            print(f"  [提示] CSV 文件无 sheet 概念，--sheet={sheet} 已忽略")
        for encoding in ("utf-8-sig", "gb18030"):
            try:
                with open(file, encoding=encoding, newline="") as stream:
                    headers = next(csv.reader(stream), [])
                _validate_headers(headers)
                df = pd.read_csv(file, encoding=encoding, skip_blank_lines=False, **options)
                return df, "csv", None
            except UnicodeDecodeError:
                if encoding == "gb18030":
                    raise
    if ext not in (".xlsx", ".xls"):
        raise ValueError("仅支持 .csv、.xlsx 或 .xls 输入")
    excel_options = {"engine_kwargs": {"data_only": False}} if ext == ".xlsx" else {}
    with pd.ExcelFile(file, **excel_options) as workbook:
        names = workbook.sheet_names
        if sheet is None or (sheet == "Sheet1" and sheet not in names):
            sheet = names[0]
            print(f"  [提示] 改用第一个 sheet「{sheet}」")
        headers = pd.read_excel(workbook, sheet_name=sheet, header=None, nrows=1,
                                **options)
        _validate_headers(headers.iloc[0].tolist() if len(headers) else [])
        df = pd.read_excel(workbook, sheet_name=sheet, **options)
    return df, "excel", sheet


def _validate_headers(headers):
    if not headers or any(pd.isna(v) or not str(v).strip() for v in headers):
        raise ValueError("输入表头不得为空")
    if len(set(headers)) != len(headers):
        raise ValueError("输入表头不得重复，拒绝自动改名")


# ── IPF 核心算法 ──────────────────────────────────────────────────────────────

def _validate_weights(w):
    with np.errstate(over="ignore", invalid="ignore"):
        total = w.sum()
    if not np.isfinite(w).all() or (w < 0).any() or not np.isfinite(total) or total <= 0:
        raise ValueError("IPF 权重必须有限、非负且总和为正；目标可能不可行")
    return total


def _marginal_error(df, dim_cols, targets, w):
    total = _validate_weights(w)
    return max(abs(w[df[col] == cat].sum() / total - share)
               for col in dim_cols for cat, share in targets[col].items())


def ipf_weights(df, dim_cols, targets, max_iter=100, tol=1e-6):
    if max_iter <= 0 or not np.isfinite(tol) or tol <= 0:
        raise ValueError("max-iter 和容差必须为正")
    if not len(df) or not dim_cols or len(set(dim_cols)) != len(dim_cols):
        raise ValueError("IPF 需要非空样本和不重复的维度")
    for col in dim_cols:
        shares = np.asarray(list(targets[col].values()), dtype=float)
        if not len(shares) or not np.isfinite(shares).all() or (shares < 0).any():
            raise ValueError("IPF 目标必须有限且非负")
        if abs(shares.sum() - 1) > 1e-12:
            raise ValueError("IPF 目标合计必须为 1")
        if df[col].isna().any() or not df[col].isin(targets[col]).all():
            raise ValueError(f"IPF 维度 {col} 有空值或未映射记录")
    w = np.ones(len(df))
    error = float("inf")
    with np.errstate(over="ignore", invalid="ignore", divide="ignore"):
        for _ in range(max_iter):
            for col in dim_cols:
                for cat, target_share in targets[col].items():
                    mask = df[col] == cat
                    current = w[mask].sum() / _validate_weights(w)
                    if current > 0:
                        w[mask] *= target_share / current
                        _validate_weights(w)
                    elif target_share > 0:
                        raise ValueError(
                            f"目标不可行：{col} 档位 {cat} 无正权重样本；"
                            f"边际误差至少 {target_share * 100:.6f} 个百分点")
            error = _marginal_error(df, dim_cols, targets, w)
            if error <= tol:
                return w
    raise ValueError(f"IPF 未收敛或目标不可行（{max_iter} 次迭代）；"
                     f"最大边际误差 {error * 100:.6f} 个百分点")


# ── 列编码 ────────────────────────────────────────────────────────────────────

def _strip_age_suffix(val):
    """去掉年龄值中的'岁'字，便于统一匹配"""
    return re.sub(r'岁', '', val.strip())


def is_range_spec(values):
    """
    判断值列表是否为数值区间格式。
    支持格式：
      30-39、50+、50及以上、50以上   （下限型）
      30以下、30及以下               （上限型，新增）
      以上各格式均支持带'岁'后缀，如 30岁-39岁、50岁+、30岁以下
    """
    pattern = re.compile(
        r'^\d+-\d+$'      # 30-39
        r'|^\d+\+$'       # 50+
        r'|^\d+及以上$'   # 50及以上
        r'|^\d+以上$'     # 50以上
        r'|^\d+以下$'     # 30以下（<N，即0~N-1）
        r'|^\d+及以下$'   # 30及以下（≤N，即0~N）
    )
    return all(pattern.match(_strip_age_suffix(v)) for v in values)


def parse_range(val):
    """整数年龄左闭右开边界，与清洗 age_bounds 的包含规则一致。"""
    v = _strip_age_suffix(val)
    m = re.fullmatch(r'(\d+)(及以下|以下|及以上|以上|\+)', v)
    if m:
        n, op = int(m[1]), m[2]
        bounds = (0, n + (op == "及以下")) if "以下" in op else (
            n + (op == "以上"), float("inf"))
    else:
        m = re.fullmatch(r'(\d+)-(\d+)', v)
        if not m:
            raise ValueError(f"无法解析区间: {val}")
        bounds = (int(m[1]), int(m[2]) + 1)
    if bounds[0] >= bounds[1]:
        raise ValueError(f"区间翻转或为空: {val}")
    return bounds


def _validated_ranges(values):
    ranges = [parse_range(v) for v in values]
    for i, j in combinations(range(len(ranges)), 2):
        if max(ranges[i][0], ranges[j][0]) < min(ranges[i][1], ranges[j][1]):
            raise ValueError(f"区间重叠: {values[i]} 与 {values[j]}")
    return ranges


def encode_column(series, values):
    """独立编码；数字 object 列可做区间，字符串档位只精确匹配。"""
    if not values or any(not v.strip() for v in values) or len(set(values)) != len(values):
        raise ValueError("档位 values 不得为空或重复")
    missing = series.isna() | series.map(lambda v: isinstance(v, str) and not v.strip())
    if is_range_spec(values):
        ranges = _validated_ranges(values)
        numeric = pd.to_numeric(series, errors="coerce")
        if numeric[~missing].notna().all():
            result = pd.Series(np.nan, index=series.index)
            for i, (lo, hi) in enumerate(ranges, start=1):
                result[(numeric >= lo) & (numeric < hi) & np.isfinite(numeric)] = i
        else:
            result = series.map({v: i for i, v in enumerate(values, start=1)})
    else:
        # 文本精确匹配；真实数字兼容数值档位，但绝不截断小数。
        mapping = {v: i for i, v in enumerate(values, start=1)}
        result = series.map(mapping)
        nontext = series.map(lambda v: not isinstance(v, str)) & ~missing
        if nontext.any():
            numeric_mapping = {}
            for i, value in enumerate(values, start=1):
                try:
                    number = float(value)
                except ValueError:
                    continue
                if not np.isfinite(number):
                    continue
                if number in numeric_mapping:
                    raise ValueError("数值档位重复或有歧义，不能将不同文本编码混同")
                numeric_mapping[number] = i
            result.loc[nontext] = series.loc[nontext].map(numeric_mapping)
    result[missing] = np.nan
    return result, series[result.isna()].unique()


# ── 零样本检查与报告 ──────────────────────────────────────────────────────────

def check_zero_samples(df_valid, encoded_cols, dims):
    """
    检查各维度是否存在零样本档位。
    返回 issues 列表，每项包含：col, zero_cats, valid_cats, norm_targets
    若返回空列表表示无问题。
    """
    issues = []
    for (col, values, targets_pct), enc_col in zip(dims, encoded_cols):
        zero_cats = []   # [(label, target_pct)]
        valid_cats = []  # [(label, target_pct, n)]
        for i, (v, t) in enumerate(zip(values, targets_pct), start=1):
            n = int((df_valid[enc_col] == i).sum())
            if n == 0 and t > 0:
                zero_cats.append((v, t))
            else:
                valid_cats.append((v, t, n))
        if zero_cats:
            total_valid = sum(t for _, t, _ in valid_cats)
            norm = ([(v, round(t / total_valid * 100, 4)) for v, t, _ in valid_cats]
                    if total_valid > 0 else [])
            issues.append({
                "col": col,
                "zero_cats": zero_cats,
                "valid_cats": valid_cats,
                "norm_targets": norm,
            })
    return issues


def print_zero_sample_report(issues):
    """打印结构化的零样本告警，供 AI 解读后向用户说明"""
    print("\n" + "="*60)
    print("  [零样本告警] 以下维度存在配比档位在样本中无人")
    print("="*60)
    for iss in issues:
        col = iss["col"]
        print(f"\n  ▶ 维度「{col}」")
        print(f"    零样本档位（目标配比中有，数据中没有）：")
        for v, t in iss["zero_cats"]:
            print(f"      · {v}  目标 {t:.2f}%  样本数 0")
        print(f"    有效档位（数据中存在）：")
        for v, t, n in iss["valid_cats"]:
            print(f"      · {v}  目标 {t:.2f}%  样本数 {n}")
    print()
    print("  正目标档位没有样本，目标不可行；未自动分摊或修改目标。")
    print("  请确认补采样本、合法合并档位、重设目标或取消该维度后重试。")
    print("="*60)


# ── 输出辅助 ──────────────────────────────────────────────────────────────────

def check_targets(df, enc_col, col_label, targets_pct, labels, kept_indices):
    w = df["weight"]
    total = w.sum()
    lines = [f"\n{'='*54}", f"  {col_label} 加权命中检查", f"{'='*54}"]
    lines.append(f"  {'档位':<22} {'目标%':>8} {'实际%':>8} {'差值':>8}  {'状态'}")
    lines.append(f"  {'-'*56}")
    all_hit = True
    for idx, lbl, tgt in zip(kept_indices, labels, targets_pct):
        actual = df.loc[df[enc_col] == idx, "weight"].sum() / total * 100
        diff = abs(actual - tgt)
        status = "✓" if diff < 0.5 else "✗ 偏差较大"
        if diff >= 0.5:
            all_hit = False
        lines.append(f"  {lbl:<22} {tgt:>7.2f}% {actual:>7.2f}% {diff:>+7.2f}%  {status}")
    lines.append(f"  {'结论':<22} {'全部命中 ✓' if all_hit else '存在偏差，请检查样本分布'}")
    return "\n".join(lines)


def summary_table(df, enc_col, targets_pct, labels, kept_indices):
    total_w = df["weight"].sum()
    rows = []
    for idx, lbl, tgt in zip(kept_indices, labels, targets_pct):
        mask = df[enc_col] == idx
        n_raw = mask.sum()
        rows.append({
            "档位": lbl,
            "原始N": n_raw,
            "原始%": round(n_raw / len(df) * 100, 2),
            "加权%": round(df.loc[mask, "weight"].sum() / total_w * 100, 2),
            "目标%": tgt,
        })
    return pd.DataFrame(rows)


def build_crosstab(df, enc_a, enc_b, cats_a, cats_b, kept_a, kept_b):
    w = df["weight"]
    result = pd.DataFrame(0.0, index=kept_a, columns=kept_b)
    for ia, a in zip(kept_a, cats_a):
        for ib, b in zip(kept_b, cats_b):
            result.loc[ia, ib] = w[(df[enc_a] == ia) & (df[enc_b] == ib)].sum()
    result.index = cats_a
    result.columns = cats_b
    result["合计"] = result.sum(axis=1)
    result.loc["合计"] = result.sum(axis=0)
    total = result.loc["合计", "合计"]
    return (result / total * 100).round(2)


# ── 输出路径与排他写入 ────────────────────────────────────────────────────────

def _unique_name(label, used, limit=31, byte_limit=180):
    label = unicodedata.normalize("NFC", str(label))
    base = re.sub(r'[\x00-\x1f<>:"/\\|?*\[\]]', '_', label).strip(" .'\t") or "维度"
    for number in range(1, len(used) + 2):
        suffix = "" if number == 1 else f"_{number}"
        stem = base[:limit - len(suffix)].encode("utf-8")[:byte_limit - len(suffix)].decode(
            "utf-8", errors="ignore")
        name = stem + suffix
        if name.casefold() not in used:
            used.add(name.casefold())
            return name


def _output_plan(output_dir, dims):
    root = os.path.abspath(output_dir)
    paths = [os.path.join(root, name) for name in
             ("加权后数据.xlsx", "加权后数据.csv", "加权汇总.xlsx", "命中检查.txt")]
    used_sheets, used_files = set(), set()
    sheets = [_unique_name(col, used_sheets) for col, _, _ in dims]
    crosses = []
    for i, j in combinations(range(len(dims)), 2):
        name = _unique_name(f"{dims[i][0]}×{dims[j][0]}", used_files, limit=180)
        path = os.path.join(root, "交叉表", name + ".xlsx")
        crosses.append((i, j, path))
        paths.append(path)
    return root, paths, sheets, crosses


def _preflight_paths(input_file, root, paths):
    input_real = os.path.realpath(input_file)
    for directory in (root, os.path.join(root, "交叉表")):
        current = directory
        while True:
            if os.path.islink(current):
                raise ValueError(f"输出路径含软链，拒绝写入: {current}")
            if os.path.lexists(current) and not os.path.isdir(current):
                raise ValueError(f"输出父路径不是目录: {current}")
            parent = os.path.dirname(current)
            if parent == current:
                break
            current = parent
    for path in paths:
        if os.path.realpath(path) == input_real:
            raise ValueError(f"输出与输入冲突，拒绝写入: {path}")
        if os.path.lexists(path):
            raise ValueError(f"目标已存在（含软链），拒绝覆盖: {path}")


def _excel_bytes(tables):
    buffer = io.BytesIO()
    with pd.ExcelWriter(buffer, engine="openpyxl") as writer:
        for sheet, table, index in tables:
            table.to_excel(writer, sheet_name=sheet, index=index)
        # pandas/openpyxl 默认将 = 开头的字符串写为公式；强制存为原文。
        for sheet in writer.book.worksheets:
            for row in sheet:
                for cell in row:
                    if isinstance(cell.value, str) and cell.value.startswith("="):
                        cell.data_type = "s"
    return buffer.getvalue()


def _write_outputs(input_file, root, payloads):
    _preflight_paths(input_file, root, list(payloads))
    created_dirs, created_files = [], []
    try:
        for directory in (root, os.path.join(root, "交叉表")):
            missing = []
            current = directory
            while not os.path.exists(current):
                missing.append(current)
                current = os.path.dirname(current)
            for path in reversed(missing):
                os.mkdir(path)
                created_dirs.append(path)
        _preflight_paths(input_file, root, list(payloads))
        # 先排他创建全部目标；有任何冲突时只回滚本次创建的文件。
        handles = []
        try:
            for path in payloads:
                fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL |
                             getattr(os, "O_NOFOLLOW", 0), 0o600)
                stat = os.fstat(fd)
                created_files.append((path, stat.st_dev, stat.st_ino))
                handles.append(os.fdopen(fd, "wb"))
            for handle, data in zip(handles, payloads.values()):
                handle.write(data)
        finally:
            for handle in handles:
                handle.close()
    except Exception:
        for path, device, inode in reversed(created_files):
            if os.path.lexists(path):
                stat = os.lstat(path)
                if (stat.st_dev, stat.st_ino) == (device, inode):
                    os.unlink(path)
        for path in reversed(created_dirs):
            try:
                if os.path.isdir(path) and not os.path.islink(path) and not os.listdir(path):
                    os.rmdir(path)
            except OSError as cleanup_error:
                print(f"[回滚提示] 本次产物已清除，但空目录无法删除: {path}；{cleanup_error}",
                      file=sys.stderr)
        raise


# ── 主流程 ────────────────────────────────────────────────────────────────────

def _run(args):
    if args.max_iter <= 0:
        raise ValueError("--max-iter 必须大于 0")
    dims, seen = [], set()
    for spec in args.dim:
        parts = spec.split("|")
        if len(parts) != 3:
            raise ValueError("--dim 格式应为 '列名|值1,值2|目标1,目标2'")
        col = parts[0].strip()
        values = [v.strip() for v in parts[1].split(",")]
        if not col or col in seen:
            raise ValueError("维度名不得为空或重复")
        if any(not v for v in values) or len(set(values)) != len(values):
            raise ValueError(f"{col}: values 不得为空或重复")
        seen.add(col)
        try:
            percentages = np.asarray([float(t) for t in parts[2].split(",")])
        except ValueError:
            raise ValueError(f"{col}: 目标百分比必须为数字") from None
        if len(values) != len(percentages):
            raise ValueError(f"{col}: 档位与目标数量不匹配")
        if not np.isfinite(percentages).all() or (percentages < 0).any():
            raise ValueError(f"{col}: 目标必须有限且非负")
        total = percentages.sum()
        if not np.isfinite(total) or total <= 0 or abs(total - 100) > 0.1 + 1e-12:
            raise ValueError(f"{col}: 目标合计应为 100，当前为 {total}")
        if total != 100:
            print(f"  [归一化] {col}: 原合计 {total:.12g}%，按 100/{total:.12g} 缩放至 100%")
            percentages = percentages / total * 100
            print("  [归一化目标] " + ", ".join(
                f"{v}={t:.8f}%" for v, t in zip(values, percentages)))
        dims.append((col, values, percentages.tolist()))

    root, paths, sheets, crosses = _output_plan(args.output_dir, dims)
    _preflight_paths(args.file, root, paths)
    print(f"\n读取数据: {args.file}  sheet={args.sheet}")
    df, fmt, _ = read_data(args.file, args.sheet)
    print(f"  格式: {fmt.upper()}，行数: {len(df)}，列数: {len(df.columns)}")
    if not len(df):
        raise ValueError("输入没有答卷记录")
    if "weight" in df.columns and not args.replace_weight:
        raise ValueError("已有 weight 列；重算必须显式指定 --replace-weight，旧值将备份保留")

    encoded = pd.DataFrame(index=df.index)
    norm_dims, targets_dict = [], {}
    for number, (col, values, percentages) in enumerate(dims):
        if col not in df.columns:
            raise ValueError(f"未找到加权维度列: {col}")
        enc_col = f"_enc_{number}"
        encoded[enc_col], _ = encode_column(df[col], values)
        invalid = encoded[enc_col].isna()
        if invalid.any():
            raise ValueError(f"{col}: {int(invalid.sum())} 行存在未映射/空值或区间未覆盖；停止加权")
        indices = list(range(1, len(values) + 1))
        norm_dims.append((col, enc_col, indices, values, percentages))
        targets_dict[enc_col] = {idx: t / 100 for idx, t in zip(indices, percentages)}

    encoded_cols = list(encoded.columns)
    issues = check_zero_samples(encoded, encoded_cols, dims)
    if issues:
        print_zero_sample_report(issues)
        raise ValueError("正目标零样本档位，目标不可行")
    print("\n检查 IPF 可行性与收敛...")
    w = ipf_weights(encoded, encoded_cols, targets_dict, max_iter=args.max_iter)
    total = _validate_weights(w)
    w = w / total * len(w)
    _validate_weights(w)
    error = _marginal_error(encoded, encoded_cols, targets_dict, w)
    if error > 1e-6:
        raise ValueError(f"归一化后边际误差 {error * 100:.6f} 个百分点，停止输出")
    print(f"  最大边际误差: {error * 100:.8f} 个百分点")
    if args.check_only:
        print("预检通过：全部记录已映射，目标可行且已收敛；未写入产物。")
        return 0

    if "weight" in df.columns:
        backup = "原始_weight"
        number = 2
        while backup in df.columns:
            backup = f"原始_weight_{number}"
            number += 1
        df = df.rename(columns={"weight": backup})
        print(f"  [旧权重保留] weight → {backup}")
    df["weight"] = w
    encoded["weight"] = w
    print(f"  权重范围: {w.min():.4f} ~ {w.max():.4f}，均值: {w.mean():.4f}")
    if w.max() > 10:
        print("  [警告] 最大权重超过 10，请检查稀疏组合与权重集中情况")

    check_text = "".join(check_targets(encoded, enc, col, pct, vals, ids)
                         for col, enc, ids, vals, pct in norm_dims)
    print(check_text)
    summary = [(sheet, summary_table(encoded, enc, pct, vals, ids), False)
               for sheet, (col, enc, ids, vals, pct) in zip(sheets, norm_dims)]
    # 全部序列化成功后才开始创建输出，避免验证或格式错误留下半套产物。
    payloads = {
        paths[0]: _excel_bytes([("Sheet1", df, False)]),
        paths[1]: df.to_csv(index=False).encode("utf-8-sig"),
        paths[2]: _excel_bytes(summary),
        paths[3]: check_text.encode("utf-8"),
    }
    for i, j, path in crosses:
        _, enc_a, ids_a, vals_a, _ = norm_dims[i]
        _, enc_b, ids_b, vals_b, _ = norm_dims[j]
        table = build_crosstab(encoded, enc_a, enc_b, vals_a, vals_b, ids_a, ids_b)
        payloads[path] = _excel_bytes([("Sheet1", table, True)])
    _write_outputs(args.file, root, payloads)
    for path in payloads:
        print(f"已输出: {path}")
    print("\n加权完成。")
    return 0


def main(argv=None):
    parser = argparse.ArgumentParser(description="调研数据 IPF 加权（通用版，支持 xlsx/csv）")
    parser.add_argument("--file", required=True, help="数据文件路径（.xlsx 或 .csv）")
    parser.add_argument("--sheet", default="Sheet1", help="Sheet 名称（仅 xlsx 生效，csv 忽略）")
    parser.add_argument("--dim", action="append", required=True,
                        metavar="列名|值1,值2,...|目标1,目标2,...", help="加权维度，可重复多次")
    parser.add_argument("--output-dir", default=".", help="输出目录")
    parser.add_argument("--max-iter", type=int, default=100)
    parser.add_argument("--check-only", action="store_true", help="仅预检映射、目标及收敛，不写入产物")
    parser.add_argument("--replace-weight", action="store_true", help="允许重算 weight，旧值备份到无冲突列")
    try:
        args = parser.parse_args(argv)
    except SystemExit as exc:
        return exc.code
    try:
        return _run(args)
    except Exception as exc:
        print(f"[错误] {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    sys.exit(main())
