#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""CSV转换回归：只创建及使用独立目录内的合成问卷和城市表。"""
import contextlib
import csv
import hashlib
import io
import json
import os
import subprocess
import sys
import tempfile
import unittest
from datetime import datetime
from pathlib import Path
from unittest.mock import patch
from uuid import uuid4

import pandas as pd
from openpyxl import Workbook, load_workbook

import clean_pipeline as pipeline

ROOT = None
SCRIPTS = Path(__file__).resolve().parent


class CsvConversionTests(unittest.TestCase):
    def setUp(self):
        self.case = ROOT / (self._testMethodName + "_" + uuid4().hex[:8])
        self.case.mkdir()
        self.source = self.case / "synthetic.csv"
        self.output = self.case / "converted.xlsx"
        self.wd = self.case / "work"
        self.city = self.case / "synthetic_city.xlsx"
        book = Workbook()
        book.active.append(["城市名", "城市分级"])
        book.active.append(["合成城市市", "合成分级"])
        book.save(self.city)
        book.close()

    def cli(self, command, *args, code=0):
        args = list(map(str, args))
        if command == "prepare" and "--city-file" not in args:
            args.extend(["--city-file", str(self.city)])
        capture = io.StringIO()
        with contextlib.redirect_stdout(capture):
            status = pipeline.main([command, *args])
        lines = capture.getvalue().splitlines()
        self.assertEqual(len(lines), 1, capture.getvalue())
        self.assertTrue(lines[0].startswith("@@RESULT@@ "))
        result = json.loads(lines[0][len("@@RESULT@@ "):])
        self.assertEqual(status, code, result)
        self.assertEqual(result["ok"], code == 0, result)
        return result

    def write_csv(self, headers=None, rows=None, encoding="utf-8-sig"):
        headers = ["Q1.备注？", "合成标识"] if headers is None else headers
        rows = [["普通", "001"]] if rows is None else rows
        with self.source.open("w", encoding=encoding, newline="") as handle:
            writer = csv.writer(handle, lineterminator="\r\n")
            writer.writerow(headers)
            writer.writerows(rows)
        return headers, rows

    def text_csv(self, content, encoding="utf-8"):
        self.source.write_bytes(content.encode(encoding))

    def convert(self, *args, code=0):
        return self.cli("convert", "--survey", self.source, "--output", self.output, *args, code=code)

    def prepare(self, *args, code=0):
        return self.cli("prepare", "--survey", self.source, "--dir", self.wd, *args, code=code)

    def cells(self, path=None, sheet="data", literal=True):
        book = load_workbook(path or self.output, read_only=True, data_only=False)
        try:
            table = book[sheet]
            table.reset_dimensions()
            rows = list(table.iter_rows())
            for row in rows:
                for cell in row:
                    self.assertNotEqual(cell.data_type, "f")
                    if literal:
                        self.assertTrue(cell.value is None or isinstance(cell.value, str))
            return [["" if cell.value is None else cell.value for cell in row] for row in rows]
        finally:
            book.close()

    def snapshot(self):
        if not self.wd.exists():
            return None
        return {p.name: ("link:" + os.readlink(p) if p.is_symlink() else pipeline.digest(p))
                for p in self.wd.iterdir() if p.is_file() or p.is_symlink()}

    def assert_blocked_consumers(self):
        before = self.snapshot()
        for command in ("inspect", "questions", "clean"):
            self.cli(command, "--dir", self.wd, code=2)
            self.assertEqual(self.snapshot(), before)
        self.prepare(code=2)
        self.assertEqual(self.snapshot(), before)

    def legacy(self, headers=None, rows=None):
        self.write_csv(headers, rows)
        self.wd.mkdir()
        copy = self.wd / "问卷数据表.csv"
        copy.write_bytes(self.source.read_bytes())
        cfg = {"format": "survey-weight-lite-v1", "source_original": str(self.source),
               "source_copy": copy.name, "source_sha256": pipeline.digest(copy), "outputs": [],
               "sheet": None, "city_file": str(self.city)}
        pipeline.write_json(self.wd / pipeline.CONFIG, cfg)
        pipeline.write_json(self.wd / pipeline.MAPPING, {"demo_map": {}, "demo_value_map": {}, "reference_year": None})
        return cfg

    def test_utf8_sig_auto(self):
        headers, rows = self.write_csv()
        result = self.convert()
        self.assertEqual(result["encoding"], "utf-8-sig")
        self.assertEqual(self.cells(), [headers, *rows])

    def test_utf8_auto(self):
        headers, rows = self.write_csv(encoding="utf-8")
        self.assertEqual(self.convert()["encoding"], "utf-8")
        self.assertEqual(self.cells(), [headers, *rows])

    def test_gbk_explicit(self):
        headers, rows = self.write_csv(encoding="gbk")
        self.assertEqual(self.convert("--encoding", "gbk")["encoding"], "gbk")
        self.assertEqual(self.cells(), [headers, *rows])

    def test_gb18030_auto_extended_unicode(self):
        headers, rows = self.write_csv(rows=[["中文𠀀", "001"]], encoding="gb18030")
        self.assertEqual(self.convert()["encoding"], "gb18030")
        self.assertEqual(self.cells(), [headers, *rows])

    def test_gb18030_explicit(self):
        self.write_csv(encoding="gb18030")
        self.assertEqual(self.convert("--encoding", "gb18030")["encoding"], "gb18030")

    def test_utf8_explicit_accepts_bom(self):
        headers, rows = self.write_csv()
        self.convert("--encoding", "utf-8")
        self.assertEqual(self.cells(), [headers, *rows])

    def test_utf8_sig_explicit_without_bom(self):
        headers, rows = self.write_csv(encoding="utf-8")
        self.convert("--encoding", "utf-8-sig")
        self.assertEqual(self.cells(), [headers, *rows])

    def test_wrong_explicit_encoding_rejected(self):
        self.write_csv(rows=[["扩展𠀀", "001"]], encoding="gb18030")
        self.convert("--encoding", "utf-8", code=2)
        self.assertFalse(self.output.exists())

    def test_unknown_encoding_rejected(self):
        self.write_csv()
        self.convert("--encoding", "latin-1", code=2)
        self.assertFalse(self.output.exists())

    def test_long_headers_complete(self):
        headers = ["Q1." + "完整题干" * 800, "备注"]
        self.write_csv(headers, [["001", "普通"]])
        result = self.convert()
        self.assertGreaterEqual(len(headers[0]), 3000)
        self.assertEqual(self.cells()[0], headers)
        self.assertEqual(result["cols"], 2)
        self.assertNotIn(headers[0], json.dumps(result, ensure_ascii=False))

    def test_quoted_commas_quotes_crlf_and_lf(self):
        headers, rows = self.write_csv(rows=[['逗号,双引号"保留"\r\n下一行\n末行', "001"], ["普通\r结尾", "002"]])
        result = self.convert()
        self.assertEqual(result["rows"], 2)
        self.assertEqual(self.cells(), [headers, *rows])

    def test_literal_values_and_order_no_strip(self):
        values = ["001", "NA", "NULL", "=SUM(1,2)", "中文", "123456789012345678901234567890", "  答案  ", "", "@文本", "+1", "-1", "\t文本\t"]
        headers = [" 原表头 ", "记录"]
        rows = [[value, str(index)] for index, value in enumerate(values)]
        self.write_csv(headers, rows)
        self.convert()
        self.assertEqual(self.cells(), [headers, *rows])

    def test_explicit_all_empty_tail_rows(self):
        self.text_csv('a,b\r\n001,x\r\n,\r\n,\r\n')
        result = self.convert()
        self.assertEqual(result["rows"], 3)
        self.assertEqual(self.cells(), [["a", "b"], ["001", "x"], ["", ""], ["", ""]])

    def test_single_column_quoted_empty_tail(self):
        self.text_csv('a\r\nx\r\n""\r\n""\r\n')
        self.convert()
        self.assertEqual(self.cells(), [["a"], ["x"], [""], [""]])

    def test_physical_blank_lines_skipped_counted(self):
        self.text_csv('\r\na,b\r\n\r\n"x\r\n\r\ny",001\r\n\r\n,\r\n\r\n')
        result = self.convert()
        self.assertEqual(result["rows"], 2)
        self.assertEqual(result["skipped_blank_lines"], 4)
        self.assertEqual(self.cells(), [["a", "b"], ["x\r\n\r\ny", "001"], ["", ""]])

    def test_header_only(self):
        self.write_csv(rows=[])
        result = self.convert()
        self.assertEqual(result["rows"], 0)
        self.assertEqual(len(self.cells()), 1)
        prepared = self.prepare()
        self.assertEqual(prepared["survey"]["rows"], 0)

    def test_empty_file_and_only_physical_blanks_rejected(self):
        for content in ("", "\r\n\n"):
            with self.subTest(content=repr(content)):
                self.text_csv(content)
                self.convert(code=2)
                self.assertFalse(self.output.exists())

    def test_trailing_unnamed_all_empty_columns_dropped_and_reported(self):
        # 问卷平台导出常见：每行末尾多逗号。整列为空才忽略，其余原文不变。
        for content, dropped in (('a,b,\r\n001,=1+1,\r\n,,\r\n', 1), ('a,b,,\nx,"多\n行",,\n', 2)):
            with self.subTest(content=repr(content)):
                self.text_csv(content)
                if self.output.exists():
                    self.output.unlink()
                result = self.convert()
                self.assertEqual(result["cols"], 2)
                self.assertEqual(result["dropped_trailing_empty_columns"], dropped)
                cells = self.cells()
                self.assertEqual(cells[0], ["a", "b"])
                self.assertTrue(all(len(row) == 2 for row in cells))
        self.assertEqual(self.cells()[1], ["x", "多\n行"])

    def test_trailing_unnamed_column_with_data_or_only_empty_rejected(self):
        for content in ('a,b,\nx,y,有数据\n', 'a,b,\nx,y, \n', ',\n,\n', 'a,,b,\nx,,y,\n'):
            with self.subTest(content=repr(content)):
                self.text_csv(content)
                self.convert(code=2)
                self.assertFalse(self.output.exists())

    def test_trailing_empty_column_prepare_reuse_and_clean(self):
        self.text_csv('Q1.您的性别是？,Q2.备注？,\r\n男,001,\r\n女,=1+1,\r\n')
        first = self.prepare()
        self.assertEqual(first["conversion"]["dropped_trailing_empty_columns"], 1)
        self.assertEqual(first["conversion"]["cols"], 2)
        before = self.snapshot()
        self.prepare()
        self.assertEqual(self.snapshot(), before)
        inspected = self.cli("inspect", "--dir", self.wd)
        self.assertEqual(inspected["survey"]["cols"], 2)
        self.cli("clean", "--dir", self.wd)
        merged = self.cells(self.wd / "问卷数据表_merged.xlsx", literal=False)
        self.assertNotIn("", merged[0])

    def test_empty_headers_rejected(self):
        for content in ('a,\nx,y\n', ',b\nx,y\n', '"",b\nx,y\n', 'a,   \nx,y\n', '""\n'):
            with self.subTest(content=repr(content)):
                self.text_csv(content)
                self.convert(code=2)
                self.assertFalse(self.output.exists())

    def test_duplicate_headers_rejected(self):
        for content in ('a,a\nx,y\n', '"a","a"\nx,y\n'):
            self.text_csv(content)
            self.convert(code=2)
            self.assertFalse(self.output.exists())

    def test_short_row_rejected(self):
        self.text_csv("a,b\nx\n")
        self.convert(code=2)
        self.prepare(code=2)
        self.assertFalse(self.wd.exists())

    def test_long_row_rejected(self):
        self.text_csv("a,b\nx,y,z\n")
        self.convert(code=2)
        self.assertFalse(self.output.exists())

    def test_unclosed_quote_rejected(self):
        self.text_csv('a,b\n"x\ny,001\n')
        self.convert(code=2)
        self.assertFalse(self.output.exists())

    def test_invalid_quote_syntax_rejected(self):
        for content in ('a,b\n"x"junk,y\n', 'a,b\nx"z,y\n'):
            self.text_csv(content)
            self.convert(code=2)
            self.assertFalse(self.output.exists())

    def test_excel_cell_exact_limit(self):
        self.write_csv(rows=[["长" * 32767, "001"]])
        self.convert()
        self.assertEqual(len(self.cells()[1][0]), 32767)

    def test_excel_long_cell_rejected(self):
        self.write_csv(rows=[["长" * 32768, "001"]])
        self.convert(code=2)
        self.prepare(code=2)
        self.assertFalse(self.output.exists())
        self.assertFalse(self.wd.exists())

    def test_excel_long_header_rejected(self):
        self.write_csv(["长" * 32768, "b"])
        self.convert(code=2)
        self.assertFalse(self.output.exists())

    def test_xml_control_characters_rejected(self):
        for value in ("x\x00y", "x\x01y", "x\x0by", "x\x0cy", "x\x1fy", "x\ufffey", "x\uffffy"):
            with self.subTest(value=repr(value)):
                self.write_csv(rows=[[value, "001"]])
                self.convert(code=2)
                self.assertFalse(self.output.exists())

    def test_excel_row_limit_simulation(self):
        self.write_csv(rows=[["x", "1"], ["", ""]])
        with patch.object(pipeline, "EXCEL_MAX_ROWS", 2):
            self.convert(code=2)
        with patch.object(pipeline, "EXCEL_MAX_ROWS", 3):
            self.convert()
        self.assertEqual(len(self.cells()), 3)

    def test_excel_column_limit_simulation(self):
        self.write_csv(["a", "b", "c"], [["1", "2", "3"]])
        with patch.object(pipeline, "EXCEL_MAX_COLS", 2):
            self.convert(code=2)
        self.assertFalse(self.output.exists())

    def test_excel_actual_too_many_columns(self):
        headers = ["c" + str(n) for n in range(16385)]
        self.write_csv(headers, [])
        self.convert(code=2)
        self.assertFalse(self.output.exists())

    def test_invalid_sheet_names(self):
        self.write_csv()
        for sheet in ("", "x" * 32, "a/b", "a\\b", "a:b", "a*b", "a?b", "a[b", "a]b", "'a", "a'", "a\x01b", "a\nb", "a\rb", "a\tb", "𠀀" * 16, "History"):
            with self.subTest(sheet=repr(sheet)):
                self.convert("--sheet", sheet, code=2)
                self.assertFalse(self.output.exists())

    def test_valid_custom_sheet(self):
        headers, rows = self.write_csv()
        self.convert("--sheet", "合成数据")
        self.assertEqual(self.cells(sheet="合成数据"), [headers, *rows])

    def test_convert_requires_output_and_no_overwrite_flag(self):
        self.write_csv()
        self.cli("convert", "--survey", self.source, code=2)
        self.convert("--overwrite", code=2)
        self.assertFalse(self.output.exists())

    def test_convert_csv_only_xlsx_output_only(self):
        self.cli("convert", "--survey", self.city, "--output", self.output, code=2)
        self.write_csv()
        target = self.case / "not_excel.csv"
        self.cli("convert", "--survey", self.source, "--output", target, code=2)
        self.assertFalse(target.exists())

    def test_existing_output_unchanged(self):
        self.write_csv()
        self.output.write_bytes(b"synthetic-unrelated-file")
        before = pipeline.digest(self.output)
        self.convert(code=2)
        self.assertEqual(pipeline.digest(self.output), before)

    def test_output_source_same_path_unchanged(self):
        self.write_csv()
        before = pipeline.digest(self.source)
        self.cli("convert", "--survey", self.source, "--output", self.source, code=2)
        self.assertEqual(pipeline.digest(self.source), before)

    def test_target_symlink_and_dangling_symlink(self):
        self.write_csv()
        self.output.symlink_to(self.city)
        before = pipeline.digest(self.city)
        self.convert(code=2)
        self.assertTrue(self.output.is_symlink())
        self.assertEqual(pipeline.digest(self.city), before)
        self.output = self.case / "dangling.xlsx"
        self.output.symlink_to(self.case / "synthetic_missing.xlsx")
        self.convert(code=2)
        self.assertTrue(self.output.is_symlink())
        self.assertFalse((self.case / "synthetic_missing.xlsx").exists())

    def test_parent_symlink_rejected(self):
        self.write_csv()
        actual = self.case / "actual"
        actual.mkdir()
        link = self.case / "link"
        link.symlink_to(actual, target_is_directory=True)
        self.output = link / "new" / "converted.xlsx"
        self.convert(code=2)
        self.assertEqual(list(actual.iterdir()), [])
        self.wd = link / "work"
        self.prepare(code=2)
        self.assertEqual(list(actual.iterdir()), [])

    def test_dangling_parent_symlink_rejected(self):
        self.write_csv()
        link = self.case / "link"
        actual = self.case / "missing"
        link.symlink_to(actual, target_is_directory=True)
        self.output = link / "converted.xlsx"
        self.convert(code=2)
        self.assertFalse(actual.exists())

    def test_nested_new_parent_allowed_unrelated_preserved(self):
        self.write_csv()
        unrelated = self.case / "personal_synthetic.txt"
        unrelated.write_text("合成保留文件", encoding="utf-8")
        self.output = self.case / "new" / "nested" / "converted.xlsx"
        self.convert()
        self.assertTrue(self.output.is_file())
        self.assertEqual(unrelated.read_text(encoding="utf-8"), "合成保留文件")

    def test_non_directory_parent_rejected(self):
        self.write_csv()
        obstacle = self.case / "obstacle"
        obstacle.write_bytes(b"synthetic")
        self.output = obstacle / "converted.xlsx"
        self.convert(code=2)
        self.assertEqual(obstacle.read_bytes(), b"synthetic")

    def test_conversion_summary_no_record_values_or_demographics(self):
        self.write_csv(["Q1.您的性别是？", "OpenID"], [["男", "synthetic-secret-001"], ["男", "synthetic-secret-001"]])
        before = pipeline.digest(self.source)
        result = self.convert()
        self.assertEqual(result["rows"], 2)
        self.assertEqual(result["cols"], 2)
        self.assertNotIn("demographics", result)
        self.assertNotIn("weight", self.cells()[0])
        self.assertNotIn("synthetic-secret-001", json.dumps(result))
        self.assertTrue(result["source_unchanged"])
        self.assertTrue(result["verified"])
        self.assertEqual(result["source_sha256"], before)
        self.assertEqual(result["source_sha256_after"], before)
        self.assertEqual(pipeline.digest(self.source), before)
        self.assertEqual(pipeline.digest(self.output), result["output_sha256"])

    def test_serialization_verification_failure_no_output(self):
        self.write_csv()
        self.output = self.case / "new" / "converted.xlsx"
        with patch.object(pipeline, "verify_excel", side_effect=pipeline.CLIError("合成核验失败")):
            self.convert(code=2)
        self.assertFalse(self.output.parent.exists())

    def test_write_failure_rolls_back_only_created_file(self):
        self.write_csv()
        unrelated = self.case / "unrelated.xlsx"
        unrelated.write_bytes(b"synthetic-existing")
        with patch.object(pipeline.os, "fsync", side_effect=OSError("合成写入失败")):
            self.convert(code=2)
        self.assertFalse(self.output.exists())
        self.assertEqual(unrelated.read_bytes(), b"synthetic-existing")

    def test_exclusive_creation_race_keeps_other_file(self):
        self.write_csv()
        original = pipeline.create_bytes
        def competing_write(path, payload):
            Path(path).write_bytes(b"synthetic-concurrent-file")
            return original(path, payload)
        with patch.object(pipeline, "create_bytes", side_effect=competing_write):
            self.convert(code=2)
        self.assertEqual(self.output.read_bytes(), b"synthetic-concurrent-file")

    def test_source_changed_during_verification_rejected(self):
        self.write_csv()
        original = pipeline.verify_excel
        def mutate(*args, **kwargs):
            result = original(*args, **kwargs)
            self.source.write_bytes(b"a,b\nx,y\n")
            return result
        with patch.object(pipeline, "verify_excel", side_effect=mutate):
            self.convert(code=2)
        self.assertFalse(self.output.exists())

    def test_source_changed_after_creation_rolls_back(self):
        self.write_csv()
        original = pipeline.create_bytes
        def mutate(path, payload):
            identity = original(path, payload)
            self.source.write_bytes(b"a,b\nx,y\n")
            return identity
        with patch.object(pipeline, "create_bytes", side_effect=mutate):
            self.convert(code=2)
        self.assertFalse(self.output.exists())

    def test_prepare_conversion_config_and_inspect_location(self):
        headers, rows = self.write_csv()
        result = self.prepare()
        cfg = pipeline.read_json(self.wd / pipeline.CONFIG)
        conversion = cfg["conversion"]
        self.assertIsNone(cfg["sheet"])
        self.assertEqual(result["conversion"], conversion)
        self.assertEqual(conversion["output"], str(self.wd / pipeline.CONVERTED))
        self.assertEqual(conversion["source"], str(self.wd / "问卷数据表.csv"))
        self.assertEqual(conversion["report"], str(self.wd / pipeline.CONVERSION_REPORT))
        self.assertEqual(conversion["source_sha256"], cfg["source_sha256"])
        self.assertEqual(conversion["output_sha256"], pipeline.digest(self.wd / pipeline.CONVERTED))
        self.assertEqual(conversion["report_sha256"], pipeline.digest(self.wd / pipeline.CONVERSION_REPORT))
        inspected = self.cli("inspect", "--dir", self.wd)
        self.assertEqual(inspected["conversion"], conversion)
        self.assertEqual(self.cells(self.wd / pipeline.CONVERTED), [headers, *rows])
        self.assertEqual(self.source.read_bytes(), (self.wd / "问卷数据表.csv").read_bytes())

    def test_prepare_reuse_same_hash_no_reconversion_or_overwrite(self):
        self.write_csv()
        self.prepare()
        converted = self.wd / pipeline.CONVERTED
        report = self.wd / pipeline.CONVERSION_REPORT
        before = (pipeline.digest(converted), converted.stat().st_ino, converted.stat().st_mtime_ns,
                  pipeline.digest(report), report.stat().st_ino, report.stat().st_mtime_ns)
        with patch.object(pipeline, "serialize_conversion", side_effect=AssertionError("不能重转")):
            self.prepare()
            self.cli("prepare", "--dir", self.wd, "--survey", self.wd / "问卷数据表.csv")
        after = (pipeline.digest(converted), converted.stat().st_ino, converted.stat().st_mtime_ns,
                 pipeline.digest(report), report.stat().st_ino, report.stat().st_mtime_ns)
        self.assertEqual(after, before)

    def test_prepare_custom_sheet_persists_and_different_sheet_rejected(self):
        self.write_csv()
        self.prepare("--sheet", "合成问卷")
        self.assertEqual(self.prepare()["conversion"]["sheet"], "合成问卷")
        before = self.snapshot()
        self.prepare("--sheet", "data", code=2)
        self.assertEqual(self.snapshot(), before)
        self.assertIsNone(pipeline.read_json(self.wd / pipeline.CONFIG)["sheet"])

    def test_prepare_invalid_sheet_no_copies(self):
        self.write_csv()
        self.prepare("--sheet", "bad/sheet", code=2)
        self.assertFalse(self.wd.exists())

    def test_prepare_mapping_and_attention_errors_before_copy(self):
        self.write_csv()
        self.prepare("--demo-map", "[]", code=2)
        self.assertFalse(self.wd.exists())
        self.prepare("--demo-map", '{"性别":"没有此列"}', code=2)
        self.assertFalse(self.wd.exists())
        with patch.object(pipeline, "attention_report", side_effect=pipeline.CLIError("合成专注度参数错误")):
            self.prepare(code=2)
        self.assertFalse(self.wd.exists())

    def test_prepare_foreign_conversion_and_report_rejected(self):
        self.write_csv()
        self.wd.mkdir()
        for name in (pipeline.CONVERTED, pipeline.CONVERSION_REPORT):
            target = self.wd / name
            target.write_bytes(b"synthetic-unowned")
            before = self.snapshot()
            self.prepare(code=2)
            self.assertEqual(self.snapshot(), before)
            self.assertFalse((self.wd / "问卷数据表.csv").exists())
            target.unlink()

    def test_prepare_foreign_conversion_symlink_rejected(self):
        self.write_csv()
        self.wd.mkdir()
        target = self.wd / pipeline.CONVERTED
        target.symlink_to(self.city)
        before = self.snapshot()
        self.prepare(code=2)
        self.assertEqual(self.snapshot(), before)

    def test_prepare_failure_rolls_back_new_batch(self):
        self.write_csv()
        self.wd.mkdir()
        unrelated = self.wd / "unrelated.txt"
        unrelated.write_bytes(b"synthetic-existing")
        original = pipeline.create_bytes
        def fail_report(path, payload):
            if Path(path).name == pipeline.CONVERSION_REPORT:
                raise OSError("合成报告写入失败")
            return original(path, payload)
        with patch.object(pipeline, "create_bytes", side_effect=fail_report):
            self.prepare(code=2)
        self.assertEqual(self.snapshot(), {"unrelated.txt": pipeline.digest(unrelated)})

    def test_tampered_converted_xlsx_blocks_all_consumers(self):
        self.write_csv()
        self.prepare()
        target = self.wd / pipeline.CONVERTED
        book = load_workbook(target)
        book["data"]["A2"] = "合成修改"
        book.save(target)
        book.close()
        self.assert_blocked_consumers()

    def test_tampered_csv_copy_blocks_all_consumers(self):
        self.write_csv()
        self.prepare()
        (self.wd / "问卷数据表.csv").write_bytes(b"a,b\nx,y\n")
        self.assert_blocked_consumers()

    def test_tampered_original_blocks_prepare(self):
        self.write_csv()
        self.prepare()
        self.source.write_bytes(b"a,b\nx,y\n")
        before = self.snapshot()
        self.prepare(code=2)
        self.assertEqual(self.snapshot(), before)

    def test_tampered_report_blocks_all_consumers(self):
        self.write_csv()
        self.prepare()
        report = self.wd / pipeline.CONVERSION_REPORT
        report.write_bytes(report.read_bytes() + b" ")
        self.assert_blocked_consumers()

    def test_replaced_conversion_symlink_blocks(self):
        self.write_csv()
        self.prepare()
        target = self.wd / pipeline.CONVERTED
        target.unlink()
        target.symlink_to(self.city)
        self.assert_blocked_consumers()

    def test_replaced_report_symlink_blocks(self):
        self.write_csv()
        self.prepare()
        target = self.wd / pipeline.CONVERSION_REPORT
        target.unlink()
        target.symlink_to(self.city)
        self.assert_blocked_consumers()

    def test_unowned_files_on_legacy_cfg_block_no_change(self):
        self.legacy()
        (self.wd / pipeline.CONVERSION_REPORT).write_bytes(b"synthetic-unowned")
        self.assert_blocked_consumers()

    def test_conversion_hash_alone_not_trusted(self):
        self.write_csv()
        self.prepare()
        target = self.wd / pipeline.CONVERTED
        book = load_workbook(target)
        book["data"]["A2"] = "改写后的合成答案"
        book.save(target)
        book.close()
        cfg = pipeline.read_json(self.wd / pipeline.CONFIG)
        cfg["conversion"]["output_sha256"] = pipeline.digest(target)
        report = {k: v for k, v in cfg["conversion"].items() if k not in ("report", "report_sha256")}
        pipeline.write_json(self.wd / pipeline.CONVERSION_REPORT, report)
        cfg["conversion"]["report_sha256"] = pipeline.digest(self.wd / pipeline.CONVERSION_REPORT)
        pipeline.write_json(self.wd / pipeline.CONFIG, cfg)
        before = self.snapshot()
        result = self.cli("inspect", "--dir", self.wd, code=2)
        self.assertIn("回读", result["error"])
        self.assertEqual(self.snapshot(), before)

    def test_legacy_csv_inspect_clean_and_migrate(self):
        self.legacy(["Q1.备注？", "记录"], [["001", "x"], ["", ""]])
        inspected = self.cli("inspect", "--dir", self.wd)
        self.assertFalse(inspected["conversion"]["converted"])
        self.assertEqual(inspected["survey"]["rows"], 2)
        cleaned = self.cli("clean", "--dir", self.wd)
        self.assertEqual(cleaned["stats"]["final_count"], 2)
        merged = self.wd / "问卷数据表_merged.xlsx"
        before = pipeline.digest(merged)
        copy_hash = pipeline.digest(self.wd / "问卷数据表.csv")
        self.prepare("--sheet", "迁移数据")
        self.assertEqual(pipeline.digest(merged), before)
        self.assertEqual(pipeline.digest(self.wd / "问卷数据表.csv"), copy_hash)
        self.assertTrue(self.cli("inspect", "--dir", self.wd)["conversion"]["converted"])
        self.assertEqual(self.cells(self.wd / pipeline.CONVERTED, "迁移数据"), [["Q1.备注？", "记录"], ["001", "x"], ["", ""]])

    def test_legacy_migration_failure_keeps_cfg_and_data(self):
        self.legacy()
        before = self.snapshot()
        original = pipeline.create_bytes
        def fail_report(path, payload):
            if Path(path).name == pipeline.CONVERSION_REPORT:
                raise OSError("合成迁移失败")
            return original(path, payload)
        with patch.object(pipeline, "create_bytes", side_effect=fail_report):
            self.prepare(code=2)
        self.assertEqual(self.snapshot(), before)

    def test_xlsx_sheet_workflow_unchanged(self):
        self.source = self.case / "synthetic.xlsx"
        with pd.ExcelWriter(self.source) as writer:
            pd.DataFrame({"Q1.备注？": ["甲"]}).to_excel(writer, sheet_name="其他", index=False)
            pd.DataFrame({"Q2.您的性别是？": ["女", "男"]}).to_excel(writer, sheet_name="问卷", index=False)
        before = pipeline.digest(self.source)
        result = self.prepare("--sheet", "问卷")
        self.assertNotIn("conversion", result)
        self.assertEqual(pipeline.read_json(self.wd / pipeline.CONFIG)["sheet"], "问卷")
        self.assertFalse((self.wd / pipeline.CONVERTED).exists())
        self.assertFalse((self.wd / pipeline.CONVERSION_REPORT).exists())
        self.cli("clean", "--dir", self.wd)
        frame = pd.read_excel(self.wd / "问卷数据表_merged.xlsx", keep_default_na=False)
        self.assertEqual(frame["性别"].tolist(), ["B.女", "A.男"])
        self.assertEqual(pipeline.digest(self.source), before)

    def test_prepare_questions_clean_use_conversion_with_empty_tail(self):
        self.write_csv(["Q1.备注？", "记录"], [["001", "x"], ["NA", "NULL"], ["", ""], ["", ""]])
        self.prepare()
        before = pipeline.digest(self.wd / pipeline.CONVERTED)
        questions = self.cli("questions", "--dir", self.wd, "--q", "1")
        self.assertEqual(questions["questions"][0]["options"], ["001", "NA"])
        cleaned = self.cli("clean", "--dir", self.wd)
        self.assertEqual(cleaned["stats"]["final_count"], 4)
        merged = self.cells(self.wd / "问卷数据表_merged.xlsx", literal=False)
        self.assertEqual([row[:2] for row in merged[1:]], [["001", "x"], ["NA", "NULL"], ["", ""], ["", ""]])
        self.assertEqual(pipeline.digest(self.wd / pipeline.CONVERTED), before)
        self.cli("clean", "--dir", self.wd, "--filter-rule", "Q1.备注？ == 001")
        self.assertEqual(self.cli("clean", "--dir", self.wd)["stats"]["raw_survey_count"], 4)

    def test_read_table_strict_csv_empty_tail_and_text(self):
        self.write_csv(["a", "b"], [["001", "NA"], ["", ""]])
        raw, encoding = pipeline.read_table(self.source)
        self.assertEqual(raw.values.tolist(), [["001", "NA"], ["", ""]])
        self.assertEqual(encoding, "utf-8-sig")
        self.text_csv("a,b\nx\n")
        with self.assertRaises(pipeline.CLIError):
            pipeline.read_table(self.source)

    def test_convert_prepare_clean_gender_only_ipf_end_to_end(self):
        headers = ["Q1.您的性别是？", "Q2.备注？", "合成标识"]
        rows = [["男" if n < 13 else "女", "=1+1" if n == 0 else "NA", f"{n:03d}"] for n in range(20)]
        self.write_csv(headers, rows)
        source_hash = pipeline.digest(self.source)
        self.convert()
        self.assertEqual(self.cells(), [headers, *rows])
        self.source = self.output
        self.prepare("--sheet", "data")
        cleaned = self.cli("clean", "--dir", self.wd)
        self.assertEqual(cleaned["stats"]["final_count"], 20)
        output = self.case / "synthetic_weight"
        completed = subprocess.run([sys.executable, str(SCRIPTS / "survey_weight.py"),
                                    "--file", str(self.wd / "问卷数据表_merged.xlsx"), "--sheet", "data",
                                    "--dim", "性别|A.男,B.女|50.4,49.6", "--output-dir", str(output)],
                                   capture_output=True, text=True)
        self.assertEqual(completed.returncode, 0, completed.stdout + completed.stderr)
        frame = pd.read_excel(output / "加权后数据.xlsx", dtype=object, keep_default_na=False)
        self.assertEqual(len(frame), 20)
        self.assertEqual(frame["合成标识"].tolist(), [f"{n:03d}" for n in range(20)])
        self.assertEqual(frame["Q2.备注？"].tolist(), [row[1] for row in rows])
        weights = frame["weight"].astype(float)
        self.assertAlmostEqual(weights.mean(), 1.0, places=10)
        for value, target in (("A.男", 50.4), ("B.女", 49.6)):
            actual = weights[frame["性别"] == value].sum() / weights.sum() * 100
            self.assertLess(abs(actual - target), 0.01)
        self.assertEqual(pipeline.digest(self.case / "synthetic.csv"), source_hash)


    def test_utf16_cell_length_guard(self):
        self.write_csv(rows=[["𠀀" * 16384, "001"]])
        self.convert(code=2)
        self.assertFalse(self.output.exists())

    def test_readonly_source_hash_and_metadata_unchanged(self):
        self.write_csv()
        self.source.chmod(0o444)
        before = self.source.stat()
        fingerprint = pipeline.digest(self.source)
        self.convert()
        after = self.source.stat()
        self.assertEqual((after.st_mode, after.st_size, after.st_mtime_ns),
                         (before.st_mode, before.st_size, before.st_mtime_ns))
        self.assertEqual(pipeline.digest(self.source), fingerprint)

    def test_empty_existing_config_rejected_without_overwrite(self):
        self.write_csv()
        self.wd.mkdir()
        pipeline.write_json(self.wd / pipeline.CONFIG, {})
        before = self.snapshot()
        self.prepare(code=2)
        self.assertEqual(self.snapshot(), before)

    def test_migration_config_replace_failure_restores_mapping_and_data(self):
        self.legacy()
        before = self.snapshot()
        original = pipeline.os.replace
        def fail_config(src, dst, **kwargs):
            if dst == pipeline.CONFIG:
                raise OSError("合成配置提交失败")
            return original(src, dst, **kwargs)
        with patch.object(pipeline.os, "replace", side_effect=fail_config):
            self.prepare("--reference-year", "2020", code=2)
        self.assertEqual(self.snapshot(), before)

    def test_new_prepare_config_failure_rolls_back_all_created(self):
        self.write_csv()
        original = pipeline.create_bytes
        def fail_config(path, payload):
            if Path(path).name == pipeline.CONFIG:
                raise OSError("合成配置写入失败")
            return original(path, payload)
        with patch.object(pipeline, "create_bytes", side_effect=fail_config):
            self.prepare(code=2)
        self.assertEqual(self.snapshot(), {})

    def test_inconsistent_source_after_hash_rejected(self):
        self.write_csv()
        self.prepare()
        cfg = pipeline.read_json(self.wd / pipeline.CONFIG)
        cfg["conversion"]["source_sha256_after"] = "0" * 64
        report = {k: v for k, v in cfg["conversion"].items() if k not in ("report", "report_sha256")}
        pipeline.write_json(self.wd / pipeline.CONVERSION_REPORT, report)
        cfg["conversion"]["report_sha256"] = pipeline.digest(self.wd / pipeline.CONVERSION_REPORT)
        pipeline.write_json(self.wd / pipeline.CONFIG, cfg)
        self.assert_blocked_consumers()

    def test_excel_verifier_rejects_formula_numeric_and_extra_rows(self):
        for value in ("=1+1", 123, "普通"):
            with self.subTest(value=value):
                book = Workbook()
                book.active.title = "data"
                book.active.append(["a", "b"])
                book.active.append([value, "001"])
                if value == "普通":
                    book.active.append(["额外记录", "002"])
                buffer = io.BytesIO()
                book.save(buffer)
                book.close()
                with self.assertRaises(pipeline.CLIError):
                    pipeline.verify_excel(io.BytesIO(buffer.getvalue()), ["a", "b"], [["普通", "001"]], "data")


def main():
    global ROOT
    default_parent = str(Path(tempfile.gettempdir()).resolve())
    parent = Path(os.environ.get("SURVEY_LITE_TEST_OUTPUT", default_parent)).expanduser().absolute()
    if not parent.is_dir() or parent.is_symlink():
        raise RuntimeError("测试父目录必须已存在且不是软链")
    pipeline.check_parent_chain(parent)
    ROOT = parent / ("synthetic_csv_run_" + datetime.now().strftime("%Y%m%d_%H%M%S_%f") + "_" + uuid4().hex[:8])
    ROOT.mkdir()
    suite = unittest.defaultTestLoader.loadTestsFromTestCase(CsvConversionTests)
    result = unittest.TextTestRunner(verbosity=2).run(suite)
    print("@@TEST_RESULT@@ " + json.dumps({"synthetic_only": True, "run_dir": str(ROOT),
                                           "tests_run": result.testsRun, "passed": result.testsRun - len(result.failures) - len(result.errors),
                                           "failures": len(result.failures), "errors": len(result.errors)}, ensure_ascii=False))
    return 0 if result.wasSuccessful() else 1


if __name__ == "__main__":
    sys.exit(main())
