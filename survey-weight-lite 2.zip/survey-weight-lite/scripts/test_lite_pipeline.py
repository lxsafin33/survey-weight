#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""仅使用独立目录内的合成数据，不读取问卷或外部用户数据。"""
import contextlib
import hashlib
import io
import itertools
import json
import os
import subprocess
import sys
import tempfile
import unittest
from datetime import datetime
from pathlib import Path
from uuid import uuid4

import numpy as np
import pandas as pd

import clean_pipeline as pipeline
from demographic_detection import detect

SCRIPTS = Path(__file__).resolve().parent
DEFAULT_OUTPUT = Path(tempfile.gettempdir()) / "survey-weight-lite-tests"
ROOT = None
WEIGHT_RESULTS = []


def fingerprint(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


class LitePipelineTests(unittest.TestCase):
    def setUp(self):
        self.case = ROOT / (self._testMethodName + "_" + uuid4().hex[:8])
        self.case.mkdir()
        self.wd = self.case / "work"

    def cli(self, command, *args, code=0):
        args = list(map(str, args))
        if command == "prepare" and "--city-file" not in args:
            city = self.case / "synthetic_city.xlsx"
            if not city.exists():
                pd.DataFrame({"城市名": ["合成城市市"], "城市分级": ["合成分级"]}).to_excel(city, index=False)
            args.extend(["--city-file", str(city)])
        output = io.StringIO()
        with contextlib.redirect_stdout(output):
            status = pipeline.main([command, *args])
        lines = output.getvalue().splitlines()
        self.assertTrue(lines[-1].startswith("@@RESULT@@ "), output.getvalue())
        result = json.loads(lines[-1].split("@@RESULT@@ ", 1)[1])
        self.assertEqual(status, code, result)
        self.assertEqual(result["ok"], code == 0, result)
        return result

    def prepare(self, data, *args, csv=False, encoding="utf-8-sig"):
        source = self.case / ("synthetic.csv" if csv else "synthetic.xlsx")
        frame = pd.DataFrame(data)
        # 真实问卷空答案行仍有记录元数据；序号确保夹具空答案不是Excel末尾空白区域。
        frame["合成记录序号"] = range(1, len(frame) + 1)
        if csv:
            frame.to_csv(source, index=False, encoding=encoding)
        else:
            frame.to_excel(source, sheet_name="合成问卷", index=False)
        before = fingerprint(source)
        result = self.cli("prepare", "--dir", self.wd, "--survey", source, *args)
        self.assertEqual(fingerprint(source), before)
        self.source = source
        return result

    def clean(self, *args, code=0):
        return self.cli("clean", "--dir", self.wd, *args, code=code)

    def data(self):
        return pd.read_excel(self.wd / "问卷数据表_merged.xlsx", sheet_name="data", keep_default_na=False)

    def blocked_unchanged(self, *args):
        before = {p.name: fingerprint(p) for p in self.wd.iterdir() if p.is_file()}
        result = self.clean(*args, code=2)
        self.assertTrue(result["needs_confirmation"])
        self.assertTrue(result["data_unchanged"])
        self.assertEqual({p.name: fingerprint(p) for p in self.wd.iterdir() if p.is_file()}, before)
        return result

    def test_basic_41_no_id_no_person_guess(self):
        result = self.prepare({"编号": list(range(41)), "昵称": ["合成昵称"] * 41,
                               "IP": ["127.0.0.1"] * 41, "Q42.喜爱的口味？": ["A.清淡"] * 41,
                               "答题时长": [1] * 41, "UA": ["合成UA"] * 41})
        self.assertEqual(result["mode"], "basic")
        before = fingerprint(self.source)
        cleaned = self.clean()
        self.assertEqual(cleaned["stats"]["final_count"], 41)
        self.assertEqual(cleaned["identity"]["column"], None)
        self.assertEqual(len(cleaned["stats"]["skipped_rules"]), 10)
        self.assertTrue({"编号", "昵称", "IP", "UA"} <= set(self.data().columns))
        self.assertEqual(fingerprint(self.source), before)
        self.assertNotIn("register", json.dumps(cleaned))

    def test_gender_only_detail(self):
        result = self.prepare({"Q42.您的性别是？": ["男", "女"]})
        self.assertEqual(result["mode"], "detail")
        result = self.clean()
        self.assertEqual(result["stats"]["demo_checked"], ["性别"])
        self.assertEqual(self.data()["性别"].tolist(), ["A.男", "B.女"])
        self.assertEqual(len(result["stats"]["skipped_rules"]), 10)

    def test_optional_city_and_urban_only(self):
        self.prepare({"城乡": ["城市", ""], "Q42.您的城市是？": ["合成城市", ""]})
        result = self.clean()
        self.assertEqual(result["mode"], "questionnaire")
        self.assertEqual(result["stats"]["final_count"], 2)
        self.assertEqual(result["stats"]["demo_checked"], [])

    def test_city_resource_synthetic(self):
        city = self.case / "synthetic_city.xlsx"
        pd.DataFrame({"城市名": ["合成城市市"], "城市分级": ["合成分级"]}).to_excel(city, index=False)
        self.prepare({"城市": ["合成城市", ""]}, "--city-file", city)
        result = self.clean()
        self.assertEqual(result["stats"]["city_level_filled"], 1)
        self.assertEqual(self.data()["城市分级"].tolist(), ["合成分级", ""])

    def test_all_fields_normalization_and_questions_preserved(self):
        source = {"Q42.您的性别是？": ["A.男性", "B.女性"], "第43题您今年多少岁？": ["25岁", "40"],
                  "44.您的最高学历是什么？": ["大专", "本科"], "45.您目前从事的职业是？": ["AF.服务人员", "高校教师"],
                  "编号": ["保留一", "保留二"], "Q46.口味选择？": ["A.清淡", "B.浓郁"]}
        self.prepare(source)
        result = self.clean()
        data = self.data()
        for column, values in source.items():
            self.assertEqual(data[column].tolist(), values)
        self.assertEqual(data["职业"].tolist(), ["服务人员", "高校教师"])
        self.assertEqual(data["学历"].tolist(), ["C.大学专科", "D.大学本科"])
        self.assertEqual(data["年龄分段"].tolist(), ["30岁以下", "40-49岁"])
        self.assertEqual(result["stats"]["final_count"], 2)

    def test_age_zero_not_missing(self):
        self.prepare({"年龄": [0, "0岁", ""], "Q42.口味？": ["A.清淡"] * 3})
        self.blocked_unchanged("--rules", "none")
        result = self.clean("--rules", "none", "--confirm-demo-completeness")
        self.assertEqual(result["stats"]["final_count"], 2)
        self.assertEqual(self.data()["年龄"].tolist(), [0, 0])
        self.assertEqual(self.data()["年龄分段"].tolist(), ["30岁以下"] * 2)

    def test_existing_age_band_preserved_and_no_fake_age(self):
        self.prepare({"Q42.您的年龄范围是？": ["A.18-29岁", "B.30-49岁"]})
        self.clean()
        self.assertNotIn("年龄", self.data())
        self.assertEqual(self.data()["年龄分段"].tolist(), ["18-29岁", "30-49岁"])
        result = self.clean("--age-groups", "30岁以下,30-39岁,40-49岁,50岁及以上")
        self.assertEqual(self.data()["年龄分段"].tolist(), ["18-29岁", "30-49岁"])
        self.assertTrue(any("不能" in w for w in result["warnings"]))

    def test_age_in_standard_column_is_band_not_age(self):
        self.prepare({"年龄": ["18-29岁", "30-49岁"]})
        result = self.clean()
        self.assertEqual(self.data()["年龄"].tolist(), ["18-29岁", "30-49岁"])
        self.assertNotIn("年龄", result["demographics"]["available_core_fields"])
        self.assertEqual(len(result["stats"]["skipped_rules"]), 10)

    def test_birth_year_reference_and_current_year_report(self):
        self.prepare({"第42题您的出生年份是？": [2000, 2020]}, "--reference-year", "2020")
        self.clean()
        self.assertEqual(self.data()["年龄"].tolist(), [20, 0])
        inspected = self.cli("inspect", "--dir", self.wd)
        self.assertEqual(inspected["demographics"]["reference_year"], 2020)
        self.assertEqual(inspected["demographics"]["reference_year_source"], "explicit")
        report = detect(pd.DataFrame({"出生年份": [2000]}))
        self.assertEqual(report["reference_year"], datetime.now().year)
        self.assertEqual(report["reference_year_source"], "current_year")
        self.assertTrue(any("未考虑生日" in w for w in report["warnings"]))

    def test_legacy_age_birth_year_original_retained(self):
        self.prepare({"年龄": [2000, 2020]}, "--reference-year", 2020)
        self.clean()
        self.assertEqual(self.data()["年龄"].tolist(), [20, 0])
        self.assertEqual(self.data()["原始_年龄"].tolist(), [2000, 2020])

    def test_unknown_codes_block_and_persist_confirmed_maps(self):
        self.prepare({"性别": [1, 2]})
        self.blocked_unchanged()
        mapping = json.dumps({"性别": {"1": "女", "2": "男"}}, ensure_ascii=False)
        self.cli("prepare", "--dir", self.wd, "--survey", self.source, "--demo-value-map", mapping)
        self.clean()
        self.assertEqual(self.data()["性别"].tolist(), ["B.女", "A.男"])
        self.assertEqual(self.data()["原始_性别"].tolist(), [1, 2])
        self.assertIn("demo_value_map", json.loads((self.wd / pipeline.MAPPING).read_text()))

    def test_unrecognized_question_manual_map_and_ephemeral_override(self):
        self.prepare({"Q42.个人资料项甲？": ["甲", "乙"]})
        mapping = json.dumps({"性别": "Q42.个人资料项甲？"}, ensure_ascii=False)
        values = json.dumps({"性别": {"甲": "男", "乙": "女"}}, ensure_ascii=False)
        self.cli("prepare", "--dir", self.wd, "--survey", self.source, "--demo-map", mapping, "--demo-value-map", values)
        saved = fingerprint(self.wd / pipeline.MAPPING)
        override = json.dumps({"性别": {"甲": "女", "乙": "男"}}, ensure_ascii=False)
        self.cli("inspect", "--dir", self.wd, "--demo-value-map", override)
        self.clean("--demo-value-map", override)
        self.assertEqual(self.data()["性别"].tolist(), ["B.女", "A.男"])
        self.assertEqual(fingerprint(self.wd / pipeline.MAPPING), saved)
        self.clean()
        self.assertEqual(self.data()["性别"].tolist(), ["A.男", "B.女"])

    def test_duplicate_population_candidates_confirmation(self):
        self.prepare({"性别": ["男", "女"], "Q42.您的性别是？": ["女", "男"]})
        self.blocked_unchanged()
        self.clean("--demo-map", json.dumps({"性别": "Q42.您的性别是？"}, ensure_ascii=False))
        self.assertEqual(self.data()["Q42.您的性别是？"].tolist(), ["女", "男"])
        self.assertEqual(self.data()["原始_性别"].tolist(), ["男", "女"])

    def test_age_birth_and_band_conflicts_block(self):
        self.prepare({"年龄": [20], "出生年份": [2000], "年龄分段": ["30-39岁"]}, "--reference-year", 2026)
        result = self.blocked_unchanged("--rules", "none")
        self.assertTrue(any("矛盾" in reason for reason in result["confirmation_reasons"]))

    def test_mixed_age_codes_block(self):
        self.prepare({"年龄": [20, "30-39岁"]})
        self.blocked_unchanged()

    def test_missing_optional_all_empty_core_and_completeness_consent(self):
        self.prepare({"性别": ["男", ""], "学历": ["", ""], "城市": ["", "合成城市"]})
        self.blocked_unchanged()
        result = self.clean("--no-demo-completeness")
        self.assertEqual(result["stats"]["final_count"], 2)
        result = self.clean("--confirm-demo-completeness")
        self.assertEqual(result["stats"]["final_count"], 1)
        self.assertEqual(result["stats"]["demo_checked"], ["性别"])

    def test_nonempty_id_latest_and_missing_not_deduped(self):
        self.prepare({"OpenID": ["synthetic-id-1", "synthetic-id-1", "", "", "synthetic-id-2", "synthetic-id-2"],
                      "结束答题时间": ["2026-01-02", "2026-01-01", "", "", "invalid", "2026-02-01"],
                      "Q42.口味？": ["一", "二", "三", "四", "五", "六"]})
        result = self.clean()
        self.assertEqual(self.data()["Q42.口味？"].tolist(), ["一", "三", "四", "六"])
        self.assertEqual(result["stats"]["survey_dedupe_removed"], 2)
        self.assertEqual(result["stats"]["dedupe_time_fallback_groups"], 1)
        self.assertEqual(result["stats"]["id_missing_count"], 2)
        self.assertNotIn("synthetic-id-1", json.dumps(result))
        removed = pd.read_excel(result["outputs"]["removed"])
        self.assertEqual(removed[pipeline.REF].tolist(), [3, 6])
        result = self.clean("--drop-empty-id")
        self.assertEqual(result["stats"]["empty_openid_removed"], 2)
        self.assertEqual(result["stats"]["final_count"], 2)

    def test_dedupe_ties_and_no_time_last(self):
        self.prepare({"openid": ["id-a", "id-a", "id-b", "id-b"], "Q42.口味？": ["一", "二", "三", "四"]})
        self.clean()
        self.assertEqual(self.data()["Q42.口味？"].tolist(), ["二", "四"])

    def test_explicit_id_and_custom_key_extraction_only(self):
        self.prepare({"自定义字段": ["openid=synthetic-a;extra=x", '{"OpenID":"synthetic-a"}', "随意文本", "随意文本"]})
        result = self.clean()
        self.assertEqual(result["identity"]["method"], "explicit_openid_key")
        self.assertEqual(result["stats"]["final_count"], 3)
        result = self.clean("--id-column", "自定义字段")
        self.assertEqual(result["stats"]["final_count"], 3)

    def test_duplicate_id_fields_block(self):
        self.prepare({"openid": ["a"], "OpenID": ["b"]})
        self.blocked_unchanged()
        self.clean("--id-column", "openid")

    def test_duration_only_explicit_threshold(self):
        self.prepare({"耗时": ["1秒", "2分3秒", "bad", "", "00:01:01"]})
        result = self.clean()
        self.assertEqual(result["stats"]["final_count"], 5)
        result = self.clean("--min-duration-seconds", 60, "--duration-column", "耗时")
        self.assertEqual(result["stats"]["duration_removed"], 1)
        self.assertEqual(result["stats"]["final_count"], 4)
        self.clean("--min-duration-seconds", "nan", "--duration-column", "耗时", code=2)
        self.clean("--drop-empty-id", code=2)

    def test_all_ten_rules_one_hit_each_and_occupation_not_guessed(self):
        rows = [
            (16, "本科", "服务人员", "男"), (20, "硕士", "服务人员", "男"),
            (18, "初中", "在校学生", "男"), (22, "高中", "在校学生", "男"),
            (36, "大专", "在校学生", "男"), (17, "初中", "公务员", "男"),
            (20, "初中", "专业人员", "男"), (15, "初中", "工人", "男"),
            (59, "初中", "退休人员", "男"), (49, "初中", "退休人员", "女"),
            (15, "初中", "高校教师", "女"), (25, "本科", "服务人员", "女")]
        self.prepare(pd.DataFrame(rows, columns=["年龄", "学历", "职业", "性别"]))
        result = self.clean()
        self.assertEqual(result["stats"]["abnormal_removed"], 10)
        self.assertEqual(list(result["stats"]["abnormal_stats"].values()), [1] * 10)
        self.assertEqual(self.data()["职业"].tolist(), ["高校教师", "服务人员"])
        self.assertEqual(result["stats"]["skipped_rules"], [])
        result = self.clean("--rules", "")
        self.assertEqual(result["stats"]["final_count"], 12)
        result = self.clean("--rules", "none")
        self.assertEqual(result["stats"]["final_count"], 12)
        result = self.clean("--rules", "1,2", "--disable-rules", "2")
        self.assertEqual(result["stats"]["abnormal_removed"], 1)
        self.clean("--rules", "未知规则", code=2)

    def test_merged_education_rules_skipped(self):
        self.prepare({"年龄": [15, 20], "学历": ["本科及以上", "研究生"], "职业": ["服务人员", "服务人员"]})
        result = self.clean()
        self.assertEqual(result["stats"]["abnormal_removed"], 0)
        self.assertTrue(any("合并学历" in r["reason"] for r in result["stats"]["skipped_rules"]))

    def test_attention_auto_requires_consent_including_blank(self):
        col = "Q42.为检验专注度，请选择第2个选项？"
        self.prepare({col: ["A.甲", "B.乙", ""]})
        result = self.blocked_unchanged()
        self.assertEqual(result["attention_check"]["correct_answer"], "B.乙")
        result = self.clean("--confirm-attention-check")
        self.assertEqual(result["stats"]["attention_removed"], 2)
        self.assertEqual(self.data()[col].tolist(), ["B.乙"])
        result = self.clean("--confirm-attention-check", "--attention-skip-empty")
        self.assertEqual(result["stats"]["final_count"], 2)
        result = self.clean("--no-attention-check")
        self.assertEqual(result["stats"]["final_count"], 3)

    def test_attention_choose_letter_without_keyword(self):
        col = "第42题选B"
        self.prepare({col: ["A.甲", "B.乙"]})
        result = self.clean("--confirm-attention-check")
        self.assertEqual(result["stats"]["attention_removed"], 1)

    def test_attention_manual_multiple_and_unknown(self):
        first = "Q42.认真回答检验？"
        second = "Q43.专注度，请选B？"
        self.prepare({first: ["A.甲", "B.乙"], second: ["A.甲", "B.乙"]})
        self.blocked_unchanged("--confirm-attention-check")
        self.blocked_unchanged("--attention-column", first, "--confirm-attention-check")
        result = self.clean("--attention-column", first, "--attention-option", "B.乙", "--confirm-attention-check")
        self.assertEqual(result["stats"]["final_count"], 1)
        self.clean("--no-attention-check")
        self.clean("--attention-column", "没有的题", "--attention-option", "B", code=2)

    def test_attention_no_numeric_guess_and_duplicate_letter(self):
        col = "Q42.专注度，请选第二个选项？"
        self.prepare({col: [1, 2]})
        self.blocked_unchanged("--confirm-attention-check")
        self.clean("--attention-option", "2", "--confirm-attention-check")
        report = pipeline.attention_report(pd.DataFrame({col: ["B.甲", "B.乙"]}))
        self.assertTrue(report["needs_confirmation"])

    def test_attention_skip_logic_not_wrong(self):
        col = "Q42.专注度，如果适用请选B？"
        self.prepare({col: ["A.甲", "B.乙", "不适用", ""]})
        self.blocked_unchanged("--confirm-attention-check")
        self.blocked_unchanged("--attention-column", col, "--confirm-attention-check")
        result = self.clean("--attention-column", col, "--attention-skip-option", "不适用",
                            "--attention-skip-empty", "--confirm-attention-check")
        self.assertEqual(result["stats"]["final_count"], 3)

    def test_custom_actual_option_validated_before_outputs(self):
        col = "Q42.您的性别是？"
        self.prepare({col: ["男", "女"]})
        self.clean("--filter-rule", col + " == A.男", code=2)
        self.assertFalse((self.wd / "问卷数据表_merged.xlsx").exists())
        result = self.clean("--filter-rule", "42.您的性别是？ == 男")
        self.assertEqual(result["stats"]["final_count"], 1)
        self.assertEqual(self.data()[col].tolist(), ["女"])
        result = self.clean("--filter-rule", "第42题您的性别是？ != 男")
        self.assertEqual(self.data()[col].tolist(), ["男"])
        self.clean("--filter-rule", "Q42.错误题干 == 男", code=2)
        self.clean("--filter-rule", "Q99.不存在 == 男", code=2)

    def test_custom_and_or_keep_mask_legacy_semantics(self):
        first, second = "Q42.口味？", "第43题颜色？"
        self.prepare({first: ["甲", "甲", "乙", "乙"], second: ["白", "黑", "白", "黑"]})
        result = self.clean("--filter-rule", first + " == 甲 AND " + second + " == 白")
        self.assertEqual(result["stats"]["final_count"], 1)
        self.assertEqual(self.data()[first].tolist(), ["乙"])
        self.assertEqual(self.data()[second].tolist(), ["黑"])
        result = self.clean("--filter-rule", first + " == 甲 OR " + second + " == 白")
        self.assertEqual(result["stats"]["final_count"], 3)
        result = self.clean("--filter-rule", first + " != 甲 AND " + second + " != 白")
        self.assertEqual(result["stats"]["final_count"], 1)
        self.assertEqual(self.data()[first].tolist(), ["甲"])

    def test_rerun_stable_prevalidated_options_no_accumulation(self):
        self.prepare({"openid": ["a", "a", "b", ""], "Q42.口味？": ["甲", "乙", "甲", "乙"]})
        result = self.clean("--filter-rule", "Q42.口味？ == 甲")
        first = self.data()
        second = self.clean("--steps", "4,5", "--filter-rule", "Q42.口味？ == 甲")
        pd.testing.assert_frame_equal(first, self.data())
        self.assertEqual(result["stats"], second["stats"])
        self.assertNotEqual(result["outputs"]["removed"], second["outputs"]["removed"])
        self.assertTrue(Path(result["outputs"]["removed"]).exists())
        self.clean("--filter-rule", "Q42.口味？ == 甲", "--filter-rule", "Q42.口味？ != 甲")
        self.assertEqual(len(self.data()), 0)
        self.clean("--steps", "5", code=2)

    def test_gb18030_and_multiline_record_count(self):
        col = "Q42.口味？"
        result = self.prepare({col: ["中文\n多行", "特殊𠀀字符", "普通"], "自定义备注": ["甲", "乙", "丙"]}, csv=True, encoding="gb18030")
        self.assertEqual(result["survey"]["rows"], 3)
        self.assertEqual(result["survey"]["encoding"], "gb18030")
        self.clean()
        self.assertEqual(self.data()[col].tolist(), ["中文\n多行", "特殊𠀀字符", "普通"])
        self.assertTrue((self.wd / "问卷数据表_merged.csv").read_bytes().startswith(b"\xef\xbb\xbf"))
        self.assertEqual(len(pd.read_csv(self.wd / "问卷数据表_merged.csv")), 3)

    def test_utf8_and_gbk_inputs(self):
        for encoding in ("utf-8", "gbk"):
            src = self.case / (encoding + ".csv")
            pd.DataFrame({"Q42.口味？": ["中文\n多行", "普通"]}).to_csv(src, index=False, encoding=encoding)
            wd = self.case / (encoding + "_work")
            result = self.cli("prepare", "--dir", wd, "--survey", src)
            self.assertEqual(result["survey"]["rows"], 2)
            self.cli("clean", "--dir", wd)

    def test_inspect_readonly_question_and_age_check(self):
        self.prepare({"Q42.口味？": ["甲", "乙"], "第43题颜色？": ["白", "黑"]})
        before = {p.name: fingerprint(p) for p in self.wd.iterdir()}
        self.cli("inspect", "--dir", self.wd)
        self.assertEqual({p.name: fingerprint(p) for p in self.wd.iterdir()}, before)
        questions = self.cli("questions", "--dir", self.wd, "--q", "Q42,第43题")
        self.assertEqual(questions["questions"][0]["options"], ["甲", "乙"])
        self.cli("check", "--dir", self.wd, "--cross", "Q42,第43题")
        self.cli("check", "--dir", self.wd, "--cross", "42,99", code=2)
        self.cli("check", "--age-groups", "29岁及以下,30-49岁,50岁及以上")
        self.cli("check", "--age-groups", "30岁以下,29-49岁,50岁及以上", code=2)
        self.cli("check", "--age-groups", "30岁以下,40-49岁,50岁及以上", code=2)
        self.cli("check", "--age-groups", "", code=2)
        self.cli("check", "--dir", self.wd, "--cross", "42,foo", code=2)

    def test_prepare_existing_source_return_and_safe_conflicts(self):
        self.prepare({"Q42.口味？": ["甲"]})
        copy = self.wd / "问卷数据表.xlsx"
        before = fingerprint(copy)
        self.cli("prepare", "--dir", self.wd, "--survey", copy)
        self.assertEqual(fingerprint(copy), before)
        another = self.case / "another.xlsx"
        pd.DataFrame({"Q42.口味？": ["乙"]}).to_excel(another, index=False)
        self.cli("prepare", "--dir", self.wd, "--survey", another, code=2)
        self.assertEqual(fingerprint(copy), before)
        sentinel = self.wd / "personal.csv"
        sentinel.write_text("合成保留文件", encoding="utf-8")
        self.clean()
        self.assertEqual(sentinel.read_text(), "合成保留文件")
        self.cli("prepare", "--dir", self.case / "new" / "nested", "--survey", self.source)

    def test_existing_foreign_output_rejected_and_copy_hash_checked(self):
        self.prepare({"Q42.口味？": ["甲"]})
        foreign = self.wd / "问卷数据表_merged.csv"
        foreign.write_text("合成未授权输出", encoding="utf-8")
        self.clean(code=2)
        self.assertEqual(foreign.read_text(), "合成未授权输出")
        self.assertFalse((self.wd / "问卷数据表_merged.xlsx").exists())
        copy = self.wd / "问卷数据表.xlsx"
        with copy.open("ab") as handle:
            handle.write(b"synthetic-change")
        self.clean(code=2)

    def test_reject_removed_cli_options_help_and_branch_absent(self):
        self.prepare({"Q42.口味？": ["甲"]})
        for command in ("prepare", "inspect", "clean"):
            for option in ("--register", "--use-default-register"):
                args = ["--dir", self.wd, option, "dummy"] if command != "prepare" else ["--dir", self.wd, "--survey", self.source, option, "dummy"]
                self.cli(command, *args, code=2)
        for command in ("prepare", "inspect", "check", "clean", "questions"):
            result = subprocess.run([sys.executable, str(SCRIPTS / "clean_pipeline.py"), command, "--help"], capture_output=True, text=True)
            self.assertEqual(result.returncode, 0)
            self.assertNotIn("register", result.stdout.lower())
        source = (SCRIPTS / "clean_pipeline.py").read_text()
        demographic = (SCRIPTS / "demographic_detection.py").read_text()
        for forbidden in ("register", "merge_tables", "survey_stats", "default_register", "clean_register"):
            self.assertNotIn(forbidden, source)
        self.assertNotIn("register", demographic)
        bad = subprocess.run([sys.executable, str(SCRIPTS / "clean_pipeline.py"), "prepare", "--register", "dummy"], capture_output=True, text=True)
        self.assertEqual(bad.returncode, 2)
        self.assertFalse(json.loads(bad.stdout.split("@@RESULT@@ ")[-1])["ok"])

    def weight(self, dimensions):
        output = self.case / "synthetic_weight"
        command = [sys.executable, str(SCRIPTS / "survey_weight.py"), "--file", str(self.wd / "问卷数据表_merged.xlsx"),
                   "--sheet", "data", "--output-dir", str(output)]
        if "weight" in self.data().columns:
            command.append("--replace-weight")
        for column, values, targets in dimensions:
            command.extend(["--dim", column + "|" + ",".join(values) + "|" + ",".join(map(str, targets))])
        completed = subprocess.run(command, capture_output=True, text=True)
        self.assertEqual(completed.returncode, 0, completed.stdout + completed.stderr)
        data = pd.read_excel(output / "加权后数据.xlsx")
        self.assertAlmostEqual(float(data["weight"].mean()), 1.0, places=10)
        checks = []
        for column, values, targets in dimensions:
            for value, target in zip(values, targets):
                actual = data.loc[data[column] == value, "weight"].sum() / data["weight"].sum() * 100
                self.assertLess(abs(actual - target), 0.01)
                checks.append({"field": column, "value": value, "target": target, "actual": float(actual)})
        self.assertNotIn("偏差较大", (output / "命中检查.txt").read_text())
        WEIGHT_RESULTS.append({"case": self._testMethodName, "rows": len(data), "mean_weight": float(data["weight"].mean()),
                               "checks": checks, "output": str(output)})
        return data, checks

    def test_40_balanced_full_factorial_clean_ipf_eleven_targets(self):
        edu = ["初中", "高中", "大专", "本科", "硕士"]
        rows = [{"Q42.您的性别是？": gender, "Q43.您今年多少岁？": age,
                 "44.您的最高学历是什么？": education, "45.您目前从事的职业是？": "服务人员",
                 "Q46.口味？": "A.清淡", "weight": 99}
                for gender, age, education in itertools.product(["男", "女"], [25, 35, 45, 55], edu)]
        self.prepare(rows)
        result = self.clean()
        self.assertEqual(result["stats"]["final_count"], 40)
        dims = [("性别", ["A.男", "B.女"], [50.4, 49.6]),
                ("年龄分段", ["30岁以下", "30-39岁", "40-49岁", "50岁及以上"], [27.8, 19.9, 17.1, 35.2]),
                ("学历", ["A.初中及以下", "B.高中/中专/技校", "C.大学专科", "D.大学本科", "E.硕士及以上"], [59.6, 20.6, 10.5, 8.6, 0.7])]
        data, checks = self.weight(dims)
        self.assertEqual(len(checks), 11)
        self.assertEqual(len(data), 40)
        self.assertFalse((data["weight"] == 99).any())
        self.assertEqual(data["原始_weight"].tolist(), [99] * 40)
        self.assertTrue({"Q42.您的性别是？", "Q46.口味？"} <= set(data.columns))

    def test_formula_like_answer_is_literal_and_question_preserved(self):
        self.prepare({"Q42.备注？": ["=1+1", "普通"]}, csv=True)
        self.clean()
        self.assertEqual(self.data()["Q42.备注？"].tolist(), ["=1+1", "普通"])
        book = pipeline.load_workbook(self.wd / "问卷数据表_merged.xlsx", data_only=False)
        self.assertEqual(book["data"]["A2"].data_type, "s")
        book.close()

    def test_duplicate_raw_headers_rejected_without_workdir(self):
        source = self.case / "synthetic_duplicate.csv"
        source.write_text("性别,性别\n男,女\n", encoding="utf-8")
        result = self.cli("prepare", "--dir", self.wd, "--survey", source, code=2)
        self.assertIn("重复列名", result["error"])
        self.assertFalse(self.wd.exists())
        self.assertEqual(source.read_text(), "性别,性别\n男,女\n")

    def test_sheet_selection_persisted_and_invalid_mapping_no_workdir(self):
        source = self.case / "synthetic_sheets.xlsx"
        with pd.ExcelWriter(source) as writer:
            pd.DataFrame({"Q42.口味？": ["甲"]}).to_excel(writer, sheet_name="其他", index=False)
            pd.DataFrame({"性别": ["女", "男"]}).to_excel(writer, sheet_name="问卷", index=False)
        result = self.cli("prepare", "--dir", self.wd, "--survey", source, "--sheet", "问卷")
        self.assertEqual(result["survey"]["rows"], 2)
        self.clean()
        self.assertEqual(self.data()["性别"].tolist(), ["B.女", "A.男"])
        invalid = self.case / "invalid_work"
        self.cli("prepare", "--dir", invalid, "--survey", source, "--demo-map", "[]", code=2)
        self.assertFalse(invalid.exists())

    def test_manual_source_resolves_unselected_mixed_age_candidate(self):
        self.prepare({"年龄": [20, "30-39岁"], "Q42.您今年多少岁？": [20, 35]})
        self.blocked_unchanged()
        self.clean("--demo-map", json.dumps({"年龄": "Q42.您今年多少岁？"}, ensure_ascii=False))
        self.assertEqual(self.data()["年龄"].tolist(), [20, 35])
        self.assertEqual(self.data()["原始_年龄"].tolist(), [20, "30-39岁"])

    def test_corrupt_excel_parameter_error_is_json_and_no_workdir(self):
        source = self.case / "synthetic_corrupt.xlsx"
        source.write_bytes(b"synthetic-invalid-xlsx")
        self.cli("prepare", "--dir", self.wd, "--survey", source, code=2)
        self.assertFalse(self.wd.exists())

    def test_identity_bare_custom_text_not_assumed_and_equal_time_last(self):
        source = pd.DataFrame({"自定义字段": ["same-first-part;other", "same-first-part;other"]})
        ids, report = pipeline.id_series(source)
        self.assertIsNone(ids)
        self.assertIsNone(report["column"])
        self.prepare({"openid": ["synthetic-a", "synthetic-a"], "结束答题时间": ["2026-01-01", "2026-01-01"], "Q42.口味？": ["甲", "乙"]})
        self.clean()
        self.assertEqual(self.data()["Q42.口味？"].tolist(), ["乙"])

    def test_unknown_override_does_not_change_existing_outputs(self):
        self.prepare({"性别": ["男", "女"]})
        self.clean()
        self.blocked_unchanged("--demo-value-map", json.dumps({"性别": {"男": "未知编码"}}, ensure_ascii=False))

    def test_attention_ambiguous_instructions_and_mixed_letter_values(self):
        report = pipeline.attention_report(pd.DataFrame({"Q42.请选A或选B？": ["A.甲", "B.乙"]}))
        self.assertTrue(report["needs_confirmation"])
        report = pipeline.attention_report(pd.DataFrame({"Q42.请选B？": ["B", "B.乙"]}))
        self.assertTrue(report["needs_confirmation"])

    def test_single_choice_age_bare_numbers_need_codebook(self):
        for index, marker in enumerate(("【单选】", "【单选题】", "（单选）", "[单选题]")):
            with self.subTest(marker=marker):
                self.wd = self.case / ("work_" + str(index))
                column = "Q42.您的年龄是？" + marker
                self.prepare({column: [1, 2], "学历": ["本科", "本科"]})
                result = self.blocked_unchanged()
                candidate = result["demographics"]["fields"]["年龄"]
                self.assertFalse(candidate["reliable"])
                self.assertEqual(candidate["mapping"], {"1": None, "2": None})
                self.assertNotIn("年龄", result["demographics"]["available_core_fields"])
                self.assertFalse((self.wd / "问卷数据表_merged.xlsx").exists())

    def test_single_choice_age_confirmed_numeric_or_unit_mapping(self):
        column = "Q42.您的年龄是？【单选题】"
        self.prepare({column: [1, 2], "学历": ["本科", "本科"]})
        for values in ({"1": 25, "2": 30}, {"1": "25岁", "2": "30周岁"}):
            with self.subTest(values=values):
                mapping = json.dumps({"年龄": values}, ensure_ascii=False)
                result = self.clean("--demo-value-map", mapping)
                self.assertEqual(result["stats"]["final_count"], 2)
                self.assertEqual(result["stats"]["abnormal_removed"], 0)
                self.assertEqual(self.data()["年龄"].tolist(), [25, 30])
                self.assertEqual(self.data()[column].tolist(), [1, 2])
                self.blocked_unchanged()

    def test_single_choice_age_explicit_units_remain_precise(self):
        column = "Q42.您的年龄是？【单选】"
        self.prepare({column: ["0岁", "20周岁", "A.25岁"]})
        result = self.clean("--rules", "none")
        self.assertEqual(result["stats"]["final_count"], 3)
        self.assertEqual(self.data()["年龄"].tolist(), [0, 20, 25])
        self.assertEqual(self.data()[column].tolist(), ["0岁", "20周岁", "A.25岁"])

    def test_fill_in_and_standard_age_bare_zero_twenty_still_valid(self):
        for index, column in enumerate(("Q42.您今年多少岁？【填空题】", "年龄")):
            with self.subTest(column=column):
                self.wd = self.case / ("work_" + str(index))
                self.prepare({column: [0, 20]})
                result = self.clean("--rules", "none")
                self.assertEqual(result["stats"]["final_count"], 2)
                self.assertEqual(self.data()["年龄"].tolist(), [0, 20])

    def test_single_choice_age_source_map_alone_does_not_confirm_codes(self):
        column = "Q42.资料项甲？【单选题】"
        mapping = json.dumps({"年龄": column}, ensure_ascii=False)
        self.prepare({column: [1, 2]}, "--demo-map", mapping)
        result = self.blocked_unchanged("--rules", "none")
        self.assertTrue(any("无码本编码" in reason for reason in result["confirmation_reasons"]))

    def test_single_choice_age_mixed_units_and_unmapped_codes_block(self):
        column = "Q42.您的年龄是？【单选题】"
        self.prepare({column: ["20岁", 1]})
        self.blocked_unchanged("--rules", "none")
        self.clean("--rules", "none", "--demo-value-map", json.dumps({"年龄": {"1": 25}}, ensure_ascii=False))
        self.assertEqual(self.data()["年龄"].tolist(), [20, 25])

    def test_legacy_band_exact_age_birth_conflict_preserves_exact_source(self):
        source = {"年龄": ["18-29岁"], "Q42.您今年多少岁？": [20], "出生年份": [2000]}
        for index, columns in enumerate((source, dict(reversed(list(source.items()))))):
            with self.subTest(order=index):
                normalized, report = pipeline.normalized(pd.DataFrame(columns), {"reference_year": 2026})
                self.assertTrue(report["needs_confirmation"])
                self.assertEqual(normalized["年龄"].tolist(), [20])
                self.assertEqual(normalized["原始_年龄"].tolist(), ["18-29岁"])
                self.wd = self.case / ("work_" + str(index))
                self.prepare(columns, "--reference-year", 2026)
                result = self.blocked_unchanged("--rules", "none")
                self.assertTrue(any("年龄与出生年份" in reason for reason in result["confirmation_reasons"]))
                self.assertEqual(result["demographics"]["fields"]["年龄"]["source_column"], "Q42.您今年多少岁？")

    def test_legacy_band_exact_age_birth_no_conflict_reruns_stably(self):
        column = "Q42.您今年多少岁？"
        self.prepare({"年龄": ["18-29岁"], column: [20], "出生年份": [2006]}, "--reference-year", 2026)
        result = self.clean("--rules", "none")
        first = self.data()
        self.assertEqual(first["年龄"].tolist(), [20])
        self.assertEqual(first["原始_年龄"].tolist(), ["18-29岁"])
        self.assertEqual(first["年龄分段"].tolist(), ["18-29岁"])
        self.assertEqual(first[column].tolist(), [20])
        self.assertEqual(result["stats"]["final_count"], 1)
        self.clean("--steps", "4,5", "--rules", "none")
        pd.testing.assert_frame_equal(first, self.data())

    def test_birth_year_does_not_fill_or_replace_partial_reliable_exact_age(self):
        self.prepare({"年龄": ["18-29岁", "18-29岁"], "Q42.您今年多少岁？": [20, ""],
                      "出生年份": [2006, 2001]}, "--reference-year", 2026)
        self.clean("--rules", "none", "--no-demo-completeness")
        self.assertEqual(self.data()["年龄"].tolist(), [20, ""])
        self.assertEqual(self.data()["原始_年龄"].tolist(), ["18-29岁"] * 2)

    def test_audit_reserved_source_columns_rejected_before_prepare(self):
        for index, column in enumerate((pipeline.REF, "_removed_stage", "_removed_reason")):
            with self.subTest(column=column):
                source = self.case / ("synthetic_reserved_" + str(index) + ".xlsx")
                pd.DataFrame({column: ["原题答案"], "Q42.口味？": ["甲"]}).to_excel(source, index=False)
                before = fingerprint(source)
                self.wd = self.case / ("work_" + str(index))
                result = self.cli("prepare", "--dir", self.wd, "--survey", source, code=2)
                self.assertIn(column, result["error"])
                self.assertEqual(fingerprint(source), before)
                self.assertFalse(self.wd.exists())

    def test_audit_reserved_source_columns_rejected_on_legacy_work_clean(self):
        for index, column in enumerate((pipeline.REF, "_removed_stage", "_removed_reason")):
            with self.subTest(column=column):
                self.wd = self.case / ("work_" + str(index))
                self.prepare({"Q42.口味？": ["甲", "乙"]})
                # 模拟旧版本已准备的合成副本，不涉及用户源文件。
                copy = self.wd / "问卷数据表.xlsx"
                pd.DataFrame({column: ["原题甲", "原题乙"], "Q42.口味？": ["甲", "乙"]}).to_excel(copy, index=False)
                cfg = pipeline.read_json(self.wd / pipeline.CONFIG)
                cfg["source_sha256"] = fingerprint(copy)
                pipeline.write_json(self.wd / pipeline.CONFIG, cfg)
                before = {p.name: fingerprint(p) for p in self.wd.iterdir() if p.is_file()}
                result = self.clean("--filter-rule", "Q42.口味？ == 甲", code=2)
                self.assertIn(column, result["error"])
                self.assertEqual({p.name: fingerprint(p) for p in self.wd.iterdir() if p.is_file()}, before)

    def test_regroup_age_band_backup_collision_preserves_all_and_reruns(self):
        self.prepare({"年龄": [20, 35], "年龄分段": ["18-29岁", "30-49岁"],
                      "原始_年龄分段": ["原题甲", "原题乙"], "原始_年龄分段_2": ["旧备份甲", "旧备份乙"]})
        self.clean("--rules", "none", "--age-groups", "30岁以下,30-49岁,50岁及以上")
        first = self.data()
        self.assertEqual(first["年龄分段"].tolist(), ["30岁以下", "30-49岁"])
        self.assertEqual(first["原始_年龄分段"].tolist(), ["原题甲", "原题乙"])
        self.assertEqual(first["原始_年龄分段_2"].tolist(), ["旧备份甲", "旧备份乙"])
        self.assertEqual(first["原始_年龄分段_3"].tolist(), ["18-29岁", "30-49岁"])
        self.clean("--steps", "4,5", "--rules", "none", "--age-groups", "30岁以下,30-49岁,50岁及以上")
        pd.testing.assert_frame_equal(first, self.data())
        self.assertNotIn("原始_年龄分段_4", self.data())

    def test_regroup_keeps_normalization_backup_and_pre_regroup_values(self):
        self.prepare({"年龄": [20], "年龄分段": ["A.18-29岁"]})
        self.clean("--rules", "none", "--age-groups", "30岁以下,30-49岁,50岁及以上")
        self.assertEqual(self.data()["原始_年龄分段"].tolist(), ["A.18-29岁"])
        self.assertEqual(self.data()["原始_年龄分段_2"].tolist(), ["18-29岁"])
        self.assertEqual(self.data()["年龄分段"].tolist(), ["30岁以下"])

    def test_city_level_backup_collision_preserves_all_and_reruns(self):
        self.prepare({"城市": ["合成城市", ""], "城市分级": ["", ""],
                      "原始_城市分级": ["原题甲", "原题乙"], "原始_城市分级_2": ["旧备份甲", "旧备份乙"]})
        result = self.clean()
        first = self.data()
        self.assertEqual(result["stats"]["city_level_filled"], 1)
        self.assertEqual(first["城市分级"].tolist(), ["合成分级", ""])
        self.assertEqual(first["原始_城市分级"].tolist(), ["原题甲", "原题乙"])
        self.assertEqual(first["原始_城市分级_2"].tolist(), ["旧备份甲", "旧备份乙"])
        self.assertEqual(first["原始_城市分级_3"].tolist(), ["", ""])
        self.clean("--steps", "4,5")
        pd.testing.assert_frame_equal(first, self.data())
        self.assertNotIn("原始_城市分级_4", self.data())

    def test_normalization_backup_collision_blocks_without_overwriting(self):
        source = self.case / "synthetic_backup_collision.xlsx"
        pd.DataFrame({"性别": ["男"], "原始_性别": ["原题答案"]}).to_excel(source, index=False)
        before = fingerprint(source)
        result = self.cli("prepare", "--dir", self.wd, "--survey", source, code=2)
        self.assertIn("原始_性别", result["error"])
        self.assertEqual(fingerprint(source), before)
        self.assertFalse(self.wd.exists())

    def test_explicit_noncustom_id_uses_full_value_and_basic_branch(self):
        self.prepare({"用户标识": ["openid=synthetic-a;extra=x", "openid=synthetic-a;extra=y",
                                "openid=synthetic-a;extra=x", "", ""], "自定义字段": ["裸文本"] * 5})
        self.assertEqual(self.clean()["stats"]["final_count"], 5)
        result = self.clean("--id-column", "用户标识", "--confirm-demo-completeness")
        self.assertEqual(result["identity"]["method"], "explicit_column")
        self.assertEqual(result["mode"], "basic")
        self.assertEqual(result["stats"]["demo_checked"], [])
        self.assertEqual(len(result["stats"]["skipped_rules"]), 10)
        self.assertEqual(result["stats"]["survey_dedupe_removed"], 1)
        self.assertEqual(result["stats"]["final_count"], 4)
        self.assertEqual(self.data()["合成记录序号"].tolist(), [2, 3, 4, 5])

    def test_gender_only_custom_ipf_504_496(self):
        self.prepare({"Q42.您的性别是？": ["男"] * 13 + ["女"] * 7})
        self.clean()
        data, checks = self.weight([("性别", ["A.男", "B.女"], [50.4, 49.6])])
        self.assertEqual(len(data), 20)
        self.assertEqual(len(checks), 2)


def main():
    global ROOT
    parent = Path(os.environ.get("SURVEY_LITE_TEST_OUTPUT", str(DEFAULT_OUTPUT))).expanduser().resolve()
    pipeline.mkdir_checked(parent)
    ROOT = parent / ("synthetic_run_" + datetime.now().strftime("%Y%m%d_%H%M%S_%f") + "_" + uuid4().hex[:8])
    ROOT.mkdir()
    suite = unittest.defaultTestLoader.loadTestsFromTestCase(LitePipelineTests)
    runner = unittest.TextTestRunner(verbosity=2)
    result = runner.run(suite)
    summary = {"synthetic_only": True, "run_dir": str(ROOT), "tests_run": result.testsRun,
               "failures": len(result.failures), "errors": len(result.errors), "weight_results": WEIGHT_RESULTS,
               "failure_details": [{"test": str(test), "traceback": trace} for test, trace in result.failures + result.errors]}
    (ROOT / "test_summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
    print("SURVEY_LITE_TEST_OUTPUT=" + str(ROOT))
    return 0 if result.wasSuccessful() else 1


if __name__ == "__main__":
    sys.exit(main())
