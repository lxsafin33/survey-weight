"""新版加权脚本的纯合成安全回归；不读取真实问卷，不写测试日志。"""

import contextlib
import csv
import hashlib
import importlib.util
import io
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from datetime import datetime
from unittest import mock

import numpy as np
import pandas as pd
from openpyxl import Workbook, load_workbook

sys.dont_write_bytecode = True
SCRIPT = Path(__file__).with_name("survey_weight.py")
OUTPUT_PARENT = Path(os.environ.get("SURVEY_LITE_TEST_OUTPUT", tempfile.gettempdir())).expanduser().resolve()
SPEC = importlib.util.spec_from_file_location("weight_safety_subject", SCRIPT)
WEIGHT = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(WEIGHT)
RUN = None


def snapshot(root):
    result = {}
    if not root.exists() and not root.is_symlink():
        return result
    for path in [root, *root.rglob("*")]:
        relative = str(path.relative_to(root))
        if path.is_symlink():
            result[relative] = ("软链", os.readlink(path))
        elif path.is_file():
            result[relative] = ("文件", hashlib.sha256(path.read_bytes()).hexdigest())
        else:
            result[relative] = ("目录",)
    return result


class WeightSafetyTests(unittest.TestCase):
    def setUp(self):
        self.base = Path(tempfile.mkdtemp(prefix=self._testMethodName + "_", dir=RUN))
        tempfile.tempdir = str(RUN)
        self.source = self.base / "合成输入.csv"
        self.out = self.base / "产物"
        self.csv_source(["性别", "普通答案"], [["男", "001"], ["女", "NA"]])

    def csv_source(self, headers, rows, encoding="utf-8-sig", path=None):
        path = path or self.source
        with path.open("w", encoding=encoding, newline="") as stream:
            writer = csv.writer(stream)
            writer.writerow(headers)
            writer.writerows(rows)
        return path

    def xlsx_source(self, headers, rows, sheet="data", formulas_as_text=True):
        self.source = self.base / "合成输入.xlsx"
        workbook = Workbook()
        worksheet = workbook.active
        worksheet.title = sheet
        worksheet.append(headers)
        for row in rows:
            worksheet.append(row)
        if formulas_as_text:
            for row in worksheet:
                for cell in row:
                    if isinstance(cell.value, str) and cell.value.startswith("="):
                        cell.data_type = "s"
        workbook.save(self.source)
        workbook.close()
        return self.source

    def arguments(self, dims=None, extra=()):
        args = ["--file", str(self.source), "--output-dir", str(self.out)]
        for dim in dims or ["性别|男,女|50.4,49.6"]:
            args.extend(["--dim", dim])
        return args + list(extra)

    def run_cli(self, dims=None, extra=(), expected=0):
        before = snapshot(self.base)
        source_before = self.source.read_bytes()
        result = subprocess.run([sys.executable, "-B", str(SCRIPT),
                                 *self.arguments(dims, extra)], capture_output=True,
                                text=True, timeout=60,
                                env={**os.environ, "TMPDIR": str(RUN), "PYTHONDONTWRITEBYTECODE": "1"})
        message = result.stdout + result.stderr
        self.assertEqual(result.returncode, expected, message)
        self.assertEqual(self.source.read_bytes(), source_before, "合成输入文件不得变动")
        self.assertNotIn("Traceback", message)
        if expected == 2 or "--check-only" in extra:
            self.assertEqual(snapshot(self.base), before, message)
            self.assertNotIn("加权完成", message)
        return message

    def in_process(self, patch_name, patch_value=None, side_effect=None):
        before = snapshot(self.base)
        output, error = io.StringIO(), io.StringIO()
        with mock.patch.object(WEIGHT, patch_name, return_value=patch_value,
                               side_effect=side_effect), contextlib.redirect_stdout(output), \
                contextlib.redirect_stderr(error):
            code = WEIGHT.main(self.arguments())
        self.assertEqual(code, 2, output.getvalue() + error.getvalue())
        self.assertEqual(snapshot(self.base), before)
        self.assertNotIn("Traceback", error.getvalue())
        return error.getvalue()

    def output_rows(self):
        with (self.out / "加权后数据.csv").open(encoding="utf-8-sig", newline="") as stream:
            return list(csv.reader(stream))

    def assert_hits(self, dims):
        data, _, _ = WEIGHT.read_data(self.out / "加权后数据.xlsx", "Sheet1")
        weights = data["weight"].to_numpy(dtype=float)
        self.assertTrue(np.isfinite(weights).all())
        self.assertTrue((weights >= 0).all())
        self.assertAlmostEqual(weights.mean(), 1, places=10)
        for col, values, targets in dims:
            encoded, unmapped = WEIGHT.encode_column(data[col], values)
            self.assertEqual(len(unmapped), 0)
            for index, target in enumerate(targets, start=1):
                actual = weights[encoded == index].sum() / weights.sum() * 100
                self.assertLessEqual(abs(actual - target), 0.0001 + 1e-10)

    def check_original_values(self, headers, rows):
        csv_rows = self.output_rows()
        self.assertEqual(csv_rows[0], headers + ["weight"])
        self.assertEqual([row[:-1] for row in csv_rows[1:]],
                         [["" if value is None else str(value) for value in row] for row in rows])
        workbook = load_workbook(self.out / "加权后数据.xlsx", data_only=False)
        worksheet = workbook.active
        for i, values in enumerate([headers, *rows], start=1):
            for j, original in enumerate(values, start=1):
                cell = worksheet.cell(i, j)
                self.assertEqual(cell.value if cell.value is not None else "",
                                 original if original is not None else "")
                if isinstance(original, str) and original:
                    self.assertEqual(cell.data_type, "s")
                elif isinstance(original, bool):
                    self.assertIsInstance(cell.value, bool)
                    self.assertEqual(cell.data_type, "b")
                elif isinstance(original, (int, float)):
                    self.assertEqual(cell.data_type, "n")
                elif isinstance(original, datetime):
                    self.assertEqual(cell.data_type, "d")
        workbook.close()

    def test_xlsx_original_types_and_formula_text(self):
        headers = ["性别", "编号", "答案", "数字", "布尔", "日期", "=原题列"]
        rows = [["男", "000123", "=1+1", 7, True, datetime(2026, 1, 2), "NULL"],
                ["女", "001", "NA", 1.25, False, datetime(2026, 2, 3), "=SUM(A1:A2)"],
                ["男", "1.00", "NULL", 0, True, datetime(2026, 3, 4), ""],
                ["女", "0000", "多行\n含,逗号", -3, False, datetime(2026, 4, 5), "NA"]]
        self.xlsx_source(headers, rows)
        before = self.source.read_bytes()
        self.run_cli(extra=["--sheet", "data"])
        self.assertEqual(self.source.read_bytes(), before)
        self.check_original_values(headers, rows)
        self.assert_hits([("性别", ["男", "女"], [50.4, 49.6])])

    def test_existing_excel_formula_is_preserved_as_text(self):
        self.xlsx_source(["性别", "答案"], [["男", "=1+1"], ["女", "=2+2"]],
                         formulas_as_text=False)
        self.run_cli()
        self.check_original_values(["性别", "答案"], [["男", "=1+1"], ["女", "=2+2"]])

    def test_same_enc_columns_are_preserved(self):
        headers = ["性别", "_enc_性别", "_enc_0", "_enc_1"]
        rows = [["男", "001", "甲", "=1+1"], ["女", "NULL", "乙", "NA"]]
        self.csv_source(headers, rows)
        self.run_cli(["性别|男,女|50,50", "_enc_0|甲,乙|50,50"])
        self.check_original_values(headers, rows)

    def test_replace_weight_unique_backup(self):
        headers = ["性别", "weight", "原始_weight", "原始_weight_2", "答案"]
        rows = [["男", "0002", "原有甲", "原有乙", "=1+1"],
                ["女", "NULL", "NA", "001", "0000"]]
        self.csv_source(headers, rows)
        self.run_cli(extra=["--replace-weight"])
        expected_headers = ["性别", "原始_weight_3", "原始_weight", "原始_weight_2", "答案"]
        self.check_original_values(expected_headers, rows)

    def test_replace_weight_xlsx_backup_types(self):
        headers = ["性别", "weight", "答案"]
        rows = [["男", 3.5, "001"], ["女", "0002", "NULL"]]
        self.xlsx_source(headers, rows)
        self.run_cli(extra=["--replace-weight"])
        self.check_original_values(["性别", "原始_weight", "答案"], rows)

    def test_check_only_success_no_outputs(self):
        self.run_cli(extra=["--check-only"])

    def test_check_only_replace_weight_no_change(self):
        self.csv_source(["性别", "weight"], [["男", "0002"], ["女", "NULL"]])
        self.run_cli(extra=["--check-only", "--replace-weight"])

    def test_zero_target_with_no_samples(self):
        self.run_cli(["性别|男,女,其它|50,50,0"])
        self.assert_hits([("性别", ["男", "女", "其它"], [50, 50, 0])])

    def test_zero_target_with_samples(self):
        self.run_cli(["性别|男,女|0,100"])
        self.assert_hits([("性别", ["男", "女"], [0, 100])])

    def test_numeric_object_range_and_above_boundary(self):
        rows = [[str(value)] for value in [0, 49, 50, 51, 90]]
        self.csv_source(["年龄"], rows)
        self.run_cli(["年龄|50岁及以下,50岁以上|60,40"])
        self.assert_hits([("年龄", ["50岁及以下", "50岁以上"], [60, 40])])
        self.check_original_values(["年龄"], rows)

    def test_xlsx_numeric_object_ranges(self):
        rows = [[value] for value in [0, 49, 50, 51, 90]]
        self.xlsx_source(["年龄"], rows)
        self.run_cli(["年龄|50岁以下,50岁及以上|40,60"])
        self.assert_hits([("年龄", ["50岁以下", "50岁及以上"], [40, 60])])
        self.check_original_values(["年龄"], rows)

    def test_string_age_categories_exact(self):
        values = ["30岁以下", "30-39岁", "40-49岁", "50岁及以上"]
        self.csv_source(["年龄档"], [[value] for value in values])
        self.run_cli(["年龄档|" + ",".join(values) + "|20,25,30,25"])
        self.assert_hits([("年龄档", values, [20, 25, 30, 25])])

    def test_string_age_alias_not_matched(self):
        self.csv_source(["年龄档"], [["50岁及以上"]])
        self.run_cli(["年龄档|50+|100"], expected=2)

    def test_numeric_text_categories_keep_leading_zeros(self):
        values = ["001", "1", "1.5"]
        self.csv_source(["代码"], [[value] for value in values])
        self.run_cli(["代码|001,1,1.5|20,30,50"])
        self.check_original_values(["代码"], [[value] for value in values])
        self.assert_hits([("代码", values, [20, 30, 50])])

    def test_numeric_values_no_decimal_truncation(self):
        self.xlsx_source(["代码"], [[1], [1.5]])
        self.run_cli(["代码|1,1.5|30,70"])
        self.assert_hits([("代码", ["1", "1.5"], [30, 70])])

    def test_float_numeric_category_compatibility(self):
        encoded, unmapped = WEIGHT.encode_column(pd.Series([1.0, 2.0], dtype=object), ["1", "2"])
        self.assertEqual(encoded.tolist(), [1, 2])
        self.assertEqual(len(unmapped), 0)

    def test_numeric_alias_ambiguity_rejected(self):
        self.xlsx_source(["代码"], [[1], [2]])
        self.run_cli(["代码|1,01,2|25,25,50"], expected=2)

    def test_unsafe_dimension_names_and_unique_names(self):
        names = ["../年龄/[A]", "维度/A", "维度\\A", "维度?A",
                 "长" * 40 + "甲", "长" * 40 + "乙", "Case", "case", "é", "e\u0301"]
        self.csv_source(names, [["甲"] * len(names), ["乙"] * len(names)])
        self.run_cli([name + "|甲,乙|50,50" for name in names])
        workbook = load_workbook(self.out / "加权汇总.xlsx")
        self.assertEqual(len(workbook.sheetnames), len(names))
        self.assertEqual(len({name.casefold() for name in workbook.sheetnames}), len(names))
        for name in workbook.sheetnames:
            self.assertLessEqual(len(name), 31)
            self.assertFalse(any(char in name for char in "[]:*?/\\"))
        workbook.close()
        cross_files = list((self.out / "交叉表").iterdir())
        self.assertEqual(len(cross_files), len(names) * (len(names) - 1) // 2)
        self.assertEqual(len({path.name.casefold() for path in cross_files}), len(cross_files))
        for path in cross_files:
            self.assertLessEqual(len(path.name.encode("utf-8")), 255)
        self.assertEqual([path.name for path in self.base.iterdir() if path.is_dir()], ["产物"])

    def test_input_output_same_file_rejected(self):
        self.out = self.base
        self.source = self.base / "加权后数据.csv"
        self.csv_source(["性别"], [["男"], ["女"]])
        self.run_cli(expected=2)

    def test_input_hardlink_output_rejected(self):
        self.out.mkdir()
        os.link(self.source, self.out / "加权后数据.csv")
        self.run_cli(expected=2)

    def test_input_symlink_target_output_rejected(self):
        original = self.source
        self.out.mkdir()
        stored = self.out / "加权后数据.csv"
        stored.write_bytes(original.read_bytes())
        self.source = self.base / "输入软链.csv"
        self.source.symlink_to(stored)
        self.run_cli(expected=2)

    def test_output_parent_symlink_rejected(self):
        actual = self.base / "真实合成目录"
        actual.mkdir()
        self.out.symlink_to(actual, target_is_directory=True)
        self.run_cli(expected=2)

    def test_output_ancestor_symlink_rejected(self):
        actual = self.base / "真实合成目录"
        actual.mkdir()
        link = self.base / "父目录软链"
        link.symlink_to(actual, target_is_directory=True)
        self.out = link / "新产物"
        self.run_cli(expected=2)

    def test_cross_directory_symlink_rejected(self):
        self.out.mkdir()
        actual = self.base / "真实交叉目录"
        actual.mkdir()
        (self.out / "交叉表").symlink_to(actual, target_is_directory=True)
        self.run_cli(expected=2)

    def test_output_directory_file_rejected(self):
        self.out.write_bytes(b"synthetic sentinel")
        self.run_cli(expected=2)

    def test_cross_directory_file_rejected(self):
        self.out.mkdir()
        (self.out / "交叉表").write_bytes(b"synthetic sentinel")
        self.run_cli(expected=2)

    def test_cross_file_existing_preflight(self):
        self.csv_source(["性别", "类型"], [["男", "甲"], ["女", "乙"]])
        (self.out / "交叉表").mkdir(parents=True)
        (self.out / "交叉表" / "性别×类型.xlsx").write_bytes(b"synthetic sentinel")
        self.run_cli(["性别|男,女|50,50", "类型|甲,乙|50,50"], expected=2)

    def test_cross_file_dangling_symlink_preflight(self):
        self.csv_source(["性别", "类型"], [["男", "甲"], ["女", "乙"]])
        (self.out / "交叉表").mkdir(parents=True)
        (self.out / "交叉表" / "性别×类型.xlsx").symlink_to(self.base / "不存在.xlsx")
        self.run_cli(["性别|男,女|50,50", "类型|甲,乙|50,50"], expected=2)

    def test_serialization_failure_no_outputs(self):
        self.in_process("_excel_bytes", side_effect=ValueError("合成序列化失败"))

    def test_exclusive_creation_race_rolls_back_own_files(self):
        original_open = os.open
        sentinel = self.out / "加权后数据.csv"

        def collision(path, flags, mode=0o777, **kwargs):
            if Path(path) == sentinel:
                with sentinel.open("xb") as stream:
                    stream.write(b"synthetic concurrent sentinel")
            return original_open(path, flags, mode, **kwargs)

        output, error = io.StringIO(), io.StringIO()
        before_input = self.source.read_bytes()
        with mock.patch.object(WEIGHT.os, "open", side_effect=collision), \
                contextlib.redirect_stdout(output), contextlib.redirect_stderr(error):
            code = WEIGHT.main(self.arguments())
        self.assertEqual(code, 2)
        self.assertEqual(sentinel.read_bytes(), b"synthetic concurrent sentinel")
        self.assertEqual([path for path in self.out.rglob("*") if path.is_file() or path.is_symlink()],
                         [sentinel], error.getvalue())
        self.assertEqual(self.source.read_bytes(), before_input)
        self.assertNotIn("Traceback", error.getvalue())

    def test_write_failure_rolls_back_all_outputs(self):
        class FailingStream:
            def __init__(self, stream):
                self.stream = stream

            def write(self, data):
                self.stream.write(data[:5])
                raise OSError("合成磁盘写入失败")

            def close(self):
                self.stream.close()

        original = os.fdopen
        before = snapshot(self.base)
        output, error = io.StringIO(), io.StringIO()
        with mock.patch.object(WEIGHT.os, "fdopen", side_effect=lambda fd, mode:
                               FailingStream(original(fd, mode))), \
                contextlib.redirect_stdout(output), contextlib.redirect_stderr(error):
            code = WEIGHT.main(self.arguments())
        self.assertEqual(code, 2)
        # 某些宿主文件系统不支持 rmdir；空目录不视为加权产物，任何文件必须回滚。
        after = snapshot(self.base)
        self.assertEqual({key: value for key, value in after.items() if value != ("目录",)},
                         {key: value for key, value in before.items() if value != ("目录",)},
                         error.getvalue())
        self.assertIn("合成磁盘写入失败", error.getvalue())
        self.assertNotIn("加权完成", output.getvalue())

    def test_40_rows_11_ranges_and_gender(self):
        ranges = [f"{i * 10}-{i * 10 + 9}岁" for i in range(11)]
        targets = [6, 7, 8, 9, 10, 11, 12, 10, 9, 8, 10]
        rows = [[str(10 * (i % 11) + 5), "男" if i % 2 == 0 else "女", f"{i:05}"]
                for i in range(40)]
        self.csv_source(["年龄", "性别", "编号"], rows)
        self.run_cli(["年龄|" + ",".join(ranges) + "|" + ",".join(map(str, targets)),
                      "性别|男,女|50.4,49.6"])
        self.assert_hits([("年龄", ranges, targets), ("性别", ["男", "女"], [50.4, 49.6])])
        self.check_original_values(["年龄", "性别", "编号"], rows)
        self.assertEqual(len(self.output_rows()) - 1, 40)

    def test_40_rows_three_dimensions(self):
        rows = [["男" if i % 2 == 0 else "女", "青年" if (i // 2) % 2 == 0 else "中年",
                 "甲" if (i // 4) % 2 == 0 else "乙"] for i in range(40)]
        self.csv_source(["性别", "年龄档", "类型"], rows)
        self.run_cli(["性别|男,女|50.4,49.6", "年龄档|青年,中年|45,55", "类型|甲,乙|30,70"])
        self.assert_hits([("性别", ["男", "女"], [50.4, 49.6]),
                          ("年龄档", ["青年", "中年"], [45, 55]),
                          ("类型", ["甲", "乙"], [30, 70])])

    def test_csv_all_blank_record_is_not_skipped(self):
        self.source.write_text("性别\n男\n\n女\n", encoding="utf-8-sig")
        self.run_cli(expected=2)

    def test_xlsx_empty_dimension_is_blocked(self):
        self.xlsx_source(["性别", "答案"], [["男", "001"], [None, "NULL"], ["女", "NA"]])
        self.run_cli(expected=2)

    def test_xlsx_duplicate_headers_rejected(self):
        self.xlsx_source(["性别", "性别"], [["男", "女"]])
        self.run_cli(expected=2)

    def test_missing_sheet_clean_error(self):
        self.xlsx_source(["性别"], [["男"], ["女"]])
        self.run_cli(extra=["--sheet", "不存在的表"], expected=2)

    def test_output_existing_directory_as_target_rejected(self):
        (self.out / "加权后数据.csv").mkdir(parents=True)
        self.run_cli(expected=2)

    def test_zero_support_combination_infeasible(self):
        self.csv_source(["性别", "类型"], [["男", "甲"], ["女", "乙"]])
        self.run_cli(["性别|男,女|100,0", "类型|甲,乙|0,100"], expected=2)

    def test_explicit_zero_target_check_only(self):
        self.run_cli(["性别|男,女,其它|0,100,0"], extra=["--check-only"])

    def test_ipf_direct_unmapped_rejected(self):
        for data in ([1, None], [1, 3]):
            with self.assertRaises(ValueError):
                WEIGHT.ipf_weights(pd.DataFrame({"d": data}), ["d"], {"d": {1: 0.5, 2: 0.5}})

    def test_ipf_direct_invalid_targets_rejected(self):
        for targets in ({1: np.nan}, {1: np.inf}, {1: -1, 2: 2}, {1: 0}, {}):
            with self.assertRaises(ValueError):
                WEIGHT.ipf_weights(pd.DataFrame({"d": [1, 2]}), ["d"], {"d": targets})

    def test_main_parser_error_returns_two(self):
        error = io.StringIO()
        with contextlib.redirect_stderr(error):
            code = WEIGHT.main(self.arguments(extra=["--max-iter", "错误"]))
        self.assertEqual(code, 2)
        self.assertNotIn("Traceback", error.getvalue())
        self.assertFalse(self.out.exists())

    def test_main_returns_clean_error_code(self):
        output, error = io.StringIO(), io.StringIO()
        with contextlib.redirect_stdout(output), contextlib.redirect_stderr(error):
            code = WEIGHT.main(self.arguments(["性别|男,女|NaN,100"]))
        self.assertEqual(code, 2)
        self.assertIn("[错误]", error.getvalue())
        self.assertNotIn("Traceback", error.getvalue())
        self.assertFalse(self.out.exists())


def add_case(name, function):
    function.__name__ = "test_" + name
    setattr(WeightSafetyTests, function.__name__, function)


for encoding in ("utf-8-sig", "gb18030"):
    def csv_case(self, encoding=encoding):
        headers = ["性别", "编号", "答案", "=原题"]
        rows = [["男", "000123", "NA", "=1+1"], ["女", "0000", "NULL", "=SUM(A1:A2)"],
                ["男", "1.00", "", "多行\n含,逗号"], ["女", "0123", "中文", "  原文  "]]
        self.csv_source(headers, rows, encoding=encoding)
        self.run_cli(extra=["--sheet", "CSV无工作表"])
        self.check_original_values(headers, rows)
    add_case("csv_roundtrip_" + encoding.replace("-", "_"), csv_case)


INVALID_DIMS = [
    ("nan", ["性别|男,女|NaN,100"]),
    ("inf", ["性别|男,女|inf,0"]),
    ("negative_inf", ["性别|男,女|-inf,100"]),
    ("negative", ["性别|男,女|-1,101"]),
    ("all_zero", ["性别|男,女|0,0"]),
    ("bad_total", ["性别|男,女|40,40"]),
    ("outside_rounding", ["性别|男,女|50,49.89"]),
    ("nonnumeric", ["性别|男,女|甲,50"]),
    ("count_mismatch", ["性别|男,女|100"]),
    ("empty_dimension", ["|男,女|50,50"]),
    ("duplicate_dimension", ["性别|男,女|50,50", "性别|男,女|50,50"]),
    ("empty_value", ["性别|男,|50,50"]),
    ("whitespace_value", ["性别|男,  |50,50"]),
    ("duplicate_value", ["性别|男,男|50,50"]),
    ("duplicate_value_trim", ["性别|男, 男 |50,50"]),
    ("missing_column", ["不存在|男,女|50,50"]),
    ("bad_spec", ["性别|男,女"]),
]
for name, dims in INVALID_DIMS:
    def invalid_case(self, dims=dims):
        self.run_cli(dims, expected=2)
    add_case("invalid_" + name, invalid_case)


for name, value in [("unknown", "未知"), ("empty", ""), ("whitespace", "   "),
                    ("literal_na", "NA"), ("literal_null", "NULL")]:
    for check in (False, True):
        def unmapped_case(self, value=value, check=check):
            self.csv_source(["性别"], [["男"], ["女"], [value]])
            message = self.run_cli(extra=["--check-only"] if check else [], expected=2)
            self.assertIn("未映射/空值", message)
        add_case("unmapped_" + name + ("_check" if check else "_run"), unmapped_case)


for check in (False, True):
    def old_weight_case(self, check=check):
        self.csv_source(["性别", "weight"], [["男", "001"], ["女", "NULL"]])
        message = self.run_cli(extra=["--check-only"] if check else [], expected=2)
        self.assertIn("--replace-weight", message)
    add_case("old_weight_no_flag" + ("_check" if check else "_run"), old_weight_case)

    def zero_sample_case(self, check=check):
        self.csv_source(["性别"], [["男"], ["男"]])
        message = self.run_cli(["性别|男,女|0,100"],
                              extra=["--check-only"] if check else [], expected=2)
        self.assertIn("目标不可行", message)
        self.assertNotIn("ZeroDivisionError", message)
    add_case("positive_zero_sample" + ("_check" if check else "_run"), zero_sample_case)

    def infeasible_case(self, check=check):
        self.csv_source(["性别", "类型"], [["男", "甲"], ["女", "乙"], ["男", "甲"], ["女", "乙"]])
        message = self.run_cli(["性别|男,女|80,20", "类型|甲,乙|20,80"],
                              extra=["--check-only"] if check else [], expected=2)
        self.assertIn("边际误差", message)
    add_case("infeasible" + ("_check" if check else "_run"), infeasible_case)

    def not_converged_case(self, check=check):
        self.csv_source(["性别", "类型"], [["男", "甲"], ["男", "甲"], ["男", "乙"], ["女", "甲"]])
        message = self.run_cli(["性别|男,女|50,50", "类型|甲,乙|50,50"],
                              extra=["--max-iter", "1"] + (["--check-only"] if check else []), expected=2)
        self.assertIn("未收敛", message)
        self.assertIn("边际误差", message)
    add_case("not_converged" + ("_check" if check else "_run"), not_converged_case)


for name, maximum in [("zero", "0"), ("negative", "-1"), ("text", "错误")]:
    def max_iter_case(self, maximum=maximum):
        self.run_cli(extra=["--max-iter", maximum], expected=2)
    add_case("max_iter_" + name, max_iter_case)


for name, targets in [("below", [50, 49.99]), ("above", [50.01, 50])]:
    def normalization_case(self, targets=targets):
        message = self.run_cli(["性别|男,女|" + ",".join(map(str, targets))])
        self.assertIn("[归一化]", message)
        self.assertIn("[归一化目标]", message)
        normalized = np.asarray(targets) / sum(targets) * 100
        self.assert_hits([("性别", ["男", "女"], normalized)])
    add_case("rounding_normalization_" + name, normalization_case)


for name, spec, expected in [("above", "50岁以上", [51, float("inf")]),
                             ("inclusive_above", "50岁及以上", [50, float("inf")]),
                             ("plus", "50岁+", [50, float("inf")]),
                             ("below", "50岁以下", [0, 50]),
                             ("inclusive_below", "50岁及以下", [0, 51]),
                             ("closed_integer_range", "30-39岁", [30, 40])]:
    def boundary_case(self, spec=spec, expected=expected):
        self.assertEqual(list(WEIGHT.parse_range(spec)), expected)
        series = pd.Series(["49", "50", "51"], dtype=object)
        encoded, _ = WEIGHT.encode_column(series, [spec])
        for age, code in zip([49, 50, 51], encoded):
            self.assertEqual(not pd.isna(code), expected[0] <= age < expected[1])
    add_case("boundary_" + name, boundary_case)


for name, values, ages in [("overlap", ["0-50", "50+"], ["20", "60"]),
                           ("overlap_alias", ["50岁及以上", "50+"], ["50", "60"]),
                           ("flipped", ["39-30", "40+"], ["35", "50"]),
                           ("empty_range", ["0岁以下", "0+"], ["0", "1"]),
                           ("uncovered_boundary", ["49岁及以下", "51+"], ["49", "50", "51"]),
                           ("uncovered_negative", ["50岁以下", "50+"], ["-1", "51"]),
                           ("nonfinite", ["50岁以下", "50+"], ["20", "inf"])]:
    def range_failure_case(self, values=values, ages=ages):
        self.csv_source(["年龄"], [[age] for age in ages])
        self.run_cli(["年龄|" + ",".join(values) + "|50,50"], expected=2)
    add_case("range_reject_" + name, range_failure_case)


for filename in ("加权后数据.xlsx", "加权后数据.csv", "加权汇总.xlsx", "命中检查.txt"):
    for kind in ("existing", "symlink", "dangling"):
        def output_conflict_case(self, filename=filename, kind=kind):
            self.out.mkdir()
            target = self.out / filename
            if kind == "existing":
                target.write_bytes(b"synthetic sentinel")
            elif kind == "symlink":
                target.symlink_to(self.source)
            else:
                target.symlink_to(self.base / "不存在的目标")
            self.run_cli(expected=2)
        add_case("output_conflict_" + filename.replace(".", "_") + "_" + kind, output_conflict_case)


for name, weights in [("nan", [np.nan, 1]), ("inf", [np.inf, 1]),
                      ("negative", [-1, 3]), ("zero_sum", [0, 0]),
                      ("finite_wrong_margins", [1, 3]), ("overflow_total", [1e308, 1e308])]:
    def invalid_weights_case(self, weights=weights):
        self.in_process("ipf_weights", patch_value=np.asarray(weights, dtype=float))
    add_case("invalid_weights_" + name, invalid_weights_case)


for name, headers, rows in [("empty_data", ["性别"], []),
                            ("duplicate_header", ["性别", "性别"], [["男", "女"]]),
                            ("empty_header", ["性别", ""], [["男", "001"]])]:
    def header_case(self, headers=headers, rows=rows):
        self.csv_source(headers, rows)
        self.run_cli(expected=2)
    add_case("source_" + name, header_case)


if __name__ == "__main__":
    if not OUTPUT_PARENT.is_dir():
        raise SystemExit("指定的合成测试父目录不存在；未创建其它目录")
    RUN = Path(tempfile.mkdtemp(prefix="run_weight_safety_", dir=OUTPUT_PARENT))
    print(f"独立合成测试目录: {RUN}", flush=True)
    suite = unittest.defaultTestLoader.loadTestsFromTestCase(WeightSafetyTests)
    result = unittest.TextTestRunner(verbosity=2).run(suite)
    print(f"合成测试数量: {result.testsRun}；失败: {len(result.failures)}；错误: {len(result.errors)}")
    raise SystemExit(0 if result.wasSuccessful() else 1)
