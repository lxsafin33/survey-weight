#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
User-Agent 解析模块
从问卷数据表的UA字段中提取操作系统和设备型号（中文映射）
"""

import re
import pandas as pd
from typing import Tuple, Optional


# ========== 操作系统中文映射 ==========
def _translate_os(os_raw: str) -> str:
    """将原始操作系统名称映射为中文"""
    if os_raw.startswith('Android'):
        return '安卓'
    if os_raw.startswith('iOS'):
        return '苹果'
    if os_raw.startswith('HarmonyOS'):
        return '华为'
    if os_raw.startswith('Windows'):
        return 'Windows'
    if os_raw.startswith('macOS') or os_raw.startswith('Mac OS'):
        return '苹果'
    return os_raw


# ========== 设备型号 → 手机品牌映射 ==========
# 基于各品牌设备的型号命名规则（参考 MobileModels 项目）
# 规则优先级由上到下依次降低

_BRAND_PATTERNS = [
    # === 荣耀 (HONOR) ===
    (r'^(FOA|CMA|MAA|PGT|REP|VER|ANB|BVL|ELI|BRT|RMO|RKY|LGE|DIO|ENT|HLK|JDY|JAT|KAN|KSA|LRA|MAG|MOA|MXW|NTH|PCAM|RBN|TNA|VNE|WOD|YOK)\-', '荣耀'),
    (r'^(ANY|ARE|BAH|BKL|BND|BMH|BZA|CRR|DNN|DUB|ELZ|FNE|GLK|HRY|JMM|JSC|LLD|NEM|RTE|BMH)\-', '荣耀'),
    (r'^(HBN|HEY|LIO|AQM|NEO|NOH|OCE|TAS)\-', '华为'),  # 华为系列
    (r'^(ALI|ALN|ALT|ANA|ANG|BON|BAL|BAH|BNE|BRA|BZA|CET|CLT|CMH|CND|COR|CRR|CTR|DAV|DCO|DLI|DRA|DUB|EDI|ELE|ELS|EML|EMU|EVA|EVR|FIG|FLA|FRD|GEM|GLK|GRA|GRS|HMA|HWI|JAD|JEF|JKM|JNY|JSC|KIR|KOB|LDN|LIO|LOG|LON|LUA|LYA|LYO|MAR|MEY|MGA|MRD|MYA|NCO|NEO|NOH|NOP|NXT|OCE|OXF|PAR|PIC|PLK|POT|PRA|REA|RIO|RNE|RSE|RTY|SEA|SHT|SNE|SPN|STF|STK|TAH|TAS|TET|TIT|TNY|TRT|VCE|VIE|VKY|VNS|VOG|VTR|WAS|WKG|YAL|AGS|ALP|ARE|ART|AUM|BKL|BLA|BND|BTN|CAN|COL)\-', '华为'),
    # 华为通用三字母前缀（动态覆盖，匹配 XXX-A[NL]XX 或 XXX-TLXX 格式，含变体后缀）
    (r'^[A-Z]{3}\-[AT][NL]\d{2}[a-zA-Z]?$', '华为'),
    # 华为四位前缀（如 BAH2, HEY2, JDN2）
    # 华为四位前缀（如 BAH2, HEY2, JDN2）
    (r'^[A-Z]{3}\d\-[A-Z]{2}\d{2}[a-zA-Z]?$', '华为'),
    # 华为平板/穿戴（W/B/P/X/L前缀，含3字母+数字前缀如 HEY2-W09）
    (r'^[A-Z]{3}\d\-[WBPXL][A-Z0-9]\d{1,2}[a-zA-Z]?$', '华为'),
    (r'^[A-Z]{3,4}\-[WBPXL][A-Z0-9]\d{1,2}[a-zA-Z]?$', '华为'),
    # 华为/荣耀 TYH 前缀（平板系列）
    (r'^TYH\d{3}[A-Z]?(\-[A-Z0-9]+)?$', '华为'),
    # 华为/荣耀 四字母前缀 + AN/AL（如 TNNH-AN00）
    (r'^[A-Z]{4}\-[AT][NL]\d{2}[a-zA-Z]?$', '华为'),

    # === OPPO ===
    (r'^(P[A-Z]{2}M\d{2}|CPH\d+|PCHM\d+|PDAM\d+|PDEM\d+|PDHM\d+|PDJM\d+|PDKM\d+|PDLM\d+|PDNM\d+|PDPM\d+|PDRM\d+|PDSM\d+|PDTM\d+|PECM\d+|PEEM\d+|PEGM\d+|PEHM\d+|PEMM\d+|PENM\d+|PEPM\d+|PERM\d+|PESM\d+|PETM\d+|PEUM\d+|PEYM\d+|PFCM\d+|PFFM\d+|PFGM\d+|PFHM\d+|PFJM\d+|PFLM\d+|PFZM\d+|PGAM\d+|PGCM\d+|PGDM\d+|PGEM\d+|PGFM\d+|PGGM\d+|PGJM\d+|PGKM\d+|PHW\d+|PHZ\d+|PJV\d+|PKT\d+|PLB\d+)$', 'OPPO'),
    (r'^(PBEM\d+|PBAM\d+|RMX\d+|RMO|REP)\-', 'OPPO'),  # realme 已回归 OPPO
    (r'^(RMO|REP)\-', 'OPPO'),

    # === 小米 (Xiaomi) / Redmi / POCO ===
    # YYMM格式: 2位年份+2位月份+型号代码，如 23013RK75C, 2407FRK8EC, 21091116AC
    (r'^2[1-9](?:0[1-9]|1[0-2])[A-Z0-9]{4,}[CG]?$', '小米'),
    # M+YYMM格式: M + 年份后2位+月份2位+代码，如 M2007J3SC
    (r'^M2[01]\d{2}[A-Z0-9]+[CG]?$', '小米'),
    # 2014xx格式旧款
    (r'^201[4-9]\d{2}[A-Z0-9]+[CG]?$', '小米'),
    # Redmi / POCO 子品牌
    (r'^(Redmi|POCO|XiaoMi)\s', '小米'),
    (r'^Redmi$', '小米'),
    (r'^MIX\s', '小米'),
    (r'^Mi\s+\d+[A-Za-z]?$', '小米'),
    (r'^MI\s+\d+[A-Za-z]?$', '小米'),
    (r'^MI\s+[A-Za-z0-9\s]+$', '小米'),
    # Mi数字（无空格，如 Mi9, Mi10）
    (r'^Mi\d+\s?[A-Za-z0-9\s]*$', '小米'),

    # === 一加 (OnePlus) ===
    (r'^(LE2\d+|KB20\d+|IN20\d+|NE2\d+|PHB\d+|CPH2\d+|CPH24\d+|CPH25\d+|CPH26\d+|PKB\d+|PKG\d+|PJD\d+|PKA\d+|PKM\d+)$', '一加'),
    (r'^(A\d{4}|A00\d+|EB21\d+|GN2\d+|MT2\d+|PDA\d+)$', '一加'),
    # OnePlus 全名型号（如 ONEPLUS A5010）
    (r'^ONEPLUS\s', '一加'),
    (r'^OnePlus\s', '一加'),

    # === OPPO P系列（纯数字后缀，如 PLA110, PHJ110, PHK110，注意在OnePlus之后）===
    (r'^(P[A-Z]{2}\d{3,})$', 'OPPO'),
    # OPPO PExxTxx 系列（如 PEHT00）
    (r'^(P[A-Z]{2}T\d{2})$', 'OPPO'),

    # === vivo ===
    (r'^(V\d{4}[A-Z]*|PD[A-Z0-9]{3,}|PA\d{4}|PK\d{4})$', 'vivo'),
    # vivo 全名型号（如 vivo Y69A, vivo X21i A）
    (r'^vivo\s', 'vivo'),

    # === iQOO ===
    (r'^(I\d{4}|I\d{3}[A-Z]?)$', 'iQOO'),

    # === 三星 (Samsung) ===
    (r'^SM\-', '三星'),

    # === realme (未合并OPPO之前的) ===
    (r'^RMX\d+$', 'realme'),

    # === 中兴 (ZTE) ===
    (r'^(ZTE\s*|N956[0S]|A\d{4}|Axon|Blade)', '中兴'),
    (r'^(904[0-9]N|803[0-9]N|A20\d{2}|A0616|Z999)', '中兴'),

    # === 努比亚 (nubia) ===
    (r'^NX\d+[A-Z]?$', '努比亚'),

    # === 魅族 (MEIZU) ===
    (r'^(16T|16th|17|17Pro|18|18Pro|20|21|M\d{3}[A-Z]?|M\d{4}[A-Z]?|MEIZU\s)', '魅族'),
    (r'^(PRO\s*\d)', '魅族'),

    # === 摩托罗拉 (Motorola) ===
    (r'^XT\d{4}\-?\d?$', '摩托罗拉'),

    # === Google Pixel ===
    (r'^(Pixel\s*[\da-zA-Z]+)$', 'Google'),

    # === 索尼 (Sony) ===
    (r'^(XQ\-|SO\-|SOG\d|SOV\d|E\d{4}|C\d{4}|D\d{4}|F\d{4}|G\d{4}|H\d{4}|J\d{4}|L\d{4}|SGP)', '索尼'),

    # === BlackBerry ===
    (r'^(BB[EFGH]|BBB\d|STH\d|STV\d|RHK\d|RHT\d|RHW\d|RHX\d|RHY\d)$', '黑莓'),

    # === 联想 (Lenovo) ===
    (r'^Lenovo\s', '联想'),
    (r'^Lecoo\s', '联想'),

    # === 其他小品牌 ===
    (r'^LynkCo\s', '领克'),
    (r'^Philips\s', '飞利浦'),
]


def _map_model_to_brand(model: str) -> str:
    """
    将设备型号映射为手机品牌名称
    
    参数:
        model: 原始设备型号字符串
        
    返回:
        品牌名称（中文，如 华为、荣耀、vivo 等）
    """
    if model == '未知':
        return model  # 解析失败保持标记
    
    model = model.strip()
    
    for pattern, brand in _BRAND_PATTERNS:
        if re.match(pattern, model, re.IGNORECASE):
            return brand
    
    # 不在 MobileModels 规则中的，统一标记为其他
    return '其他'


def parse_ua(ua_string: str) -> Tuple[str, str]:
    """
    解析 User-Agent 字符串，提取操作系统（中文名）和设备品牌
    
    参数:
        ua_string: User-Agent 字符串
        
    返回:
        (操作系统中文名, 设备品牌) 元组，无法识别时返回 ('其他', '未知')
    """
    if pd.isna(ua_string) or not isinstance(ua_string, str) or not ua_string.strip():
        return ('其他', '未知')
    
    ua = ua_string.strip()
    
    # ===== 1. 检测 Android =====
    android_match = re.search(r'Android\s+(\d+(?:\.\d+)?)', ua, re.IGNORECASE)
    if android_match:
        os_name = _translate_os(f"Android {android_match.group(1)}")
        # 提取设备型号
        model_match = re.search(
            r'Android\s+\d+(?:\.\d+)?;\s*'
            r'(?:[a-z]{2}(?:[-_][A-Za-z]+)?;\s*)?'  # 可选的语言标记
            r'([^;)]+)',
            ua, re.IGNORECASE
        )
        if model_match:
            model = model_match.group(1).strip()
            # 去掉 Build/ 及后续内容
            model = re.sub(r'\s+Build/.*$', '', model)
            # 如果捕获到了语言标记本身（如 "zh-cn"），继续往后找真实型号
            if re.match(r'^[a-z]{2}[-_][A-Za-z]+$', model, re.IGNORECASE):
                alt_match = re.search(
                    r'Android\s+\d+(?:\.\d+)?;\s*'
                    r'[a-z]{2}(?:[-_][A-Za-z]+)?;\s*'
                    r'([^;)]+)',
                    ua, re.IGNORECASE
                )
                if alt_match:
                    model = alt_match.group(1).strip()
                    model = re.sub(r'\s+Build/.*$', '', model)
            model = model.rstrip(')').strip()
        else:
            model = '未知'
        return (os_name, _map_model_to_brand(model))
    
    # ===== 2. 检测 iPhone / iOS =====
    iphone_match = re.search(r'(iPhone|iPad|iPod)', ua, re.IGNORECASE)
    ios_match = re.search(r'(?:iPhone|iPad)\s+OS\s+(\d+)[_\.](\d+)', ua, re.IGNORECASE)
    if iphone_match or ios_match:
        os_name = _translate_os("iOS")
        return (os_name, '苹果')
    
    # ===== 3. 检测 OpenHarmony / HarmonyOS =====
    harmony_match = re.search(r'OpenHarmony\s+(\d+(?:\.\d+)?)', ua, re.IGNORECASE)
    if harmony_match:
        os_name = _translate_os(f"HarmonyOS {harmony_match.group(1)}")
        # 尝试提取设备类型/名称: (Phone; OpenHarmony ...) 或 (Tablet; OpenHarmony ...)
        dev_match = re.search(r'\(([^;]+);\s*OpenHarmony', ua, re.IGNORECASE)
        if dev_match:
            model = dev_match.group(1).strip()
        else:
            model = '未知'
        return (os_name, _map_model_to_brand(model))
    
    # ===== 4. 检测 Windows =====
    win_match = re.search(r'Windows\s+NT\s+(\d+\.\d+)', ua, re.IGNORECASE)
    if win_match:
        os_name = _translate_os("Windows")
        return (os_name, 'Windows')
    
    # ===== 5. 检测 macOS =====
    if re.search(r'Macintosh|Mac\s+OS\s+X', ua, re.IGNORECASE):
        return (_translate_os('macOS'), '其他')
    
    # ===== 6. 检测 Linux =====
    if re.search(r'Linux', ua, re.IGNORECASE) and not android_match:
        return ('Linux', '未知')
    
    # ===== 7. 无法识别 =====
    return ('其他', '未知')


def process_ua_column(df: pd.DataFrame, ua_column: str = 'UA') -> pd.DataFrame:
    """
    处理 DataFrame 中的 UA 列，添加操作系统（中文名）和设备品牌列
    
    参数:
        df: 包含 UA 列的 DataFrame
        ua_column: UA 列的列名，默认为 'UA'
        
    返回:
        添加了 '操作系统'（中文名如 安卓/苹果/华为/Windows）和 '设备型号'（品牌名）列的 DataFrame
    """
    if ua_column not in df.columns:
        return df
    
    print(f"\n[UA] 检测到 UA 列 ({len(df)} 行数据)，正在解析操作系统与设备品牌...")
    
    # 应用解析函数（返回中文OS名 + 品牌名）
    parsed = df[ua_column].apply(parse_ua)
    df['操作系统'] = parsed.apply(lambda x: x[0])
    df['设备型号'] = parsed.apply(lambda x: x[1])
    
    # 统计分布
    os_counts = df['操作系统'].value_counts()
    model_counts = df['设备型号'].value_counts()
    
    print(f"  [OK] 操作系统分布（中文）: {dict(os_counts)}")
    print(f"  [OK] 设备品牌种类: {len(model_counts)} 种")
    print(f"  品牌分布 Top 10: {dict(model_counts.head(10))}")
    print(f"  [OK] 已生成列: 操作系统, 设备型号")
    
    return df


def get_ua_dimension_categories() -> dict:
    """返回 UA 相关维度的分类定义"""
    return {
        '操作系统': [],   # 动态值：安卓、苹果、华为、Windows 等
        '设备型号': [],   # 动态值：手机品牌名称
    }


if __name__ == '__main__':
    # 测试用例
    test_ua_list = [
        # Android - 荣耀
        'Mozilla/5.0 (Linux; Android 12; FOA-AL00 Build/HONORFOA-AL00; wv) AppleWebKit/537.36',
        # Android - vivo
        'Mozilla/5.0 (Linux; Android 10; V1911A Build/QP1A.190711.020; wv) AppleWebKit/537.36',
        # Android - vivo (带语言标记)
        'Mozilla/5.0 (Linux; Android 14; zh-cn; V2354A Build/UP1A.231005.007; wv) AppleWebKit/537.36',
        # Android - OPPO
        'Mozilla/5.0 (Linux; Android 13; PEMM00 Build/TP1A.220905.001; wv) AppleWebKit/537.36',
        # Android - 三星
        'Mozilla/5.0 (Linux; Android 14; SM-S9280 Build/UP1A.231005.007; wv) AppleWebKit/537.36',
        # Android - 一加
        'Mozilla/5.0 (Linux; Android 14; LE2110 Build/UKQ1.230924.001; wv) AppleWebKit/537.36',
        # Android - 小米 (无法匹配品牌则保留型号)
        'Mozilla/5.0 (Linux; Android 13; 23013RK75C Build/TP1A.220624.014; wv) AppleWebKit/537.36',
        # Android - realme
        'Mozilla/5.0 (Linux; Android 13; RMX3700 Build/TP1A.220624.014; wv) AppleWebKit/537.36',
        # iPhone
        'Mozilla/5.0 (iPhone; CPU iPhone OS 26_5_2 like Mac OS X) AppleWebKit/605.1.15',
        # HarmonyOS
        'Mozilla/5.0 (Phone; OpenHarmony 5.0) AppleWebKit/537.36',
        'Mozilla/5.0 (Phone; OpenHarmony 4.1) AppleWebKit/537.36',
        # Windows
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
        # macOS
        'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36',
    ]
    
    print("=" * 60)
    print("UA 解析测试（中文OS + 品牌映射）")
    print("=" * 60)
    for ua in test_ua_list:
        os_name, model = parse_ua(ua)
        print(f"\nUA: {ua[:80]}...")
        print(f"  操作系统: {os_name}")
        print(f"  设备品牌: {model}")
    
    # 批量测试
    print("\n" + "=" * 60)
    print("批量测试")
    print("=" * 60)
    test_df = pd.DataFrame({'UA': test_ua_list})
    result_df = process_ua_column(test_df)
    print(result_df[['操作系统', '设备型号']].to_string())
