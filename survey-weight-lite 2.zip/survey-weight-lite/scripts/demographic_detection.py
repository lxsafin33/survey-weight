# -*- coding: utf-8 -*-
"""仅依据明确人口学题干与实际答案识别；不推断码值或个人属性。"""
import re
import unicodedata
from datetime import datetime

import pandas as pd

CORE_FIELDS = ("性别", "年龄", "出生年份", "年龄分段", "学历", "职业")
FIELDS = CORE_FIELDS + ("省份", "城市", "地区", "城乡", "婚姻状况", "月收入", "行业", "城市分级")
QUESTION_PREFIX = re.compile(r"^\s*(?:Q\s*(\d+)\s*[.、:：]?|第\s*(\d+)\s*题\s*[.、:：]?|(\d+)\s*[.、:：])\s*", re.I)
OTHER_PERSON = re.compile(r"孩子|子女|儿童|父母|父亲|母亲|爸爸|妈妈|配偶|伴侣|丈夫|妻子|先生|太太|家人|家庭|朋友|同事|他人|其他人")
ALIASES = {
    "性别": ("性别",), "年龄": ("年龄", "周岁年龄", "周岁"),
    "出生年份": ("出生年份", "出生年"), "年龄分段": ("年龄段", "年龄分段", "年龄范围", "年龄区间"),
    "学历": ("学历", "最高学历", "最高学历水平", "受教育程度", "最高受教育程度", "文化程度"),
    "职业": ("职业", "职业类型", "职业类别", "职业状况", "工作职业", "从事的职业"),
    "省份": ("省份", "所在省份", "居住省份", "常住省份"),
    "城市": ("城市", "所在城市", "居住城市", "常住城市"),
    "地区": ("地区", "所在地区", "居住地区", "常住地区"),
    "城乡": ("城乡", "城乡类型", "城乡属性", "所在地是城镇还是农村", "所在地是城市还是农村"),
    "婚姻状况": ("婚姻状况", "婚姻状态"),
    "月收入": ("月收入", "个人月收入", "个人税前月收入", "税前月收入", "每月收入"),
    "行业": ("行业", "从事的行业", "所属行业", "所在行业", "工作行业"),
    "城市分级": ("城市分级",),
}
EDUCATION = {
    "未上过学": "A.初中及以下", "文盲": "A.初中及以下", "小学": "A.初中及以下",
    "初中": "A.初中及以下", "初中及以下": "A.初中及以下", "初中及以下学历": "A.初中及以下",
    "高中": "B.高中/中专/技校", "中专": "B.高中/中专/技校", "技校": "B.高中/中专/技校",
    "高中/中专/技校": "B.高中/中专/技校", "高中、中专或技校": "B.高中/中专/技校",
    "高中/中专": "B.高中/中专/技校", "中专/高中": "B.高中/中专/技校",
    "高中/中专/职高": "B.高中/中专/技校", "职高": "B.高中/中专/技校",
    "大专": "C.大学专科", "专科": "C.大学专科", "大学专科": "C.大学专科",
    "本科": "D.大学本科", "大学本科": "D.大学本科",
    "硕士": "E.硕士及以上", "博士": "E.硕士及以上", "硕士及以上": "E.硕士及以上",
    "硕士研究生": "E.硕士及以上", "博士研究生": "E.硕士及以上",
    "硕士及以上学历": "E.硕士及以上", "硕士研究生及以上": "E.硕士及以上",
    "硕士研究生及以上学历": "E.硕士及以上",
}


def text(value):
    return unicodedata.normalize("NFKC", str(value)).strip()


def value_key(value):
    s = str(value).strip()
    return re.sub(r"^(\d+)\.0$", r"\1", s)


def is_missing(value):
    return pd.isna(value) or text(value).lower() in ("", "nan", "none", "#n/a", "null")


def question_number(column):
    m = QUESTION_PREFIX.match(text(column))
    return int(next(g for g in m.groups() if g is not None)) if m else None


def strip_question_number(column):
    return QUESTION_PREFIX.sub("", text(column))


def identify_field(column):
    stem = strip_question_number(column)
    if OTHER_PERSON.search(stem):
        return None
    # 只剥离末尾完整题型标识，不删除带假设/偏好描述的括注。
    stem = re.sub(r"(?:\s*(?:\(\s*(?:单选|单选题|多选|多选题|填空|填空题)\s*\)|\[\s*(?:单选|单选题|多选|多选题|填空|填空题)\s*\]|【\s*(?:单选|单选题|多选|多选题|填空|填空题)\s*】)[?。:：]*)+\s*$", "", stem).strip()
    matrix = re.fullmatch(r"(?:您|你)(?:目前)?所在的地区是[?]?[:：](省|省份|市|城市|区|地区)", stem)
    if matrix:
        return {"省": "省份", "省份": "省份", "市": "城市", "城市": "城市", "区": "地区", "地区": "地区"}[matrix.group(1)]
    # 仅去掉明确的问句修饰；不以关键词命中态度、偏好或消费问题。
    stem = re.sub(r"\((?:包括在读|含在读|周岁|岁|从各种途径得到的全部收入总和,包括零花钱)\)", "", stem)
    stem = re.sub(r"^(?:到目前为止[,，]?|请(?:问|填写|选择|问一下))", "", stem)
    if re.fullmatch(r"(?:您|你|本人)(?:今年)?(?:的)?(?:多少岁|多大(?:年龄)?|年龄(?:是多少|为多少|是)?)[?。:：]*", stem):
        return "年龄"
    stem = re.sub(r"^(?:您|你|本人)(?:目前|现在|当前)?(?:的)?", "", stem)
    stem = re.sub(r"^(?:目前|现在|当前)(?:的)?", "", stem)
    stem = re.sub(r"^(所在|居住|常住)的", r"\1", stem)
    stem = re.sub(r"(?:为多少|是多少|是什么|为|是|属于哪一类|属于哪个范围|属于哪个年龄段)?[?？。:：]*$", "", stem)
    for field, aliases in ALIASES.items():
        if stem in aliases:
            return field
    return None


def answer_text(value):
    return re.sub(r"^(?:[A-Za-z]+\s*[.、:)\-]\s*|\d+\s*[.、:)]\s*(?=[^\d\s]))", "", text(value)).strip()


def age_bounds(value):
    s = answer_text(value).replace("岁", "").replace("～", "-").replace("~", "-").replace("至", "-").replace("—", "-").replace("–", "-")
    m = re.fullmatch(r"(\d+)\s*-\s*(\d+)", s)
    if m and 0 <= int(m[1]) <= int(m[2]) <= 120:
        return int(m[1]), int(m[2]) + 1
    m = re.fullmatch(r"(\d+)(及以下|以下|及以上|以上|\+)", s)
    if m and 0 <= int(m[1]) <= 120:
        n, op = int(m[1]), m[2]
        return (0, n + (op == "及以下")) if "以下" in op else (n + (op == "以上"), 121)
    return None


def normalize_value(field, value, year, allow_bare_age=True):
    if is_missing(value):
        return None, None, None
    s = answer_text(value)
    if field == "性别":
        gender = {"男": "A.男", "男性": "A.男", "女": "B.女", "女性": "B.女"}
        return gender.get(s), "性别" if s in gender else None, None
    if field in ("年龄", "年龄分段"):
        bounds = age_bounds(s)
        if bounds:
            return s, "年龄分段", None
        m = re.fullmatch(r"(\d{1,3})(?:\.0)?\s*(周岁|岁)?", s)
        if m and 0 <= int(m[1]) <= 120 and field == "年龄" and (allow_bare_age or m[2]):
            return int(m[1]), "年龄", None
        # 兼容旧标准年龄列中明确的四位出生年份，不用中位数或占比猜测。
        if field == "年龄":
            m = re.fullmatch(r"(\d{4})(?:\.0)?年?", s)
            if m and year - 120 <= int(m[1]) <= year:
                return int(m[1]), "出生年份", "旧年龄列保存的是出生年份，将按参考年换算"
        return None, None, None
    if field == "出生年份":
        m = re.fullmatch(r"(\d{4})(?:\.0)?年?", s)
        if m and year - 120 <= int(m[1]) <= year:
            return int(m[1]), field, None
        return None, None, None
    if field == "学历":
        if s in EDUCATION:
            return EDUCATION[s], field, None
        if s in ("研究生", "大学本科及以上", "本科及以上", "大专及以上", "高中及以上", "专科及以上"):
            return s, field, "保留合并/未区分学位的原学历口径，不拆分或等同硕士"
        return None, None, None
    if field == "城乡":
        if s in ("城市", "城镇", "乡镇", "农村", "乡村"):
            return s, field, None
        return None, None, None
    if field == "婚姻状况":
        if s in ("未婚", "已婚", "离异", "离婚", "丧偶", "同居", "单身", "已婚有子女", "已婚无子女"):
            return s, field, None
        return None, None, None
    if field == "月收入":
        if re.fullmatch(r"\d+(?:\.\d+)?元(?:/月)?", s) or re.fullmatch(r"\d+\s*[-~～至]\s*\d+元?", s) or re.fullmatch(r"\d+元?(?:及以上|以上|及以下|以下)", s) or s in ("无收入", "没有收入"):
            return s, field, None
        # 小数字也可能是选项编码，不作金额解释。
        if re.fullmatch(r"\d+(?:\.\d+)?", s) and float(s) >= 100:
            return s, field, None
        return None, None, None
    if field in ("职业", "行业", "省份", "城市", "地区", "城市分级"):
        if s in ("是", "否", "同意", "不同意", "满意", "不满意", "重要", "不重要", "喜欢", "不喜欢"):
            return None, None, None
        if re.fullmatch(r"[A-Za-z]+|\d+(?:\.\d+)?", s):
            return None, None, None
        if re.search(r"[\u4e00-\u9fff]", s):
            return s, field, None
    return None, None, None


def _validate_maps(df, demo_map, demo_value_map):
    if not isinstance(demo_map, dict) or not isinstance(demo_value_map, dict):
        raise ValueError("人口学映射必须是 JSON 对象")
    for field, column in demo_map.items():
        if field not in FIELDS or not isinstance(column, str) or column not in df.columns:
            raise ValueError(f"无效 --demo-map：{field}: {column}")
        if OTHER_PERSON.search(strip_question_number(column)):
            raise ValueError(f"不能将他人或家庭属性映射为本人信息：{column}")
    if len(set(demo_map.values())) != len(demo_map):
        raise ValueError("同一源列不能映射为多个人口学字段")
    for field, mapping in demo_value_map.items():
        if field not in FIELDS or not isinstance(mapping, dict):
            raise ValueError(f"无效 --demo-value-map：{field}")
        for value in mapping.values():
            if not isinstance(value, (str, int, float)):
                raise ValueError(f"确认后的标准值必须是文本或数字：{field}")


def normalize(df, demo_map=None, demo_value_map=None, reference_year=None):
    """返回 (保留原题列并新增标准列的数据副本, JSON 可序列化报告)。"""
    demo_map = {} if demo_map is None else demo_map
    demo_value_map = {} if demo_value_map is None else demo_value_map
    _validate_maps(df, demo_map, demo_value_map)
    year = reference_year if reference_year is not None else datetime.now().year
    report = {"fields": {}, "candidates": {}, "warnings": [], "needs_confirmation": False,
              "confirmation_reasons": [], "reference_year": year, "mode": "basic"}

    def pending(reason):
        if reason not in report["confirmation_reasons"]:
            report["confirmation_reasons"].append(reason)
        report["needs_confirmation"] = True

    candidates = {}
    values = {}
    for col in df.columns:
        field = next((f for f, source in demo_map.items() if source == col), None) or identify_field(col)
        if field is None:
            continue
        series = df[col]
        if isinstance(series, pd.DataFrame):
            pending(f"重复列名：{col}")
            continue
        mapping, unknown, kinds, notes = {}, [], set(), set()
        result = []
        missing = 0
        confirmed = demo_value_map.get(field, {})
        single_choice_age = field == "年龄" and bool(re.search(
            r"(?:\(\s*单选(?:题)?\s*\)|\[\s*单选(?:题)?\s*\]|【\s*单选(?:题)?\s*】)", text(col)))
        for raw in series:
            if is_missing(raw):
                missing += 1
                result.append(None)
                continue
            key = value_key(raw)
            value = confirmed.get(str(raw), confirmed.get(key, raw))
            # 单选裸数字可能是选项码；只有显式码本或岁数单位可消除歧义。
            mapped = str(raw) in confirmed or key in confirmed
            val, kind, note = normalize_value(field, value, year, allow_bare_age=not single_choice_age or mapped)
            if kind == "出生年份" and field == "年龄" and col != "年龄":
                val, kind, note = None, None, None
            mapping[str(raw)] = val
            if kind:
                kinds.add(kind)
            else:
                if str(raw) not in unknown:
                    unknown.append(str(raw))
            if note:
                notes.add(note)
            result.append(val)
        target = next(iter(kinds)) if len(kinds) == 1 else field
        candidate = {"source_column": str(col), "declared_field": field, "field": target,
                     "mapping": mapping, "missing": missing, "unrecognized_values": unknown,
                     "valid_count": sum(v is not None for v in result),
                     "reliable": len(kinds) == 1 and not unknown and bool(kinds),
                     "mixed_types": sorted(kinds) if len(kinds) > 1 else [], "warnings": sorted(notes)}
        candidates.setdefault(target, []).append(candidate)
        values[(target, col)] = pd.Series(result, index=df.index, dtype=object)
        if len(kinds) > 1:
            if field not in demo_map or demo_map[field] == col:
                pending(f"{col} 混合了不同口径：{'、'.join(sorted(kinds))}")
            else:
                report["warnings"].append(f"{col} 混合口径，已由人工映射选择其它来源，本列仅保留原值")
        report["warnings"].extend(f"{col}：{note}" for note in sorted(notes))
    report["candidates"] = candidates
    out = df.copy()
    for field, cs in candidates.items():
        explicit = demo_map.get(field)
        chosen = next((c for c in cs if c["source_column"] == explicit), None) if explicit else None
        if chosen is None:
            chosen = next((c for c in cs if c["source_column"] == field), cs[0])
        if len(cs) > 1:
            report["warnings"].append(f"{field} 有多个候选，" + (f"已按人工映射选择 {explicit}" if explicit else "优先现有标准列；须确认来源"))
            if not explicit:
                pending(f"{field} 有多个候选题/列")
            baseline = values[(field, chosen["source_column"])]
            for c in cs:
                other = values[(field, c["source_column"])]
                conflict = baseline.notna() & other.notna() & (baseline != other)
                if conflict.any():
                    report["warnings"].append(f"{field}：{chosen['source_column']} 与 {c['source_column']} 有 {int(conflict.sum())} 行矛盾")
                    if not explicit:
                        pending(f"{field} 的标准列或候选题答案矛盾")
        if chosen["unrecognized_values"]:
            pending(f"{chosen['source_column']} 有未识别值/无码本编码，请用 --demo-value-map 确认")
        report["fields"][field] = dict(chosen)
        if chosen["reliable"]:
            out[field] = values[(field, chosen["source_column"])]
            # 保留源年龄列；精确年龄是否可用由报告决定。
        elif chosen["valid_count"] == 0 and not chosen["unrecognized_values"]:
            report["warnings"].append(f"{field} 整列缺失，不纳入人口学完整性检查")
    # 旧标准年龄列实际是档位/年份时，不将其原文本误当精确年龄。
    age_source = next((c for cs in candidates.values() for c in cs
                       if c["source_column"] == "年龄"), None)
    if age_source and age_source["reliable"] and age_source["field"] != "年龄":
        report["warnings"].append("原年龄列保存档位/出生年份，原值须保留，不能直接按精确岁数使用")
    if "出生年份" in report["fields"] and report["fields"]["出生年份"]["reliable"]:
        derived = pd.to_numeric(out["出生年份"], errors="coerce").map(lambda v: year - v if pd.notna(v) else None)
        precise_source = report["fields"].get("年龄", {})
        if precise_source.get("reliable"):
            # 采用已选中的精确题，而非原同名列的旧档位/年份口径。
            ages = pd.to_numeric(values[("年龄", precise_source["source_column"])], errors="coerce")
        elif "年龄" in out.columns and not (age_source and age_source["reliable"] and age_source["field"] != "年龄"):
            ages = pd.to_numeric(out["年龄"], errors="coerce")
        else:
            ages = pd.Series(float("nan"), index=out.index)
        conflict = ages.notna() & derived.notna() & (ages != derived)
        if conflict.any():
            pending("年龄与出生年份按参考年换算结果矛盾，请核对采集时点/生日口径")
        if ages.isna().all() and not precise_source.get("unrecognized_values"):
            out["年龄"] = derived
        report["warnings"].append(f"出生年份按参考年 {year} 换算年龄，未考虑生日；不覆盖已有年龄")
    if "年龄" in out.columns and "年龄分段" in report["fields"] and report["fields"]["年龄分段"]["reliable"]:
        conflicts = 0
        for age, band in zip(pd.to_numeric(out["年龄"], errors="coerce"), out["年龄分段"]):
            if is_missing(age) or is_missing(band):
                continue
            bounds = age_bounds(band)
            if bounds and not bounds[0] <= float(age) < bounds[1]:
                conflicts += 1
        if conflicts:
            pending(f"年龄与年龄分段有 {conflicts} 行矛盾，不覆盖原分段")
            report["warnings"].append(report["confirmation_reasons"][-1])
    core = [f for f, cs in candidates.items() if f in CORE_FIELDS]
    if any(report["fields"][f]["reliable"] for f in core) or (core and report["needs_confirmation"]):
        report["mode"] = "detail"
    if report["mode"] == "basic" and candidates:
        report["mode"] = "questionnaire"
    report["reference_year_source"] = "explicit" if reference_year is not None else "current_year"
    report["demo_fields"] = [f for f, c in report["fields"].items() if c["reliable"]]
    report["available_core_fields"] = [f for f in CORE_FIELDS if f in out.columns and any(not is_missing(v) for v in out[f]) and (f in report["demo_fields"] or f == "年龄" and "出生年份" in report["demo_fields"])]
    return out, report


def detect(df, demo_map=None, demo_value_map=None, reference_year=None):
    """与 normalize 同一契约，只返回识别报告。"""
    return normalize(df, demo_map, demo_value_map, reference_year)[1]
