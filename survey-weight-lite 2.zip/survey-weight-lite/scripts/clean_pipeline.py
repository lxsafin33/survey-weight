#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""独立问卷清洗入口。仅使用问卷及可选城市分级资源。"""
import argparse
import csv
import hashlib
import io
import json
import math
import os
import re
import stat
import sys
from contextlib import contextmanager
from datetime import datetime
from pathlib import Path
from uuid import uuid4

import pandas as pd
from openpyxl import Workbook, load_workbook

from demographic_detection import (answer_text, age_bounds, is_missing, normalize,
                                   question_number, strip_question_number, text)

DEFAULT_AGE_GROUPS = "30岁以下,30-39岁,40-49岁,50岁及以上"
DEFAULT_CITY = Path(__file__).resolve().parent.parent / "assets" / "标准版本-城市分级2025.xlsx"
CONFIG = "pipeline_config.json"
MAPPING = "demographic_mapping.json"
REF = "_source_row_ref"
CONVERTED = "未清洗问卷数据表.xlsx"
CONVERSION_REPORT = "conversion_report.json"
CSV_ENCODINGS = ("auto", "utf-8-sig", "utf-8", "gb18030", "gbk")
EXCEL_MAX_ROWS = 1048576
EXCEL_MAX_COLS = 16384
EXCEL_MAX_TEXT = 32767
INVALID_XML = re.compile(r"[\x00-\x08\x0b\x0c\x0e-\x1f\ud800-\udfff\ufffe\uffff]")
RULES = {
    "大学专科/本科<17岁": ["年龄", "学历"],
    "硕士<21岁": ["年龄", "学历"],
    "在校学生&初中及以下>17岁": ["年龄", "学历", "职业"],
    "在校学生&高中/中专/技校>21岁": ["年龄", "学历", "职业"],
    "在校学生&大学专科/本科/硕士>35岁": ["年龄", "学历", "职业"],
    "公务员<18岁": ["年龄", "职业"],
    "专业人员<21岁": ["年龄", "职业"],
    "工人/职员/职工<16岁": ["年龄", "职业"],
    "退休人员:男<60岁": ["年龄", "职业", "性别"],
    "退休人员:女<50岁": ["年龄", "职业", "性别"],
}
EDU_EXACT = {"初中及以下", "高中/中专/技校", "大学专科", "大学本科", "硕士及以上"}


class CLIError(ValueError):
    pass


class Parser(argparse.ArgumentParser):
    def error(self, message):
        raise CLIError("参数错误：" + message)


def emit(result):
    print("@@RESULT@@ " + json.dumps(result, ensure_ascii=False, allow_nan=False, default=str))


def read_json(path):
    return json.loads(path.read_text(encoding="utf-8"))


def write_json(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False, default=str), encoding="utf-8")


def save_excel(frame, path, sheet):
    with pd.ExcelWriter(path, engine="openpyxl") as writer:
        frame.to_excel(writer, sheet_name=sheet, index=False)
        # 问卷文本以文字存储，不把等号开头的用户答案变成可执行公式。
        for row in writer.book[sheet].iter_rows():
            for cell in row:
                if cell.data_type == "f":
                    cell.data_type = "s"


def digest(path):
    h = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1048576), b""):
            h.update(chunk)
    return h.hexdigest()


def absolute_path(path):
    path = Path(path).expanduser().absolute()
    if ".." in path.parts:
        raise CLIError("安全路径不能包含父目录跳转")
    return path


@contextmanager
def directory_handle(path, create=False):
    path = absolute_path(path)
    fd = os.open(path.anchor, os.O_RDONLY | os.O_DIRECTORY)
    try:
        for part in path.parts[1:]:
            try:
                child = os.open(part, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW, dir_fd=fd)
            except FileNotFoundError:
                if not create:
                    raise
                os.mkdir(part, dir_fd=fd)
                child = os.open(part, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW, dir_fd=fd)
            except OSError as exc:
                raise CLIError("父目录链不是实际目录或包含软链") from exc
            os.close(fd)
            fd = child
        yield fd
    finally:
        os.close(fd)


def check_parent_chain(path):
    # 不创建目录，仍逐级检查所有已经存在的父目录（包括悬空软链）。
    path = absolute_path(path)
    for parent in reversed((path, *path.parents)):
        if parent.is_symlink():
            raise CLIError("父目录链不能包含软链")
        if parent.exists() and not parent.is_dir():
            raise CLIError("父目录链不是目录")


def mkdir_checked(path):
    with directory_handle(path, create=True):
        pass


def check_new_output(path, source=None):
    path = absolute_path(path)
    check_parent_chain(path.parent)
    if path.is_symlink() or path.exists():
        raise CLIError("目标文件已存在或是软链，不覆盖")
    if source is not None and path == absolute_path(source):
        raise CLIError("输出与输入路径冲突")
    return path


def remove_created(path, identity):
    with directory_handle(path.parent) as parent_fd:
        try:
            stat = os.stat(path.name, dir_fd=parent_fd, follow_symlinks=False)
        except FileNotFoundError:
            return
        if (stat.st_dev, stat.st_ino) == identity:
            os.unlink(path.name, dir_fd=parent_fd)


def create_bytes(path, payload):
    path = check_new_output(path)
    with directory_handle(path.parent, create=True) as parent_fd:
        fd = os.open(path.name, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW,
                     0o600, dir_fd=parent_fd)
        stat = os.fstat(fd)
        identity = (stat.st_dev, stat.st_ino)
        try:
            with os.fdopen(fd, "wb") as handle:
                if handle.write(payload) != len(payload):
                    raise CLIError("输出写入不完整")
                handle.flush()
                os.fsync(handle.fileno())
        except BaseException:
            current = os.stat(path.name, dir_fd=parent_fd, follow_symlinks=False)
            if (current.st_dev, current.st_ino) == identity:
                os.unlink(path.name, dir_fd=parent_fd)
            raise
    return identity


def json_bytes(value):
    return json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False, default=str).encode("utf-8")


def replace_metadata(path, payload, previous):
    # 仅替换已经核对的本流程配置，写失败不会截断旧配置。
    with directory_handle(path.parent) as parent_fd:
        fd = os.open(path.name, os.O_RDONLY | os.O_NOFOLLOW, dir_fd=parent_fd)
        with os.fdopen(fd, "rb") as handle:
            original = os.fstat(handle.fileno())
            if not stat.S_ISREG(original.st_mode) or handle.read() != previous:
                raise CLIError("配置文件已变动，不能覆盖")
        temporary = path.with_name("." + path.name + "." + uuid4().hex + ".tmp")
        identity = create_bytes(temporary, payload)
        try:
            current = os.stat(path.name, dir_fd=parent_fd, follow_symlinks=False)
            if (current.st_dev, current.st_ino) != (original.st_dev, original.st_ino):
                raise CLIError("配置文件已被替换，不能覆盖")
            os.replace(temporary.name, path.name, src_dir_fd=parent_fd, dst_dir_fd=parent_fd)
        finally:
            remove_created(temporary, identity)


def validate_csv_quotes(content):
    state = "start"
    for char in content:
        if state == "quoted":
            if char == '"':
                state = "closed"
        elif state == "closed":
            if char == '"':
                state = "quoted"
            elif char in ",\r\n":
                state = "start"
            else:
                raise CLIError("CSV引号闭合后存在非法字符")
        elif char in ",\r\n":
            state = "start"
        elif char == '"':
            if state != "start":
                raise CLIError("CSV未加引号字段内有非法引号")
            state = "quoted"
        else:
            state = "unquoted"
    if state == "quoted":
        raise CLIError("CSV存在不闭合引号")


def strict_csv(path, encoding="auto", payload=None):
    return strict_csv_details(path, encoding, payload)[:4]


def strict_csv_details(path, encoding="auto", payload=None):
    """返回 (表头, 记录, 编码, 跳过的物理空行数, 忽略的末尾无名空列数)。"""
    if encoding not in CSV_ENCODINGS:
        raise CLIError("不支持的CSV编码")
    if payload is None:
        payload = Path(path).read_bytes()
    choices = (("utf-8-sig" if payload.startswith(b"\xef\xbb\xbf") else "utf-8"), "gb18030") if encoding == "auto" else (encoding,)
    for selected in choices:
        try:
            content = payload.decode(selected)
            break
        except UnicodeDecodeError:
            continue
    else:
        raise CLIError("无法用支持的编码读取CSV，请显式指定encoding")
    if content.startswith("\ufeff"):
        content = content[1:]
    validate_csv_quotes(content)
    headers, rows, skipped, trailing = None, [], 0, 0
    previous_limit = csv.field_size_limit()
    try:
        csv.field_size_limit(sys.maxsize)
        for record in csv.reader(io.StringIO(content, newline=""), strict=True):
            if record == []:
                skipped += 1
                continue
            if headers is None:
                headers = record
                # 问卷平台导出常在每行末尾多一个逗号，形成末尾无名列；仅当它们整列为空时才忽略。
                while trailing < len(headers) and not headers[len(headers) - 1 - trailing].strip():
                    trailing += 1
                named = headers[:len(headers) - trailing]
                if not named or any(not value.strip() for value in named):
                    raise CLIError("CSV有空表头")
                if len(named) != len(set(named)):
                    raise CLIError("源文件有重复列名，不能自动改名掩盖歧义")
            else:
                if len(record) != len(headers):
                    raise CLIError(f"CSV第{len(rows) + 2}条逻辑记录列数不一致")
                rows.append(record)
    except csv.Error as exc:
        raise CLIError("CSV语法错误，不能保真读取") from exc
    finally:
        csv.field_size_limit(previous_limit)
    if headers is None:
        raise CLIError("CSV没有表头")
    if trailing:
        if any(value != "" for record in rows for value in record[-trailing:]):
            raise CLIError("CSV末尾无列名的列含有数据，不能自动忽略，请确认列名")
        headers = headers[:-trailing]
        rows = [record[:-trailing] for record in rows]
    return headers, rows, selected, skipped, trailing


def validate_sheet(sheet):
    if (not sheet or len(sheet.encode("utf-16-le", errors="surrogatepass")) // 2 > 31
            or re.search(r"[\[\]:*?/\\\x00-\x1f]", sheet) or INVALID_XML.search(sheet)
            or sheet.startswith("'") or sheet.endswith("'") or sheet.lower() == "history"):
        raise CLIError("Excel工作表名不合法")


def verify_excel(source, headers, rows, sheet):
    workbook = load_workbook(source, read_only=True, data_only=False)
    try:
        if workbook.sheetnames != [sheet]:
            raise CLIError("Excel回读工作表不一致")
        worksheet = workbook[sheet]
        worksheet.reset_dimensions()
        # 读取实际XML行（含明确全空尾记录），不信任可被改写的dimension。
        expected = [headers, *rows]
        observed = []
        for record in worksheet.iter_rows():
            values = []
            for cell in record:
                if cell.data_type == "f" or (cell.value is not None and not isinstance(cell.value, str)):
                    raise CLIError("Excel回读不是纯文字")
                values.append("" if cell.value is None else cell.value)
            observed.append(values)
        if len(observed) != len(expected) or any(len(row) != len(headers) for row in observed):
            raise CLIError("Excel回读行列数不一致")
        if observed != expected:
            raise CLIError("Excel回读单元格文字不一致")
        return pd.DataFrame(observed[1:], columns=observed[0], dtype=object)
    finally:
        workbook.close()


def serialize_conversion(source, output, sheet="data", encoding="auto"):
    source = absolute_path(source)
    if source.suffix.lower() != ".csv" or not source.is_file():
        raise CLIError("convert仅接受已有CSV源文件")
    output = check_new_output(output, source)
    if output.suffix.lower() != ".xlsx":
        raise CLIError("convert输出必须是.xlsx")
    validate_sheet(sheet)
    source_payload = source.read_bytes()
    before = hashlib.sha256(source_payload).hexdigest()
    headers, rows, selected, skipped, trailing = strict_csv_details(source, encoding, source_payload)
    if len(headers) > EXCEL_MAX_COLS or len(rows) + 1 > EXCEL_MAX_ROWS:
        raise CLIError("CSV超过Excel行列容量（行数包含表头）")
    for record in (headers, *rows):
        for value in record:
            if len(value) > EXCEL_MAX_TEXT or len(value.encode("utf-16-le", errors="surrogatepass")) // 2 > EXCEL_MAX_TEXT:
                raise CLIError("CSV单元格文字超过Excel32767长度限制")
            if INVALID_XML.search(value):
                raise CLIError("CSV单元格含非法XML字符")
    # 普通Workbook配合BytesIO，不在系统临时目录写出问卷XML。
    workbook = Workbook()
    worksheet = workbook.active
    worksheet.title = sheet
    for row_number, record in enumerate((headers, *rows), 1):
        for col_number, value in enumerate(record, 1):
            cell = worksheet.cell(row_number, col_number, value)
            cell.data_type = "s"
    buffer = io.BytesIO()
    try:
        workbook.save(buffer)
    finally:
        workbook.close()
    payload = buffer.getvalue()
    verify_excel(io.BytesIO(payload), headers, rows, sheet)
    after = digest(source)
    if before != after:
        raise CLIError("转换期间源CSV已变动")
    report = {"ok": True, "converted": True, "source": str(source), "output": str(output), "sheet": sheet,
              "encoding": selected, "rows": len(rows), "cols": len(headers), "verified": True,
              "source_unchanged": True, "source_sha256": before, "source_sha256_after": after,
              "output_sha256": hashlib.sha256(payload).hexdigest(), "skipped_blank_lines": skipped,
              "dropped_trailing_empty_columns": trailing,
              "summary": "纯CSV转Excel；表头及所有字段按文字保存，未识别人口学、未剔除、未新增权重"}
    return payload, report


def cmd_convert(args):
    payload, report = serialize_conversion(args.survey, args.output, args.sheet, args.encoding)
    output = Path(report["output"])
    identity = create_bytes(output, payload)
    try:
        if digest(Path(report["source"])) != report["source_sha256"]:
            raise CLIError("转换期间源CSV已变动")
        if digest(output) != report["output_sha256"]:
            raise CLIError("转换输出hash不一致")
    except BaseException:
        remove_created(output, identity)
        raise
    return report, 0


def read_table(path, sheet=None):
    if path.suffix.lower() == ".csv":
        headers, rows, encoding, _ = strict_csv(path)
        return pd.DataFrame(rows, columns=headers, dtype=object), encoding
    if path.suffix.lower() != ".xlsx":
        raise CLIError("仅支持 .xlsx 和 .csv")
    workbook = load_workbook(path, read_only=True, data_only=True)
    try:
        worksheet = workbook.worksheets[0] if sheet is None else workbook[sheet]
        headers = next(worksheet.iter_rows(values_only=True), ())
        present = [h for h in headers if h is not None]
        if len(present) != len(set(present)):
            raise CLIError("源文件有重复列名，不能自动改名掩盖歧义")
    finally:
        workbook.close()
    return pd.read_excel(path, sheet_name=0 if sheet is None else sheet, dtype=object,
                         keep_default_na=False), None


def maps_for(args, wd):
    saved = read_json(wd / MAPPING) if (wd / MAPPING).exists() else {}
    result = {}
    for key in ("demo_map", "demo_value_map"):
        value = dict(saved.get(key, {}))
        override = getattr(args, key, None)
        if override is not None:
            override = json.loads(override)
            if not isinstance(override, dict):
                raise CLIError("人口学映射必须是 JSON 对象")
            value.update(override)
        result[key] = value
    year = getattr(args, "reference_year", None)
    result["reference_year"] = saved.get("reference_year") if year is None else year
    if result["reference_year"] is not None and not 1900 <= result["reference_year"] <= 9999:
        raise CLIError("reference-year 必须在1900至9999之间")
    return result


def converted_source(wd, cfg):
    conversion = cfg["conversion"]
    source, output, report_path = wd / cfg["source_copy"], wd / CONVERTED, wd / CONVERSION_REPORT
    if source.suffix.lower() != ".csv" or conversion.get("source") != str(source) or conversion.get("output") != str(output) or conversion.get("report") != str(report_path):
        raise CLIError("转换文件路径不属于当前配置")
    for path, key in ((source, "source_sha256"), (output, "output_sha256"), (report_path, "report_sha256")):
        if path.is_symlink() or not path.is_file() or digest(path) != conversion.get(key):
            raise CLIError("转换源副本、Excel或报告已变动，不覆盖或继续清洗")
    if conversion["source_sha256"] != cfg["source_sha256"]:
        raise CLIError("转换源hash与配置不一致")
    report = read_json(report_path)
    expected = {k: v for k, v in conversion.items() if k not in ("report", "report_sha256")}
    if (report != expected or report.get("converted") is not True or report.get("verified") is not True
            or report.get("source_unchanged") is not True or report.get("source_sha256_after") != cfg["source_sha256"]):
        raise CLIError("转换报告与配置不一致")
    validate_sheet(report["sheet"])
    headers, rows, encoding, skipped, trailing = strict_csv_details(source, report["encoding"])
    if (len(rows), len(headers), encoding, skipped, trailing) != (report["rows"], report["cols"], report["encoding"], report["skipped_blank_lines"], report.get("dropped_trailing_empty_columns", 0)):
        raise CLIError("转换CSV行列或编码与报告不一致")
    raw = verify_excel(output, headers, rows, report["sheet"])
    for path, key in ((source, "source_sha256"), (output, "output_sha256"), (report_path, "report_sha256")):
        if digest(path) != conversion[key]:
            raise CLIError("转换核验期间文件已变动")
    return raw, encoding


def work_source(args):
    wd = absolute_path(args.dir)
    check_parent_chain(wd)
    if any((wd / name).is_symlink() for name in (CONFIG, MAPPING)):
        raise CLIError("配置/映射不能是软链")
    cfg = read_json(wd / CONFIG)
    if cfg.get("format") != "survey-weight-lite-v1":
        raise CLIError("不是本版创建的工作目录")
    name = cfg["source_copy"]
    if Path(name).name != name:
        raise CLIError("无效源副本路径")
    path = wd / name
    if path.is_symlink() or digest(path) != cfg["source_sha256"]:
        raise CLIError("源副本已变动，请在新工作目录重新prepare")
    if "conversion" in cfg:
        raw, encoding = converted_source(wd, cfg)
    else:
        if path.suffix.lower() == ".csv" and any((wd / name).exists() or (wd / name).is_symlink() for name in (CONVERTED, CONVERSION_REPORT)):
            raise CLIError("既有转换文件或报告不属于配置")
        raw, encoding = read_table(path, cfg.get("sheet"))
    return wd, cfg, raw, encoding


def normalized(raw, mapping):
    if not raw.columns.is_unique:
        raise CLIError("存在重复列名，须先确认真实列")
    reserved = [column for column in (REF, "_removed_stage", "_removed_reason") if column in raw]
    if reserved:
        raise CLIError("源列与审计保留列重名，不覆盖：" + "、".join(reserved))
    out, report = normalize(raw, **mapping)
    # 题列不会改写；同名标准字段规范化时额外保留原始值。
    preserved = {}
    for column in raw.columns:
        if column not in out or not raw[column].equals(out[column]):
            backup = "原始_" + str(column)
            if backup in raw.columns:
                raise CLIError("原始值备份列重名：" + backup)
            out[backup] = raw[column]
            preserved[str(column)] = backup
    report["preserved_source_values"] = preserved
    return out, report


def preserve_standard_value(frame, column):
    backup = "原始_" + column
    suffix = 2
    while backup in frame:
        backup = "原始_" + column + "_" + str(suffix)
        suffix += 1
    frame[backup] = frame[column].copy()
    return backup


def question_catalog(raw):
    catalog = []
    for col in raw.columns:
        q = question_number(col)
        if q is not None:
            options = list(dict.fromkeys(str(v) for v in raw[col] if not is_missing(v)))
            catalog.append({"q": q, "column": str(col), "stem": strip_question_number(col),
                            "options": options, "missing": int(raw[col].map(is_missing).sum())})
    return catalog


def id_series(raw, column=None):
    candidates = [c for c in raw.columns if text(c).lower() == "openid"]
    if column is not None:
        if column not in raw:
            raise CLIError("指定ID列不存在")
        candidates = [column]
    if len(candidates) > 1:
        return None, {"column": None, "needs_confirmation": True,
                      "note": "存在多个显式OpenID列，请使用 --id-column 确认"}
    if candidates:
        col = candidates[0]
        return raw[col].map(lambda v: None if is_missing(v) else str(v).strip()), {
            "column": col, "needs_confirmation": False, "method": "explicit_column"}
    # 仅提取带明确键名的openid；不把自定义字段首段或昵称猜作身份。
    if column is None and "自定义字段" in raw:
        def extract(value):
            if is_missing(value):
                return None
            s = str(value).strip()
            try:
                obj = json.loads(s)
                if isinstance(obj, dict):
                    found = [v for k, v in obj.items() if str(k).lower() == "openid"]
                    if len(found) == 1:
                        return None if is_missing(found[0]) else str(found[0]).strip()
            except (ValueError, TypeError):
                pass
            match = re.search(r'(?:^|[;；&])\s*openid\s*[:=：]\s*([^;；&]+)', s, re.I)
            return match.group(1).strip() if match else None
        ids = raw["自定义字段"].map(extract)
        if ids.notna().any():
            return ids, {"column": "自定义字段", "method": "explicit_openid_key", "needs_confirmation": False}
    return None, {"column": None, "needs_confirmation": False,
                  "note": "没有已确认的唯一ID，跳过去重；不使用昵称/IP/编号猜测身份"}


def attention_report(raw, column=None, option=None, disabled=False, skip_options=None, skip_empty=False):
    candidates = []
    for col in raw.columns:
        stem = text(col)
        if re.search(r"专注度|检验|认真|请\s*(?:选|选择)|选(?:择)?\s*(?:第\s*[一二三四五六七八九十\d]|[A-Z](?![A-Z]))", stem, re.I):
            candidates.append(str(col))
    report = {"candidates": candidates, "column": None, "correct_option": None,
              "correct_answer": None, "needs_confirmation": False, "confirmation_reasons": [],
              "disabled": disabled, "skip_options": skip_options or [], "skip_empty": skip_empty}
    if disabled:
        return report
    if column is not None:
        if column not in raw:
            raise CLIError("专注度列不存在")
        selected = column
    elif len(candidates) == 1:
        selected = candidates[0]
    elif candidates:
        report["needs_confirmation"] = True
        report["confirmation_reasons"].append("多个专注度候选，请用 --attention-column 确认完整列名")
        return report
    else:
        if option is not None:
            raise CLIError("指定正确选项前须指定专注度列")
        return report
    report["column"] = selected
    values = list(dict.fromkeys(str(v) for v in raw[selected] if not is_missing(v)))
    report["options"] = values
    letters = set(re.findall(r"(?:请\s*)?(?:选(?:择)?|选项)\s*([A-Z])(?![A-Z])", text(selected).upper()))
    chinese = "一二三四五六七八九十"
    for hit in re.findall(r"(?:请\s*)?选(?:择)?\s*第\s*([一二三四五六七八九十]|\d+)\s*(?:个|项)", text(selected)):
        n = chinese.index(hit) + 1 if hit in chinese else int(hit)
        if 1 <= n <= 26:
            letters.add(chr(64 + n))
    chosen = option
    if chosen is None and len(letters) == 1:
        chosen = next(iter(letters))
    if chosen is not None:
        exact = [v for v in values if v == chosen]
        if re.fullmatch(r"[A-Za-z]", chosen):
            matches = [v for v in values if text(v).upper() == chosen.upper() or re.match(r"^\s*" + chosen.upper() + r"\s*[.、:：)\-]", text(v).upper())]
        else:
            matches = exact
        if len(matches) == 1:
            report["correct_option"] = chosen
            report["correct_answer"] = matches[0]
        else:
            report["confirmation_reasons"].append("正确选项不存在或同字母多个答案，须确认实际选项全文")
    else:
        report["confirmation_reasons"].append("题干无法唯一解码，请使用 --attention-option 确认")
    for skip in report["skip_options"]:
        if skip not in values:
            raise CLIError("专注度跳题选项不存在")
    special = [v for v in values if re.search(r"不适用|跳题|跳过|未展示|无需作答", answer_text(v))]
    if any(v not in report["skip_options"] for v in special):
        report["confirmation_reasons"].append("存在不适用/跳题答案，须用 --attention-skip-option 指定，不能视为答错")
    if re.search(r"如果|若您|仅限|仅.*作答|跳题|跳过", text(selected)) and column is None:
        report["confirmation_reasons"].append("题干可能有适用逻辑，须手动指定列并确认跳题口径")
    report["missing"] = int(raw[selected].map(is_missing).sum())
    report["needs_confirmation"] = bool(report["confirmation_reasons"])
    return report


def inspect_result(args, wd, raw, encoding, demo):
    _, identity = id_series(raw, getattr(args, "id_column", None))
    att = attention_report(raw, getattr(args, "attention_column", None), getattr(args, "attention_option", None),
                           getattr(args, "no_attention_check", False), getattr(args, "attention_skip_option", None),
                           getattr(args, "attention_skip_empty", False))
    return {"ok": True, "mode": demo["mode"], "work_dir": str(wd), "demographics": demo,
            "demo_fields": demo["demo_fields"], "needs_confirmation": demo["needs_confirmation"] or identity["needs_confirmation"] or att["needs_confirmation"],
            "identity": identity, "rules": RULES, "survey": {"rows": len(raw), "cols": len(raw.columns),
            "encoding": encoding, "has_openid_field": identity["column"] is not None,
            "weight_cols": [str(c) for c in raw if text(c).lower() in ("weight", "权重")],
            "questions": [{k: v for k, v in q.items() if k != "options"} for q in question_catalog(raw)],
            "attention_check": att}}


def cmd_prepare(args):
    wd = absolute_path(args.dir)
    check_parent_chain(wd)
    source = Path(args.survey).expanduser().resolve()
    if not source.is_file():
        raise CLIError("问卷源文件不存在")
    if source.suffix.lower() not in (".csv", ".xlsx"):
        raise CLIError("仅支持 .xlsx 和 .csv")
    is_csv = source.suffix.lower() == ".csv"
    copy = wd / ("问卷数据表" + source.suffix.lower())
    if any((wd / name).is_symlink() for name in (CONFIG, MAPPING)):
        raise CLIError("配置/映射不能是软链")
    cfg = read_json(wd / CONFIG) if (wd / CONFIG).exists() else None
    if cfg is not None:
        if cfg.get("format") != "survey-weight-lite-v1" or (str(source) != cfg["source_original"] and source != copy):
            raise CLIError("工作目录属于另一源文件；请新建工作目录，不覆盖其它source")
        if cfg["source_copy"] != copy.name or copy.is_symlink() or digest(copy) != cfg["source_sha256"]:
            raise CLIError("源副本已变动，不覆盖")
        if source != copy and digest(source) != cfg["source_sha256"]:
            raise CLIError("原源文件已更新，请新建工作目录")
    elif copy.exists() and source != copy:
        raise CLIError("目标副本已存在，不覆盖；请使用新的工作目录")
    if copy.is_symlink():
        raise CLIError("不能使用软链作为源副本")
    for name in ("问卷数据表.csv", "问卷数据表.xlsx", MAPPING, "demographic_report.json", "clean_report.json", "问卷数据表_merged.xlsx", "问卷数据表_merged.csv"):
        if not cfg and ((wd / name).exists() or (wd / name).is_symlink()) and wd / name != source:
            raise CLIError("目标文件已存在，不覆盖：" + name)
    conversion = cfg.get("conversion") if cfg else None
    converted_payload, report_payload = None, None
    before = digest(source)
    if is_csv:
        sheet = args.sheet if args.sheet is not None else (conversion["sheet"] if conversion else "data")
        validate_sheet(sheet)
        if conversion:
            if sheet != conversion["sheet"]:
                raise CLIError("已有CSV转换sheet不同，请使用新工作目录")
            raw, encoding = converted_source(wd, cfg)
        else:
            for name in (CONVERTED, CONVERSION_REPORT):
                check_new_output(wd / name, source)
            converted_payload, report = serialize_conversion(source, wd / CONVERTED, sheet)
            headers, rows, encoding, _ = strict_csv(source, report["encoding"])
            raw = verify_excel(io.BytesIO(converted_payload), headers, rows, sheet)
            report["source"] = str(copy)
            report_payload = json_bytes(report)
            conversion = {**report, "report": str(wd / CONVERSION_REPORT),
                          "report_sha256": hashlib.sha256(report_payload).hexdigest()}
    else:
        raw, encoding = read_table(source, args.sheet if cfg is None or args.sheet is not None else cfg.get("sheet"))
    mapping = maps_for(args, wd)
    _, demo = normalized(raw, mapping)
    # 映射及体检参数错误必须先于源副本和转换产物的写入。
    result = inspect_result(args, wd, raw, encoding, demo)
    city = Path(args.city_file).expanduser().resolve() if args.city_file else (Path(cfg["city_file"]) if cfg and cfg.get("city_file") else DEFAULT_CITY)
    if args.city_file and not city.is_file():
        raise CLIError("指定城市分级文件不存在")
    if source in (wd / CONFIG, wd / MAPPING, wd / CONVERTED, wd / CONVERSION_REPORT):
        raise CLIError("源文件与配置/转换路径冲突")
    source_payload = source.read_bytes()
    if hashlib.sha256(source_payload).hexdigest() != before or digest(source) != before:
        raise CLIError("prepare期间源文件已变动")
    if conversion and conversion["source_sha256"] != before:
        raise CLIError("转换期间源CSV已变动")
    metadata_before = {wd / name: (wd / name).read_bytes() for name in (MAPPING, CONFIG) if (wd / name).exists()}
    cfg = cfg or {"format": "survey-weight-lite-v1", "source_original": str(source),
                  "source_copy": copy.name, "source_sha256": before, "outputs": []}
    if is_csv:
        cfg["sheet"] = None
        cfg["conversion"] = conversion
    else:
        cfg["sheet"] = args.sheet if args.sheet is not None else cfg.get("sheet")
    cfg["city_file"] = str(city) if city.is_file() else None
    created, replaced = [], []
    try:
        mkdir_checked(wd)
        if source != copy and not copy.exists():
            created.append((copy, create_bytes(copy, source_payload)))
        if converted_payload is not None:
            for path, payload in ((wd / CONVERTED, converted_payload), (wd / CONVERSION_REPORT, report_payload)):
                created.append((path, create_bytes(path, payload)))
        if is_csv:
            converted_source(wd, cfg)
        if digest(source) != before:
            raise CLIError("prepare期间源文件已变动")
        for path, value in ((wd / MAPPING, mapping), (wd / CONFIG, cfg)):
            payload = json_bytes(value)
            previous = metadata_before.get(path)
            if previous is None:
                created.append((path, create_bytes(path, payload)))
            elif previous != payload:
                replace_metadata(path, payload, previous)
                replaced.append((path, previous, payload))
        if digest(source) != before:
            raise CLIError("prepare期间源文件已变动")
    except BaseException:
        try:
            for path, previous, payload in reversed(replaced):
                replace_metadata(path, previous, payload)
        finally:
            for path, identity in reversed(created):
                remove_created(path, identity)
        raise
    result["source_copy"] = str(copy)
    result["mapping_file"] = str(wd / MAPPING)
    if is_csv:
        result["conversion"] = conversion
    return result, 0


def cmd_inspect(args):
    wd, cfg, raw, encoding = work_source(args)
    _, demo = normalized(raw, maps_for(args, wd))
    result = inspect_result(args, wd, raw, encoding, demo)
    if Path(cfg["source_copy"]).suffix.lower() == ".csv":
        result["conversion"] = cfg.get("conversion", {"converted": False, "source": str(wd / cfg["source_copy"]),
                                                     "summary": "旧CSV配置直接读取审计副本；再次prepare可补转换"})
    return result, 0


def age_groups(spec):
    labels = [g.strip().replace("～", "-").replace("~", "-").replace("至", "-") for g in re.split(r"[,，、;；]+", spec) if g.strip()]
    ranges, problems = [], []
    if not labels:
        problems.append("年龄区间不能为空")
    for label in labels:
        bounds = age_bounds(label)
        if bounds is None or bounds[0] >= bounds[1]:
            problems.append("无效年龄区间：" + label)
        else:
            ranges.append((*bounds, label))
    ranges.sort()
    if ranges:
        if ranges[0][0] != 0:
            problems.append("缺少最低年龄段")
        if ranges[-1][1] != 121:
            problems.append("缺少最高年龄段")
        for left, right in zip(ranges, ranges[1:]):
            if left[1] != right[0]:
                problems.append("年龄区间重叠或有空档：" + left[2] + " / " + right[2])
    return labels, ranges, problems


def question_numbers(spec):
    numbers = []
    for token in re.split(r"[,，、\s]+", spec.strip()):
        if not token:
            continue
        match = re.fullmatch(r"(?:Q|第)?(\d+)(?:题)?(?:[-~～至](?:Q|第)?(\d+)(?:题)?)?", token, re.I)
        if not match:
            raise CLIError("无效题号：" + token)
        start, end = int(match[1]), int(match[2] or match[1])
        if start < 1 or end < start or end - start > 10000:
            raise CLIError("无效题号范围")
        numbers.extend(range(start, end + 1))
    if not numbers:
        raise CLIError("题号不能为空")
    return list(dict.fromkeys(numbers))


def cmd_check(args):
    result = {"ok": True}
    if args.age_groups is not None:
        labels, ranges, problems = age_groups(args.age_groups)
        result.update(age_groups=",".join(labels), age_ranges=ranges, age_problems=problems)
        result["ok"] = not problems
    if args.cross is not None:
        if args.dir is None:
            raise CLIError("校验题号需指定 --dir")
        _, _, raw, _ = work_source(args)
        nums = question_numbers(args.cross)
        catalog = question_catalog(raw)
        found = {q["q"] for q in catalog}
        result.update(cross=nums, cross_found=[q for q in catalog if q["q"] in nums],
                      cross_missing=[n for n in nums if n not in found])
        result["ok"] = result["ok"] and not result["cross_missing"]
    return result, 0 if result["ok"] else 2


def cmd_questions(args):
    _, _, raw, _ = work_source(args)
    catalog = question_catalog(raw)
    if args.q is not None:
        nums = question_numbers(args.q)
        found = {q["q"] for q in catalog}
        if any(n not in found for n in nums):
            raise CLIError("指定题号不存在")
        catalog = [q for q in catalog if q["q"] in nums]
    return {"ok": True, "questions": catalog, "source": "source_copy"}, 0


def selected_rules(spec, disabled):
    def parse(value):
        if value.strip().lower() in ("", "none"):
            return []
        selected = []
        for item in value.split(","):
            item = item.strip()
            if item.isdigit() and 1 <= int(item) <= len(RULES):
                item = list(RULES)[int(item) - 1]
            if item not in RULES:
                raise CLIError("未知人口学规则：" + item)
            if item not in selected:
                selected.append(item)
        return selected
    chosen = list(RULES) if spec is None else parse(spec)
    disable = parse(disabled) if disabled is not None else []
    return [r for r in chosen if r not in disable]


def compile_filter(raw, rule):
    # 沿用旧版的保留掩码语义：== 删除匹配、!= 保留匹配；AND/OR组合保留条件，AND优先。
    parts = re.split(r"\s+(AND|OR)\s+", rule, flags=re.I)
    masks = []
    for condition in parts[::2]:
        hits = []
        for match in re.finditer(r"==|!=", condition):
            name, value = condition[:match.start()].strip(), condition[match.end():].strip()
            q = question_number(name)
            columns = [c for c in raw if q is not None and question_number(c) == q and strip_question_number(c) == strip_question_number(name)]
            if len(columns) == 1:
                hits.append((columns[0], match.group(), value))
        if len(hits) != 1:
            raise CLIError("自定义规则列不存在、题干不完整或表达式有歧义")
        col, operator, value = hits[0]
        present = raw[col].map(lambda v: False if is_missing(v) else str(v) == value)
        if not present.any():
            raise CLIError("自定义规则实际选项不存在：" + col + " / " + value)
        masks.append(~present if operator == "==" else present)
    groups = [masks[0]]
    for operator, mask in zip(parts[1::2], masks[1:]):
        if operator.upper() == "AND":
            groups[-1] &= mask
        else:
            groups.append(mask)
    keep = groups[0].copy()
    for group in groups[1:]:
        keep |= group
    return keep


def abnormal_mask(df, rule):
    age = pd.to_numeric(df["年龄"], errors="coerce")
    edu = df["学历"].map(lambda v: "" if is_missing(v) else answer_text(v)) if "学历" in RULES[rule] else None
    occ = df["职业"].map(lambda v: "" if is_missing(v) else answer_text(v)) if "职业" in RULES[rule] else None
    gender = df["性别"].map(lambda v: "" if is_missing(v) else answer_text(v)) if "性别" in RULES[rule] else None
    checks = {
        "大学专科/本科<17岁": lambda: edu.isin(["大学专科", "大学本科"]) & (age < 17),
        "硕士<21岁": lambda: (edu == "硕士及以上") & (age < 21),
        "在校学生&初中及以下>17岁": lambda: (occ == "在校学生") & (edu == "初中及以下") & (age > 17),
        "在校学生&高中/中专/技校>21岁": lambda: (occ == "在校学生") & (edu == "高中/中专/技校") & (age > 21),
        "在校学生&大学专科/本科/硕士>35岁": lambda: (occ == "在校学生") & edu.isin(["大学专科", "大学本科", "硕士及以上"]) & (age > 35),
        "公务员<18岁": lambda: (occ == "公务员") & (age < 18),
        "专业人员<21岁": lambda: (occ == "专业人员") & (age < 21),
        "工人/职员/职工<16岁": lambda: occ.isin(["工人", "职员", "职工"]) & (age < 16),
        "退休人员:男<60岁": lambda: occ.isin(["退休", "退休人员"]) & (gender == "男") & (age < 60),
        "退休人员:女<50岁": lambda: occ.isin(["退休", "退休人员"]) & (gender == "女") & (age < 50),
    }
    return checks[rule]()


def duration_values(raw, column):
    if column not in raw:
        raise CLIError("时长列不存在，请用 --duration-column 指定")
    def seconds(value):
        if is_missing(value):
            return float("nan")
        s = text(value)
        if re.fullmatch(r"\d+(?:\.\d+)?\s*(?:秒|s)?", s, re.I):
            return float(re.sub(r"\s*(?:秒|s)$", "", s, flags=re.I))
        if re.fullmatch(r"(?:\d+时)?(?:\d+分)?(?:\d+(?:\.\d+)?秒)?", s):
            return sum(float(n) * unit for n, unit in ((re.search(r"(\d+)时", s).group(1) if re.search(r"(\d+)时", s) else 0, 3600), (re.search(r"(\d+)分", s).group(1) if re.search(r"(\d+)分", s) else 0, 60), (re.search(r"(\d+(?:\.\d+)?)秒", s).group(1) if re.search(r"(\d+(?:\.\d+)?)秒", s) else 0, 1)))
        if re.fullmatch(r"\d+:\d{2}:\d{2}", s):
            h, m, sec = map(int, s.split(":"))
            return h * 3600 + m * 60 + sec if m < 60 and sec < 60 else float("nan")
        return float("nan")
    return raw[column].map(seconds)


def cmd_clean(args):
    if args.steps not in ("all", "全", "1,2,3,4,5", "4,5"):
        raise CLIError("steps仅支持all/全/1,2,3,4,5/4,5；每次从source副本完整重跑")
    wd, cfg, raw, encoding = work_source(args)
    mapping = maps_for(args, wd)
    df, demo = normalized(raw, mapping)
    ids, identity = id_series(raw, args.id_column)
    att = attention_report(raw, args.attention_column, args.attention_option, args.no_attention_check,
                           args.attention_skip_option, args.attention_skip_empty)
    chosen = selected_rules(args.rules, args.disable_rules)
    custom = [(rule, compile_filter(raw, rule)) for rule in args.filter_rule]
    warnings = list(demo["warnings"])
    reasons = list(demo["confirmation_reasons"])
    if identity["needs_confirmation"]:
        reasons.append(identity["note"])
    reasons.extend(att["confirmation_reasons"])
    if att["column"] and not args.no_attention_check and not args.confirm_attention_check:
        reasons.append("专注度剔除须 --confirm-attention-check 显式同意；默认空缺也会剔除，可明确跳过空缺")
    if args.drop_empty_id and ids is None:
        raise CLIError("没有已确认ID列，不能执行drop-empty-id")
    duration = None
    if args.min_duration_seconds is not None:
        if not math.isfinite(args.min_duration_seconds) or args.min_duration_seconds < 0:
            raise CLIError("时长阈值须为非负有限数")
        duration = duration_values(raw, args.duration_column or "答题时长")
        if duration.isna().any():
            warnings.append(f"时长无法解析/缺失 {int(duration.isna().sum())} 行，保留这些记录")
    elif args.duration_column is not None:
        warnings.append("未显式指定最小时长阈值，不执行时长剔除")
    ranges = None
    if args.age_groups is not None:
        _, ranges, problems = age_groups(args.age_groups)
        if problems:
            raise CLIError("；".join(problems))
    available = demo["available_core_fields"]
    checked = [c for c in ("性别", "年龄", "年龄分段", "学历", "职业") if c in available]
    if "年龄" in checked and "年龄分段" in checked:
        checked.remove("年龄分段")
    if args.no_demo_completeness:
        checked = []
    else:
        partial = [c for c in checked if df[c].map(is_missing).any()]
        if partial and not args.confirm_demo_completeness:
            reasons.append("可用核心字段部分缺失：" + "、".join(partial) + "；须 --confirm-demo-completeness 同意剔除或 --no-demo-completeness 跳过")
    if reasons:
        return {"ok": False, "needs_confirmation": True, "mode": demo["mode"],
                "confirmation_reasons": list(dict.fromkeys(reasons)), "demographics": demo,
                "attention_check": att, "data_unchanged": True}, 2
    df[REF] = range(2, len(raw) + 2)
    stats = {"raw_survey_count": len(raw), "empty_openid_removed": 0, "survey_dedupe_removed": 0,
             "demo_incomplete_removed": 0, "duration_removed": 0, "attention_removed": 0,
             "abnormal_removed": 0, "custom_removed": 0, "abnormal_stats": {}, "custom_stats": {},
             "demo_checked": checked, "skipped_rules": [], "funnel": []}
    removed = []
    def drop(mask, stage, reason, key):
        nonlocal df
        mask = mask.reindex(df.index, fill_value=False).astype(bool)
        count = int(mask.sum())
        if count:
            rows = df.loc[mask].copy()
            rows["_removed_stage"] = stage
            rows["_removed_reason"] = reason
            removed.append(rows)
            df = df.loc[~mask].copy()
        stats[key] += count
        stats["funnel"].append({"stage": stage, "removed": count, "remaining": len(df)})
        return count
    if ids is None:
        warnings.append(identity["note"])
        stats["id_missing_count"] = None
    else:
        missing = ids.isna()
        stats["id_missing_count"] = int(missing.sum())
        if missing.any():
            warnings.append("缺ID行默认保留，不互相去重；仅显式drop-empty-id时剔除")
        if args.drop_empty_id:
            drop(missing, "ID完整性", "ID为空", "empty_openid_removed")
        duplicate = pd.Series(False, index=raw.index)
        times = None
        if "结束答题时间" in raw:
            times = pd.to_datetime(raw["结束答题时间"], errors="coerce", format="mixed", utc=True)
        grouped = ids.loc[df.index].dropna().groupby(ids.loc[df.index].dropna(), sort=False)
        duplicate_groups = 0
        fallback_groups = 0
        for _, group in grouped:
            if len(group) < 2:
                continue
            duplicate_groups += 1
            if times is not None and times.loc[group.index].notna().all():
                latest = times.loc[group.index].max()
                keeper = times.loc[group.index][times.loc[group.index] == latest].index[-1]
            else:
                keeper = group.index[-1]
                fallback_groups += 1
            duplicate.loc[group.index[group.index != keeper]] = True
        stats["duplicate_group_count"] = duplicate_groups
        stats["dedupe_time_fallback_groups"] = fallback_groups
        if fallback_groups:
            warnings.append("重复ID组存在无法解析的结束时间，稳定保留该组最后一条")
        drop(duplicate, "去重", "重复非空ID，保留最新时间/稳定最后一条", "survey_dedupe_removed")
    for field in checked:
        drop(df[field].map(is_missing), "人口学完整性:" + field, "缺少可用核心字段:" + field, "demo_incomplete_removed")
    if duration is not None:
        drop(duration < args.min_duration_seconds, "答题时长", "低于用户确认时长阈值", "duration_removed")
    if att["column"] and not args.no_attention_check:
        series = raw[att["column"]]
        skip = series.astype(str).isin(att["skip_options"])
        if args.attention_skip_empty:
            skip |= series.map(is_missing)
        drop((series.astype(str) != att["correct_answer"]) & ~skip, "专注度", "未选择已确认正确答案", "attention_removed")
    for rule in chosen:
        missing = [c for c in RULES[rule] if c not in available]
        if missing:
            stats["skipped_rules"].append({"rule": rule, "required_fields": RULES[rule], "reason": "缺少实际可用字段:" + "、".join(missing)})
            continue
        if "学历" in RULES[rule]:
            merged = df["学历"].map(lambda v: not is_missing(v) and answer_text(v) not in EDU_EXACT)
            if merged.any():
                stats["skipped_rules"].append({"rule": rule, "reason": "合并学历无法精确执行，仅对规范细档执行", "skipped_rows": int(merged.sum())})
        count = drop(abnormal_mask(df, rule), "人口学异常", rule, "abnormal_removed")
        stats["abnormal_stats"][rule] = count
    for rule, keep in custom:
        count = drop(~keep, "自定义规则", rule, "custom_removed")
        stats["custom_stats"][rule] = stats["custom_stats"].get(rule, 0) + count
    reliable_band = "年龄分段" in available
    precise_age = "年龄" in available
    if args.age_groups is None:
        if precise_age and not reliable_band:
            _, ranges, _ = age_groups(DEFAULT_AGE_GROUPS)
    elif not precise_age:
        warnings.append("没有精确年龄，不能按指定age-groups重新分段；保留原年龄档位，不造年龄")
    if ranges is not None and precise_age:
        def band(value):
            if is_missing(value):
                return None
            return next((label for lo, hi, label in ranges if lo <= float(value) < hi), None)
        if "年龄分段" in df:
            backup = preserve_standard_value(df, "年龄分段")
            demo["preserved_source_values"].setdefault("年龄分段", backup)
        df["年龄分段"] = df["年龄"].map(band)
    city_path = Path(args.city_file).expanduser().resolve() if args.city_file else (Path(cfg["city_file"]) if cfg.get("city_file") else None)
    if "城市" in demo["demo_fields"] and "城市分级" not in demo["demo_fields"] and city_path:
        city_df, _ = read_table(city_path)
        if not {"城市名", "城市分级"} <= set(city_df.columns):
            raise CLIError("城市分级资源缺少城市名/城市分级列")
        city_map = dict(zip(city_df["城市名"], city_df["城市分级"]))
        def level(value):
            if is_missing(value):
                return None
            s = str(value).strip()
            return city_map.get(s, city_map.get(s + "市", city_map.get(s[:-1] if s.endswith("市") else s)))
        if "城市分级" in df:
            backup = preserve_standard_value(df, "城市分级")
            demo["preserved_source_values"].setdefault("城市分级", backup)
        df["城市分级"] = df["城市"].map(level)
        stats["city_level_filled"] = int(df["城市分级"].notna().sum())
    stats["final_count"] = len(df)
    stats["total_removed"] = len(raw) - len(df)
    stats["rerun_from"] = "source_copy"
    stats["steps_note"] = "所有steps均从源副本完整重跑，统计不堆叠"
    token = datetime.now().strftime("%Y%m%d_%H%M%S_%f") + "_" + uuid4().hex[:8]
    removed_name = "问卷数据表_剔除记录_" + token + ".xlsx"
    names = ["问卷数据表_merged.xlsx", "问卷数据表_merged.csv", "demographic_report.json", "clean_report.json", removed_name]
    for name in names:
        path = wd / name
        if path.is_symlink() or (path.exists() and name not in cfg["outputs"]):
            raise CLIError("非本流程产物已存在，不覆盖：" + name)
    result = {"ok": True, "mode": demo["mode"], "needs_confirmation": False, "demographics": demo,
              "attention_check": att, "identity": identity, "warnings": warnings, "stats": stats,
              "outputs": {"xlsx": str(wd / names[0]), "csv": str(wd / names[1]),
                          "removed": str(wd / removed_name), "demographics": str(wd / names[2]), "report": str(wd / names[3])},
              "source_copy": str(wd / cfg["source_copy"])}
    save_excel(df, wd / names[0], "data")
    df.to_csv(wd / names[1], index=False, encoding="utf-8-sig")
    removed_df = pd.concat(removed, ignore_index=True) if removed else pd.DataFrame(columns=list(df.columns) + ["_removed_stage", "_removed_reason"])
    save_excel(removed_df, wd / removed_name, "removed")
    write_json(wd / names[2], demo)
    write_json(wd / names[3], result)
    cfg["outputs"] = list(dict.fromkeys(cfg["outputs"] + names))
    write_json(wd / CONFIG, cfg)
    return result, 0


def build_parser():
    parser = Parser(description="仅问卷的本地清洗流程；所有重跑均读取源副本", allow_abbrev=False)
    subs = parser.add_subparsers(dest="command", required=True, parser_class=Parser)
    def common(command, required_dir=True):
        p = subs.add_parser(command, allow_abbrev=False)
        p.add_argument("--dir", required=required_dir)
        return p
    def demo_options(p):
        p.add_argument("--demo-map", help="标准字段到完整源列名的JSON对象")
        p.add_argument("--demo-value-map", help="标准字段到已确认码本的JSON对象")
        p.add_argument("--reference-year", type=int, help="出生年换算参考年；默认当前年并报告")
    def attention_options(p):
        p.add_argument("--id-column", help="确认真实唯一ID列，不自动猜测")
        p.add_argument("--attention-column", help="已确认专注度题的完整原列名")
        p.add_argument("--attention-option", help="正确选项字母或实际选项全文")
        p.add_argument("--no-attention-check", action="store_true")
        p.add_argument("--attention-skip-option", action="append", help="实际不适用/跳题选项全文，可重复")
        p.add_argument("--attention-skip-empty", action="store_true", help="明确将专注题空缺视为跳题保留")
    p = subs.add_parser("convert", allow_abbrev=False, help="仅CSV转Excel，不清洗、不加权、不覆盖")
    p.add_argument("--survey", required=True)
    p.add_argument("--output", required=True)
    p.add_argument("--sheet", default="data")
    p.add_argument("--encoding", choices=CSV_ENCODINGS, default="auto")
    p = common("prepare")
    p.add_argument("--survey", required=True)
    p.add_argument("--sheet")
    p.add_argument("--city-file")
    demo_options(p)
    p = common("inspect")
    demo_options(p)
    attention_options(p)
    p = common("check", False)
    p.add_argument("--age-groups")
    p.add_argument("--cross")
    p = common("questions")
    p.add_argument("--q")
    p = common("clean")
    demo_options(p)
    attention_options(p)
    p.add_argument("--steps", default="all", help="兼容全/4,5，均从source副本完整重跑")
    p.add_argument("--city-file")
    p.add_argument("--drop-empty-id", action="store_true")
    p.add_argument("--min-duration-seconds", type=float)
    p.add_argument("--duration-column")
    p.add_argument("--confirm-attention-check", action="store_true", help="明确同意剔除专注题非正确答案（含未明确跳过的空缺）")
    p.add_argument("--confirm-demo-completeness", action="store_true", help="同意剔除可用核心人口字段部分缺失行")
    p.add_argument("--no-demo-completeness", action="store_true")
    p.add_argument("--age-groups")
    p.add_argument("--rules", help="启用规则原名或1至10编号，逗号分隔；空字符串/none关闭全部，缺省启用全部")
    p.add_argument("--disable-rules", help="关闭规则原名或编号，逗号分隔")
    p.add_argument("--filter-rule", action="append", default=[], help="Q号.完整题干 == 实际选项（剔除）/ !=（只保留）；AND/OR组合保留掩码，AND优先")
    return parser


def main(argv=None):
    try:
        args = build_parser().parse_args(argv)
        result, status = globals()["cmd_" + args.command](args)
    except Exception as exc:
        result, status = {"ok": False, "error": str(exc)}, 2
    emit(result)
    return status


if __name__ == "__main__":
    sys.exit(main())
